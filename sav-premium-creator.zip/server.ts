/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini SDK with User-Agent header and the provided API Key
const aiKey = process.env.GEMINI_API_KEY;
const ai = aiKey 
  ? new GoogleGenAI({
      apiKey: aiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    })
  : null;

// Helper to check if API key is provided
function checkGeminiActive(res: express.Response): boolean {
  if (!ai) {
    res.status(503).json({ 
      error: 'API_KEY_MISSING',
      message: 'کلید وب‌سرویس هوش مصنوعی (GEMINI_API_KEY) تدارک دیده نشده است. لطفا در تب Secrets تنظیم کنید.' 
    });
    return false;
  }
  return true;
}

// 1. Endpoint: Generate Instagram Scenario
app.post('/api/generate-scenario', async (req, res) => {
  try {
    if (!checkGeminiActive(res)) return;

    const { idea, tone } = req.body;
    if (!idea) {
      return res.status(400).json({ error: 'ایده سناریو الزامی است' });
    }

    const prompt = `
      یک ایده خام دارید: "${idea}". 
      لحن درخواستی: "${tone || 'سینماتیک لوکس'}".
      لطفا یک سناریوی اینستاگرام بسیار خلاقانه، وایرال و چشم‌گیر به زبان فارسی بنویسید که بتواند مخاطب ایرانی را در همان ثانیه‌های اول میخکوب کند.
      خروجی باید به ساختار JSON تعریف شده بازگردانده شود. تمامی بخش‌ها باید به زبان فارسی فاخر، ترغیب‌کننده و هماهنگ با فرهنگ اینستاگرام ایرانی تولید شوند.
    `;

    const response = await ai!.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        systemInstruction: 'شما یک مربی و استاد سناریونویسی تبلیغاتی ریلز اینستاگرام در سطح جهانی برای برندهای لوکس هستید. همیشه پاسخ خود را با دقت و غنای بالا و به صورت ساختار یافته منطبق بر پاسخ درخواستی جفت کنید.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            hook: { 
              type: Type.STRING, 
              description: 'یک قلاب ۳ ثانیه‌ای بسیار طوفانی و شوکه‌کننده به زبان فارسی برای ابتدای ویدیو' 
            },
            scenarioText: { 
              type: Type.STRING, 
              description: 'متن سناریو به صورت کامل همراه دیالوگ‌ها و روند داستانی جذاب' 
            },
            caption: { 
              type: Type.STRING, 
              description: 'یک کپشن غنی، دارای ریتم، هشتگ‌های خاص و متناسب با الگوریتم' 
            },
            cta: { 
              type: Type.STRING, 
              description: 'رویکرد دکمه‌ی اقدام به عمل ترغیب‌کننده برای دریافت کامنت بیشتر' 
            },
            storyFlow: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '۳ تا ۵ فریم استوری خلاقانه مربوط به این ریلز به زبان فارسی'
            },
            shotList: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '۳ تا ۵ صحنه یا شات‌لیست تصویربرداری ترجیحا موبایلی'
            },
            cameraDirections: { 
              type: Type.STRING, 
              description: 'دستورالعمل‌های حرکتی دوربین، لرزش‌ها، زوایای باز و حرکت‌های سینمایی' 
            },
            musicMood: { 
              type: Type.STRING, 
              description: 'سبک موزیک پیشنهادی، امبینت، نئوآرت، ضربی تند، رازآلود، لوکس عمیق' 
            }
          },
          required: [
            'hook', 'scenarioText', 'caption', 'cta', 'storyFlow', 'shotList', 'cameraDirections', 'musicMood'
          ]
        }
      }
    });

    const textOutput = response.text;
    if (!textOutput) {
      throw new Error('سیستم هوش مصنوعی خروجی متنی تولید نکرد.');
    }

    const parsedData = JSON.parse(textOutput);
    res.json(parsedData);
  } catch (error: any) {
    console.error('Error generating scenario:', error);
    res.status(500).json({ 
      error: 'FAILED_GENERATION', 
      message: 'خطا در ارتباط با سرور هوش مصنوعی ساو. لطفا بار دیگر تلاش کنید.',
      details: error.message 
    });
  }
});

// 2. Endpoint: Refine Existing Scenario
app.post('/api/refine-scenario', async (req, res) => {
  try {
    if (!checkGeminiActive(res)) return;

    const { previousScenario, instruction } = req.body;
    if (!previousScenario || !instruction) {
      return res.status(400).json({ error: 'سناریوی قبلی و دستور ویرایش الزامی هستند' });
    }

    const prompt = `
      لطفا سناریوی قبلی زیر را بازنگری کرده و دقیقا دستورات جدید را اعمال کنید.
      در دستورالعمل‌ها آمده است: "${instruction}".
      
      اطلاعات سناریوی قبلی:
      - قلاب قبلی: ${previousScenario.hook}
      - متن قبلی: ${previousScenario.scenarioText}
      - کپشن قبلی: ${previousScenario.caption}
      - CTA قبلی: ${previousScenario.cta}
      - استوری فلو قبلی: ${(previousScenario.storyFlow || []).join(' | ')}
      - شات‌لیست قبلی: ${(previousScenario.shotList || []).join(' | ')}
      - دوربین قبلی: ${previousScenario.cameraDirections}
      - موزیک قبلی: ${previousScenario.musicMood}

      طوری بازنویسی کنید که تمام ساختارها حفظ شوند اما لحن و پیام کاملا ارتقا یابد. خروجی نهایی را در ساختار JSON سناریو به زبان فارسی مجددا تولید کنید.
    `;

    const response = await ai!.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        systemInstruction: 'شما دستیار و سناریونویس ارشد پلتفرم لوکس ساو هستید. سناریوها را ویرایش و تصحیح کرده و بر اساس بازخوردهای خلاقانه غنی‌سازی کنید. در فرمت ساختار یافته ی JSON پاسخ دهید.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            hook: { type: Type.STRING },
            scenarioText: { type: Type.STRING },
            caption: { type: Type.STRING },
            cta: { type: Type.STRING },
            storyFlow: { type: Type.ARRAY, items: { type: Type.STRING } },
            shotList: { type: Type.ARRAY, items: { type: Type.STRING } },
            cameraDirections: { type: Type.STRING },
            musicMood: { type: Type.STRING }
          },
          required: [
            'hook', 'scenarioText', 'caption', 'cta', 'storyFlow', 'shotList', 'cameraDirections', 'musicMood'
          ]
        }
      }
    });

    const textOutput = response.text;
    if (!textOutput) {
      throw new Error('سیستم هوش مصنوعی خروجی متنی جدید تولید نکرد.');
    }

    const parsedData = JSON.parse(textOutput);
    res.json(parsedData);
  } catch (error: any) {
    console.error('Error refining scenario:', error);
    res.status(500).json({ 
      error: 'FAILED_REFINEMENT', 
      message: 'خطا در ویرایش سناریو توسط هوش مصنوعی. لطفا مجدد امتحان کنید.', 
      details: error.message 
    });
  }
});

// 3. Endpoint: Rewrite Inspiration Scenario
app.post('/api/rewrite-inspiration', async (req, res) => {
  try {
    if (!checkGeminiActive(res)) return;

    const { 
      originalScenario, 
      originalTranscript, 
      productName, 
      isSellingProduct, 
      userIdea, 
      targetAudience, 
      tone 
    } = req.body;

    if (!originalTranscript || !productName) {
      return res.status(400).json({ error: 'اطلاعات سناریوی اصلی و نام محصول جدید الزامی است' });
    }

    const prompt = `
      شما یک متخصص و سناریونویس ارشد ریلز اینستاگرام در بازار ایران هستید.
      وظیفه شما بازنویسی خلاقانه (Rewrite) سناریوی موجود زیر بر اساس اطلاعات جدید کاربر است.
      
      توجه بسیار مهم: هدف، حفظ کامل ساختار، ریتم ضربه‌ای، شیوه قلاب کلامی/بصری و پیام‌رسانی هوشمندانه ویدئوی مرجع است، اما تمامی دیالوگ‌ها، نام محصول، جزئیات بسته‌بندی/آموزش/پیام به نیاز و محصول کاربر جدید بازآفرینی شود.

      ویدئوی مرجع (جهت الهامگیری ساختار و ریتم):
      - ترانسکریپت اصلی: "${originalTranscript}"
      - سناریوی مرجع: "${originalScenario || ''}"

      اطلاعات جدید کاربر برای بازنویسی اختصاصی:
      - نام محصول/خدمت کاربر: "${productName}"
      - آیا مستقیماً محصول یا خدمت می‌فروشند؟ "${isSellingProduct || 'خیر'}"
      - ایده اولیه یا زمینه کاری کاربر: "${userIdea || ''}"
      - مخاطب هدف کاربر: "${targetAudience || 'عموم مخاطبین درگیر اینستاگرام'}"
      - لحن درخواستی: "${tone || 'دوستانه و صمیمی'}"

      لطفاً خروجی بازنویسی شده را در قالب همان ساختار JSON استاندارد سناریو به زبان فارسی غنی، پربازدید و منطبق بر ادبیات مدرن ریلز بازگردانید.
    `;

    const response = await ai!.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        systemInstruction: 'شما یک استاد بازنویسی سناریو و ویرایشگر تبلیغات اینستاگرام لوکس ساو هستید. سناریوها را بسیار حرفه‌ای، تمیز و ساختاریافته به فرمت JSON فارسی برگردانید.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            hook: { type: Type.STRING, description: 'قلاب ۳ ثانیه‌ای جدید بازنویسی شده' },
            scenarioText: { type: Type.STRING, description: 'متن سناریو بازنویسی شده با حفظ ریتم ویدئوی اصلی' },
            caption: { type: Type.STRING, description: 'کپشن مناسب ریلز بازنویسی شده' },
            cta: { type: Type.STRING, description: 'دسترسی یا دعوت به اقدام جدید' },
            storyFlow: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'استوری فلو بازنویسی شده' },
            shotList: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'شات‌لیست بازنویسی شده' },
            cameraDirections: { type: Type.STRING },
            musicMood: { type: Type.STRING }
          },
          required: [
            'hook', 'scenarioText', 'caption', 'cta', 'storyFlow', 'shotList', 'cameraDirections', 'musicMood'
          ]
        }
      }
    });

    const textOutput = response.text;
    if (!textOutput) {
      throw new Error('سیستم هوش مصنوعی خروجی متنی تولید نکرد.');
    }

    const parsedData = JSON.parse(textOutput);
    res.json(parsedData);
  } catch (error: any) {
    console.error('Error rewriting inspiration:', error);
    res.status(500).json({ 
      error: 'FAILED_REWRITE', 
      message: 'خطا در بازنویسی سناریو الهامی توسط سرور هوش مصنوعی ساو. لطفا بار دیگر تلاش کنید.',
      details: error.message 
    });
  }
});

// Create Full-Stack Middleware integration
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Sav Server] Running on http://localhost:${PORT}`);
  });
}

startServer();
