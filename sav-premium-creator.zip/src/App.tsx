/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppStateProvider, useAppState } from './state';
import { Navigation } from './components/Navigation';
import { InspirationFeed } from './components/InspirationFeed';
import { BookingSystem } from './components/BookingSystem';
import { EducationalPlatform } from './components/EducationalPlatform';
import { AdminPanel } from './components/AdminPanel';
import { AppContainer } from './components/AppContainer';
import { AuthModal } from './components/AuthModal';
import { SupportSystem } from './components/SupportSystem';
import { ArticlesHub } from './components/ArticlesHub';
import { HomeView } from './components/HomeView';
import { ServicesHub } from './components/ServicesHub';

function MainAppContent() {
  const [currentTab, setCurrentTab] = useState('home');
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [selectedGateway, setSelectedGateway] = useState<'zarinpal' | 'idpay' | 'stripe'>('zarinpal');
  const [coupon, setCoupon] = useState('');
  const [loadingPayment, setLoadingPayment] = useState(false);

  const { currentUser, simulatePayment, settings, updateUserSubscription } = useAppState();

  const handleUpgradePayment = () => {
    setLoadingPayment(true);
    setTimeout(() => {
      // Simulate successful payment record addition
      const discount = coupon.trim().toLowerCase() === 'sav2026' ? 0.2 : 0;
      const finalAmount = Math.round(settings.goldSubscriptionPrice * (1 - discount));
      
      simulatePayment({
        amount: finalAmount,
        type: 'subscription',
        description: 'خرید اشتراک ماهانه طلایی هوش مصنوعی ساو',
        gateway: selectedGateway,
        status: 'successful'
      });

      updateUserSubscription(currentUser.id, true);
      setLoadingPayment(false);
      setShowUpgradeModal(false);
      setCoupon('');
      alert('✓ پرداخت شما تایید شد! دسترسی ویژه GOLD نامحدود تا ۳۰ روز آینده فعال گردید.');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-matte-dark pb-24 md:pb-6 text-zinc-100 flex flex-col font-sans selection:bg-brand-orange/30 selection:text-white relative overflow-hidden">
      {/* Background Ambient Glows from Sophisticated Dark */}
      <div className="absolute top-[-100px] left-[-100px] w-[400px] h-[400px] bg-brand-orange rounded-full blur-[150px] opacity-10 pointer-events-none z-0" />
      <div className="absolute bottom-[-100px] right-[-100px] w-[500px] h-[500px] bg-brand-red rounded-full blur-[180px] opacity-10 pointer-events-none z-0" />

      {/* Dynamic Header & Navigation Layout wrapper */}
      <Navigation 
        currentTab={currentTab} 
        onChangeTab={setCurrentTab} 
        isGoldSubscriber={currentUser.isPremium}
        onUpgradeGold={() => setShowUpgradeModal(true)}
        onLoginTrigger={() => setShowAuthModal(true)}
      />

      {/* Main Container Layout */}
      <AppContainer currentTab={currentTab}>
        {/* Home Dashboard Landing Page */}
        {currentTab === 'home' && (
          <HomeView 
            onChangeTab={setCurrentTab} 
            onUpgradeGold={() => setShowUpgradeModal(true)} 
          />
        )}

        {/* Services Hub (which nests production requests, creators, clinical consultation) */}
        {currentTab === 'services' && <ServicesHub />}

        {/* Articles Hub Editorial Page */}
        {currentTab === 'articles' && <ArticlesHub />}

        {/* Masterclass educational lists */}
        {currentTab === 'education' && <EducationalPlatform />}

        {/* Scenario Creator engine */}
        {currentTab === 'user' && (
          <InspirationFeed />
        )}

        {/* Support Ticketing System */}
        {currentTab === 'support' && <SupportSystem />}

        {/* Admin CRM Control board */}
        {currentTab === 'admin' && <AdminPanel />}
      </AppContainer>

      {/* Authenticator modal */}
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />

      {/* Luxury Payment Gateway Simulation Modal */}
      {showUpgradeModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-950 border border-white/10 rounded-3xl p-6 md:p-8 max-w-md w-full space-y-6 shadow-2xl relative text-right">
            <button 
              onClick={() => setShowUpgradeModal(false)}
              className="absolute top-4 left-4 text-zinc-500 hover:text-white text-xs font-bold"
            >
              بستن ×
            </button>

            <div className="space-y-2 text-center">
              <span className="text-amber-400 font-extrabold text-xs tracking-wider uppercase bg-amber-500/10 px-3 py-1 rounded-full text-center">★ طعم برتری را بچشید ★</span>
              <h3 className="text-xl font-black text-white mt-2">اشتراک طلایی نامحدود ساو (MEMBER GOLD)</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                قفل موتورهای دکوپاژ ساو را باز کنید و روزانه تا ۵۰ سناریو سینمایی با وضوح بالا بسازید. همچنین از ۲ جلسه کلینیک و مربیگری رایگان بهره‌مند شوید.
              </p>
            </div>

            {/* Billing breakdown */}
            <div className="p-4 rounded-xl bg-white/[2%] border border-white/5 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-zinc-400">شارژ ۳۰ روزه طلایی:</span>
                <span className="font-mono text-white font-bold">{settings.goldSubscriptionPrice.toLocaleString()} تومان</span>
              </div>
              <div className="flex justify-between text-emerald-400">
                <span>تخفیف ویژه جشنواره بهار:</span>
                <span>۰ تومان</span>
              </div>
              <div className="border-t border-white/5 pt-2 flex justify-between font-bold text-white">
                <span>مبلغ نهایی فاکتور:</span>
                <span className="font-mono text-brand-orange">{settings.goldSubscriptionPrice.toLocaleString()} تومان</span>
              </div>
            </div>

            {/* Gateway Choose */}
            <div className="space-y-2">
              <label className="text-[11px] font-bold text-zinc-400 block">انتخاب درگاه امن پرداختی</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'zarinpal', label: '💳 زرین‌پال' },
                  { id: 'idpay', label: '📲 آی‌دی‌پی' },
                  { id: 'stripe', label: '🌍 استرایپ' }
                ].map((gate) => (
                  <button
                    key={gate.id}
                    onClick={() => setSelectedGateway(gate.id as any)}
                    className={`py-2 rounded-xl text-center text-xs font-bold transition-all border ${
                      selectedGateway === gate.id 
                        ? 'border-brand-orange text-brand-orange bg-brand-orange/5' 
                        : 'border-white/5 text-zinc-400 bg-white/[1.5%]'
                    }`}
                  >
                    {gate.label}
                  </button>
                ))}
              </div>
            </div>

            {/* coupon */}
            <div className="space-y-1.5">
              <label className="text-[10px] text-zinc-500 font-bold block">کد تخفیف (کپن)</label>
              <input
                type="text"
                value={coupon}
                onChange={(e) => setCoupon(e.target.value)}
                placeholder="کد تخفیف خود را بنویسید (کد تست: sav2026)"
                className="w-full px-3.5 py-2 rounded-xl bg-white/[3%] border border-white/10 text-xs text-white"
              />
              {coupon.trim().toLowerCase() === 'sav2026' && (
                <p className="text-[10px] text-green-400 font-bold">✓ کد طلایی ساو معتبر است! ۲۰٪ تخفیف روی فاکتور اعمال شد.</p>
              )}
            </div>

            {/* Simulated processing */}
            <button
              onClick={handleUpgradePayment}
              disabled={loadingPayment}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-brand-orange to-brand-red text-white text-xs font-black transition-all flex items-center justify-center gap-2"
            >
              {loadingPayment ? 'در حال اتصال به شتاب...' : 'پرداخت آنلاین فاکتور'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <AppStateProvider>
      <MainAppContent />
    </AppStateProvider>
  );
}
