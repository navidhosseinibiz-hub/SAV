/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Scenario {
  id: string;
  idea: string;
  tone: string;
  hook: string;
  scenarioText: string;
  caption: string;
  cta: string;
  storyFlow: string[];
  shotList: string[];
  cameraDirections: string;
  musicMood: string;
  reviewStatus: 'pending' | 'under_review' | 'completed'; // در انتظار, در حال بررسی, تکمیل شده
  expertNotes?: string;
  createdAt: string;
}

export interface Consultation {
  id: string;
  topic: string;
  jalaliDate: string;
  timeSlot: string;
  meetLink: string;
  telegramStatus: 'sent' | 'pending';
  createdAt: string;
}

export interface ProductionRequest {
  id: string;
  contentType: string; // Reel, Podcast, Commercial, Talking Head, Motion Graphics, Documentary
  budget: number; // in Tomans
  qualityLevel: string; // Basic, Professional, Cinematic, Ultra Premium
  referenceLinks: string;
  jalaliDate: string;
  additionalNotes: string;
  status: 'received' | 'contacted' | 'completed';
  createdAt: string;
}

export interface Lesson {
  id: string;
  title: string;
  videoUrl: string;
  duration: string;
  summary: string;
  contentType?: 'video' | 'text' | 'both';
  richContent?: string;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  price: number; // in Tomans
  lessons: Lesson[];
  category: string;
  image: string;
  isPremium: boolean;
}

export interface UserNote {
  id: string;
  lessonId: string;
  lessonTitle: string;
  timestamp: string; // e.g. "02:15"
  content: string;
  createdAt: string;
}

export interface ScenarioTemplate {
  id: string;
  title: string;
  category: string; // e.g. بلاگری, معرفی محصول, آموزشی, انگیزشی
  prompt: string;
  aiStyle: string; // e.g. لوکس, احساسی, وایرال
}

export interface BlogPost {
  id: string;
  title: string;
  category: string;
  content: string;
  scheduledDate: string;
  seoTitle: string;
  seoKeywords: string;
  status: 'draft' | 'published' | 'scheduled';
  videoUrl?: string;
}

export interface PaymentRecord {
  id: string;
  amount: number; // In Tomans
  type: 'subscription' | 'production_deposit' | 'booking_fee' | 'course_purchase';
  description: string;
  gateway: 'zarinpal' | 'idpay' | 'stripe';
  status: 'successful' | 'failed' | 'pending';
  refId?: string;
  date: string;
}

export interface ProductionTeamMember {
  id: string;
  name: string;
  avatar: string;
  role: string;
  bio: string;
  portfolio: {
    title: string;
    videoUrl: string;
    coverImage: string;
    views: string;
  }[];
  availability: 'available' | 'busy' | 'offline';
  rating: number;
}

export interface UserProfile {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  isPremium: boolean;
  isGuest: boolean;
  status: 'active' | 'suspended';
  aiCount: number;
  registrationDate: string;
  provider: 'otp' | 'google' | 'guest';
}

export interface SupportTicket {
  id: string;
  userId: string;
  userName: string;
  department: string; // 'پشتیبانی فنی' | 'مالی و اشتراک' | 'مشاوره سناریو' | 'خدمات ساخت'
  title: string;
  status: 'open' | 'pending' | 'answered' | 'closed';
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
  messages: {
    sender: 'user' | 'admin';
    senderName: string;
    content: string;
    createdAt: string;
    fileUrl?: string;
  }[];
}

export interface HomeSection {
  id: string;
  type: 'hero' | 'features' | 'popular_courses' | 'cta_banner' | 'stats' | 'team';
  title: string;
  subtitle: string;
  enabled: boolean;
  order: number;
}

export interface PushCampaign {
  id: string;
  title: string;
  description: string;
  image?: string;
  ctaLink?: string;
  segment: 'all' | 'guest' | 'standard' | 'premium';
  status: 'scheduled' | 'sent';
  scheduledAt?: string;
}

export interface InspirationVideo {
  id: string;
  title: string;
  videoUrl: string;
  category: string;
  transcript: string;
  scenario?: string; // Scenario structure or detailed prompt
  isPinned: boolean;
  likes: number;
  likedByUsers?: string[];
  createdAt: string;
}

