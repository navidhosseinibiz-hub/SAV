/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  GraduationCap, 
  Video, 
  ShieldCheck, 
  UserCheck, 
  MessageSquare, 
  LogIn, 
  LogOut, 
  FileText, 
  Clock, 
  Tv, 
  Home, 
  Menu, 
  X, 
  Bell, 
  CheckCheck, 
  User 
} from 'lucide-react';
import { useAppState } from '../state';

interface NavigationProps {
  currentTab: string;
  onChangeTab: (tab: string) => void;
  isGoldSubscriber: boolean;
  onUpgradeGold: () => void;
  onLoginTrigger: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({ 
  currentTab, 
  onChangeTab,
  isGoldSubscriber,
  onUpgradeGold,
  onLoginTrigger
}) => {
  const { currentUser, logout, copywriting } = useAppState();

  // Drawer States
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [simulatedIsAdmin, setSimulatedIsAdmin] = useState(() => {
    const saved = localStorage.getItem('sav_simulated_admin');
    return saved === 'true';
  });

  // Stateful notifications for high craftsmanship & real interactivity
  const [notifications, setNotifications] = useState(() => {
    const saved = localStorage.getItem('sav_notifications');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'notif1',
        title: '🌟 شارژ سهمیه هوش مصنوعی ساو',
        text: 'موتور بهینه‌سازی قلاب سهمیه روزانه شما را شارژ کرد. آماده نوشتن سناریوهای پربازدید جدید باشید.',
        date: '۱۰ دقیقه پیش',
        read: false
      },
      {
        id: 'notif2',
        title: '📽️ درس جدید دکوپاژ سینماتیک ریلز',
        text: 'ویدیو تدریس اصول نورپردازی خلاقانه در تب آکادمی آپدیت شد.',
        date: '۱ ساعت پیش',
        read: false
      },
      {
        id: 'notif3',
        title: '💬 پاسخ مربی آکادمی',
        text: 'آخرین تیکت مشاوره شما بررسی شد و مربی سناریو، ایده قلاب شما را بازنویسی کرد.',
        date: 'دیروز',
        read: true
      }
    ];
  });

  // Save states to localStorage on change
  useEffect(() => {
    localStorage.setItem('sav_simulated_admin', simulatedIsAdmin ? 'true' : 'false');
  }, [simulatedIsAdmin]);

  useEffect(() => {
    localStorage.setItem('sav_notifications', JSON.stringify(notifications));
  }, [notifications]);

  // Unread Count
  const unreadCount = notifications.filter(n => !n.read).length;

  const handleMarkAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const handleMarkSingleRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const toggleSimulatedAdmin = () => {
    setSimulatedIsAdmin(prev => !prev);
  };

  const navItems = [
    { id: 'home', label: 'خانه', icon: Home, color: 'text-blue-400' },
    { id: 'services', label: 'خدمات', icon: Tv, color: 'text-teal-400' },
    { id: 'education', label: 'آکادمی', icon: GraduationCap, color: 'text-amber-400' },
    { id: 'user', label: 'الهامگیری', icon: Sparkles, color: 'text-orange-500' },
    { id: 'articles', label: 'مقالات', icon: FileText, color: 'text-rose-400' }
  ];

  return (
    <>
      {/* Horizontal Sticky Header for Branding & Premium Status */}
      <header className="sticky top-0 z-40 w-full border-b border-white/10 bg-[#0F0F10]/90 backdrop-blur-md px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-brand-orange to-brand-red flex items-center justify-center font-black text-white text-lg tracking-widest shadow-lg shadow-brand-orange/20">
              {(copywriting?.appName || 'ساو').charAt(0)}
            </div>
            <div className="absolute -top-1 -left-1 w-2.5 h-2.5 bg-green-500 rounded-full border border-matte-dark animate-pulse" />
          </div>
          <div>
            <h1 className="text-base font-extrabold text-white tracking-wide">پلتفرم فوق‌حرفه‌ای <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-orange to-brand-red">{copywriting?.appName || 'ساو'}</span></h1>
            <p className="text-[10px] text-zinc-400 font-medium tracking-tight">سیستم عامل لوکس تولیدکنندگان محتوای اینستاگرام</p>
          </div>
        </div>

        {/* Action controls */}
        <div className="flex items-center gap-3">
          {currentUser.isGuest ? (
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onLoginTrigger}
              className="px-4 py-1.5 rounded-full bg-white/5 border border-white/10 hover:border-brand-orange/40 text-xs font-bold text-zinc-200 transition-all flex items-center gap-1.5"
            >
              <LogIn className="w-3.5 h-3.5 text-brand-orange" />
              <span>ورود / ثبت‌نام</span>
            </motion.button>
          ) : (
            isGoldSubscriber || currentUser.isPremium ? (
              <motion.div 
                initial={{ scale: 0.9 }}
                animate={{ scale: 1 }}
                className="px-3 py-1.5 rounded-full bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-rose-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                <span>کاربر ویژه (GOLD)</span>
              </motion.div>
            ) : (
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={onUpgradeGold}
                className="px-4 py-1.5 bg-gradient-to-r from-brand-orange to-brand-red hover:from-orange-600 hover:to-rose-600 text-white rounded-full text-xs font-extrabold shadow-lg shadow-brand-orange/15 transition-all flex items-center gap-1.5"
              >
                <span>ارتقا به ویژه ★</span>
              </motion.button>
            )
          )}

          <div className="hidden md:flex items-center gap-2 border-r border-white/5 pr-3 mr-1">
            <div className="w-8 h-8 rounded-full bg-zinc-800 border border-white/10 flex items-center justify-center text-zinc-300">
              <UserCheck className="w-4 h-4" />
            </div>
            <span className="text-xs text-zinc-300 font-bold hidden lg:inline">{currentUser.name}</span>
            {!currentUser.isGuest && (
              <button 
                onClick={logout}
                className="p-1 rounded text-zinc-500 hover:text-rose-450 transition-colors"
                title="خروج از حساب"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Elegant Hamburger menu trigger (always visible as requested) */}
          <button
            onClick={() => setIsDrawerOpen(true)}
            className="p-2 md:p-2.5 rounded-xl bg-white/[2%] hover:bg-white/[6%] border border-white/10 hover:border-white/20 text-zinc-300 hover:text-white transition-all flex items-center justify-center relative cursor-pointer"
            id="hamburger_menu_btn"
            title="منوی جامع کاربری"
          >
            <Menu className="w-5 h-5" />
            {unreadCount > 0 && !simulatedIsAdmin && (
              <span className="absolute -top-1 -left-1 flex h-4 w-4 items-center justify-center rounded-full bg-brand-red text-[8px] font-bold text-white ring-2 ring-[#0F0F10]">
                {unreadCount}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* Drawer Overlay backdrop and panel using AnimatePresence */}
      <AnimatePresence>
        {isDrawerOpen && (
          <>
            {/* Backdrop Overlay */}
            <motion.div
              key="drawer-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              onClick={() => setIsDrawerOpen(false)}
              className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm cursor-pointer"
            />

            {/* Left Drawer Slider Container */}
            <motion.div
              key="drawer-panel"
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 22, stiffness: 150 }}
              className="fixed top-0 bottom-0 left-0 z-55 w-80 max-w-[90vw] bg-[#0A0A0B] border-r border-white/10 text-right p-6 flex flex-col justify-between shadow-2xl overflow-y-auto font-sans"
              dir="rtl"
            >
              <div className="space-y-6">
                {/* Drawer Header with Close Button */}
                <div className="flex items-center justify-between border-b border-white/5 pb-4">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-brand-orange animate-pulse" />
                    <span className="text-sm font-black text-white">سامانه هوشمند رشد {copywriting?.appName || 'ساو'}</span>
                  </div>
                  <button
                    onClick={() => setIsDrawerOpen(false)}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/10 text-zinc-400 hover:text-white transition-all"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* Simulated Role Setting Block (Super Smart testing tool) */}
                <div className="p-3.5 rounded-2xl bg-white/[1.5%] border border-white/5 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-zinc-400 font-bold">نقش شبیه‌سازی‌شده (جهت تست)</span>
                    <span className={`text-[9px] font-black px-2 py-0.5 rounded ${simulatedIsAdmin ? 'bg-emerald-500/15 text-emerald-400' : 'bg-blue-500/15 text-blue-400'}`}>
                      {simulatedIsAdmin ? 'مدیر سیستم' : 'کاربر معمولی'}
                    </span>
                  </div>
                  <button 
                    onClick={toggleSimulatedAdmin}
                    className="w-full py-1.5 text-center bg-white/5 hover:bg-white/10 rounded-xl text-[10px] font-bold text-zinc-300 border border-white/5 transition-all flex items-center justify-center gap-2"
                  >
                    <User className="w-3.5 h-3.5 text-brand-orange" />
                    <span>تغییر نقش به {simulatedIsAdmin ? 'کاربر معمولی' : 'مدیر سیستم'}</span>
                  </button>
                </div>

                {/* Dynamic Content menu depending on Simulated Role */}
                {simulatedIsAdmin ? (
                  /* --- ADMIN FLOW --- */
                  <div className="space-y-4">
                    {/* Primary Highlighted Command Button */}
                    <button
                      onClick={() => {
                        onChangeTab('admin');
                        setIsDrawerOpen(false);
                      }}
                      className="w-full p-4 rounded-xl bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-transparent border border-emerald-500/30 hover:border-emerald-400 text-right space-y-1 transition-all group shadow-md"
                    >
                      <div className="flex items-center gap-2 text-emerald-400">
                        <ShieldCheck className="w-4 h-4 animate-bounce" />
                        <span className="text-xs font-black">ورود به پنل مدیریت ارشد</span>
                      </div>
                      <p className="text-[9px] text-zinc-500">پایش سیستم، درخواست‌های فیلم‌برداری، کاربران و تغییر قوانین مالی.</p>
                    </button>

                    {/* Standard menu links block */}
                    <div className="space-y-1.5">
                      <p className="text-[10px] text-zinc-500 font-black px-1 mb-1">منوی اصلی سایت</p>
                      {navItems.map((item) => {
                        const Icon = item.icon;
                        const isActive = currentTab === item.id;
                        return (
                          <button
                            key={item.id}
                            onClick={() => {
                              onChangeTab(item.id);
                              setIsDrawerOpen(false);
                            }}
                            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                              isActive 
                                ? 'text-white bg-white/5 border border-white/10' 
                                : 'text-zinc-400 hover:text-zinc-200 hover:bg-white/[2%]'
                            }`}
                          >
                            <Icon className={`w-4 h-4 ${isActive ? item.color : 'text-zinc-500'}`} />
                            <span>{item.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  /* --- REGULAR USER FLOW --- */
                  <div className="space-y-5">
                    {/* Access links */}
                    <div className="space-y-1.5">
                      <p className="text-[10px] text-zinc-500 font-black px-1 mb-1 font-sans">دسترسی سریع به بخش‌ها</p>
                      {navItems.map((item) => {
                        const Icon = item.icon;
                        const isActive = currentTab === item.id;
                        return (
                          <button
                            key={item.id}
                            onClick={() => {
                              onChangeTab(item.id);
                              setIsDrawerOpen(false);
                            }}
                            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                              isActive 
                                ? 'text-white bg-white/5 border border-white/10' 
                                : 'text-zinc-400 hover:text-zinc-200 hover:bg-white/[2%]'
                            }`}
                          >
                            <Icon className={`w-4 h-4 ${isActive ? item.color : 'text-zinc-500'}`} />
                            <span>{item.label}</span>
                          </button>
                        );
                      })}
                    </div>

                    {/* Prominent Support button */}
                    <div className="pt-2 border-t border-white/5">
                      <button
                        onClick={() => {
                          onChangeTab('support');
                          setIsDrawerOpen(false);
                        }}
                        className="w-full flex items-center justify-between p-3 rounded-xl bg-[#0F0F10] border border-blue-500/20 hover:border-blue-400 text-xs font-bold text-zinc-200 transition-all group"
                      >
                        <div className="flex items-center gap-2.5">
                          <MessageSquare className="w-4 h-4 text-blue-400" />
                          <span>تیکت پشتیبانی</span>
                        </div>
                        <span className="text-[8px] bg-blue-500/10 text-blue-400 px-2 py-0.5 rounded-full font-black">پاسخگو</span>
                      </button>
                    </div>

                    {/* Stateful Luxury Notification Center */}
                    <div className="space-y-2 pt-2 border-t border-white/5">
                      <div className="flex items-center justify-between px-1 mb-1">
                        <div className="flex items-center gap-2">
                          <Bell className="w-4 h-4 text-rose-400" />
                          <span className="text-[10px] font-black text-white">بخش نوتیفیکیشن‌ها</span>
                        </div>
                        {unreadCount > 0 && (
                          <span className="text-[8px] bg-brand-red/15 text-brand-orange px-2 py-0.5 rounded-full font-black">
                            {unreadCount} جدید
                          </span>
                        )}
                      </div>

                      {/* Notifs List layout */}
                      <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                        {notifications.map((notif) => (
                          <div 
                            key={notif.id}
                            onClick={() => handleMarkSingleRead(notif.id)}
                            className={`p-3 rounded-xl border text-right space-y-1 transition-all cursor-pointer ${
                              notif.read 
                                ? 'bg-zinc-950/40 border-white/5 text-zinc-500' 
                                : 'bg-[#151517] border-brand-orange/20 text-zinc-200 hover:border-brand-orange/40'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-black">{notif.title}</span>
                              <span className="text-[8px] text-zinc-500 font-mono font-bold">{notif.date}</span>
                            </div>
                            <p className={`text-[9px] leading-relaxed ${notif.read ? 'text-zinc-600' : 'text-zinc-400 font-medium'}`}>{notif.text}</p>
                            {!notif.read && (
                              <div className="text-left pt-1">
                                <span className="text-[8px] text-brand-orange hover:underline font-bold">✓ خواندم</span>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>

                      {/* Mark all as read action triggers */}
                      {unreadCount > 0 && (
                        <button
                          onClick={handleMarkAllRead}
                          className="w-full py-2 text-center text-[9px] font-extrabold text-zinc-400 hover:text-white transition-all flex items-center justify-center gap-1 bg-white/[1.5%] hover:bg-white/[3%] rounded-lg border border-white/5"
                        >
                          <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
                          <span>علامت‌گذاری همه به عنوان خوانده‌شده</span>
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Drawer footer brand credit */}
              <div className="border-t border-white/5 pt-4 text-center space-y-1 mt-6">
                <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest font-sans">SAV CLIENT ENGINE</span>
                <p className="text-[8px] text-zinc-600">پایش لایو اینستاگرام ۲۰۲۶</p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Desktop Sidebar Navigation */}
      <nav className="fixed right-0 top-[73px] bottom-0 w-64 border-l border-white/10 bg-[#0F0F10]/95 backdrop-blur-lg pt-8 px-4 hidden md:flex flex-col justify-between pb-8 z-30">
        <div className="space-y-2">
          <p className="text-[10px] text-zinc-500 font-bold px-3 uppercase tracking-wider mb-4">منوی اصلی پلتفرم</p>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onChangeTab(item.id)}
                className={`w-full flex items-center gap-3.5 px-4 py-3.5 rounded-xl text-sm font-semibold transition-all relative ${
                  isActive 
                    ? 'text-white' 
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-white/[2%]'
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="sidebar-active"
                    className="absolute inset-0 bg-gradient-to-l from-brand-orange/5 via-brand-red/5 to-transparent border-r-2 border-brand-orange rounded-xl"
                  />
                )}
                <Icon className={`w-5 h-5 relative z-10 transition-colors ${isActive ? item.color : 'text-zinc-400'}`} />
                <span className="relative z-10">{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* System & Support Utilities */}
        <div className="space-y-1.5 pt-4 border-t border-white/5 my-3">
          <p className="text-[9px] text-zinc-550 font-bold px-3 uppercase tracking-wider mb-2">سیستم و راهنما</p>
          
          {/* Support Link */}
          <button
            onClick={() => onChangeTab('support')}
            className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
              currentTab === 'support'
                ? 'text-white bg-white/5'
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <MessageSquare className="w-4 h-4 text-blue-400" />
            <span>پشتیبانی و تیکت</span>
          </button>

          {/* Admin Link */}
          <button
            onClick={() => onChangeTab('admin')}
            className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
              currentTab === 'admin'
                ? 'text-white bg-white/5'
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>پنل مدیریت سیستم</span>
          </button>
        </div>

        {/* Editorial mini prompt */}
        <div className="p-4 rounded-xl bg-gradient-to-b from-white/[2%] to-transparent border border-white/5 text-center space-y-1.5">
          <p className="text-[11px] font-semibold text-zinc-200">کنسول شتاب‌دهنده</p>
          <p className="text-[9px] text-zinc-500 leading-normal">سامانه {copywriting?.appName || 'ساو'} مجهز به پیشرفته‌ترین موتور هوش مصنوعی بومی‌سازی شده ریلز است.</p>
        </div>
      </nav>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 h-20 bg-[#0F0F10]/95 backdrop-blur-xl border-t border-white/10 flex justify-around items-center px-4 md:hidden z-40 pb-safe-bottom">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onChangeTab(item.id)}
              className="flex flex-col items-center justify-center gap-1.5 w-16 h-14 relative"
            >
              {isActive && (
                <motion.div
                  layoutId="mobile-nav-indicator"
                  className="absolute -top-3 w-8 h-[3px] bg-gradient-to-r from-brand-orange to-brand-red rounded-full"
                />
              )}
              <Icon className={`w-5.5 h-5.5 transition-colors ${isActive ? item.color : 'text-zinc-400'}`} />
              <span className={`text-[9px] font-bold ${isActive ? 'text-white' : 'text-zinc-505'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>
    </>
  );
};
