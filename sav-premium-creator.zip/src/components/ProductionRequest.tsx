/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAppState } from '../state';
import { 
  Sparkles, 
  ArrowLeft, 
  ArrowRight, 
  Tv, 
  CheckCircle,
  HelpCircle,
  Coins,
  ShieldCheck,
  Video,
  Database,
  CalendarCheck
} from 'lucide-react';

export const ProductionRequest: React.FC = () => {
  const { addProductionRequest, productionRequests } = useAppState();

  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 6;

  // Form States
  const [contentType, setContentType] = useState('Reel');
  const [budget, setBudget] = useState(5000000); // 5 Million Toman
  const [qualityLevel, setQualityLevel] = useState('Cinematic');
  const [referenceLinks, setReferenceLinks] = useState('');
  const [jalaliDate, setJalaliDate] = useState('۱۴۰۵/۰۳/۱۸');
  const [additionalNotes, setAdditionalNotes] = useState('');
  
  // Submit complete
  const [showFinishedModal, setShowFinishedModal] = useState(false);

  const contentTypes = [
    { value: 'Reel', label: '🎬 ریلز کوتاه اکسپلورر', desc: 'مناسب رشد سریع، افزایش لید ملایم و قلاب‌های تند' },
    { value: 'Podcast', label: '🎙 پادکست ویدیویی (تجهیزات کامل)', desc: 'گفتگوهای عمیق، مباحث فلسفی کسب‌وکار با نورپردازی گرم امبینت' },
    { value: 'Commercial', label: '💎 تیزر تبلیغاتی لوکس', desc: 'باکلاس‌ترین سطح معرفی محصولات، رندرهای دالی و فریم‌های گران' },
    { value: 'Talking Head', label: '🗣 ویدیو صحبت رو به دوربین', desc: 'انتقال سریع مفاهیم، آموزش تخصصی یا بلاگری همراه با تله پرومپتر' },
    { value: 'Motion Graphics', label: '👾 موشن گرافیک سه بعدی', desc: 'تصویرسازی‌های انتزاعی تکنولوژیک، نمودارهای متحرک و فلوچارت‌های خاص' },
    { value: 'Documentary', label: '📜 مستند کوتاه برند', desc: 'بیان داستان تولد کسب‌وکار شما با موزیک سینمایی ارکسترال' }
  ];

  const qualityTiers = [
    { value: 'Basic', label: 'ساده (موبایلی)', desc: 'کیفیت بالا با آیفون ۱۵ پرو بدون نیاز به دکور پیچیده و تدوین سریع' },
    { value: 'Professional', label: 'حرفه‌ای (موبایلی + کیت نور)', desc: 'نورپردازی ۳ نقطه‌ای، میکروفون حرفه‌ای Rode، و افکت‌های صوتی ریتمیک' },
    { value: 'Cinematic', label: 'سینماتیک (دوربین SONY + گیمبال)', desc: 'عمق میدان جذاب (Bokeh)، داینامیک رنج باز، تصحیح رنگ هالیوودی و لنز پرایم' },
    { value: 'Ultra Premium', label: 'اولترا پرمیوم (رد RED/ARRI + تیم کارگردانی)', desc: 'عالی‌ترین استانداردهای برندینگ شامل بازیگر، استودیو معلق و مانیتورینگ زنده' }
  ];

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleSubmit = () => {
    addProductionRequest({
      contentType,
      budget,
      qualityLevel,
      referenceLinks,
      jalaliDate,
      additionalNotes
    });

    setShowFinishedModal(true);
    setCurrentStep(1);
    
    // Clear
    setReferenceLinks('');
    setAdditionalNotes('');
  };

  // Convert Tomans to readable million format in Persian
  const formatToman = (val: number) => {
    if (val >= 1000000) {
      return (val / 1000000).toFixed(1) + ' میلیون تومان';
    }
    return val.toLocaleString() + ' تومان';
  };

  return (
    <div className="space-y-8">
      {/* Editorial Header */}
      <div className="rounded-3xl p-6 bg-gradient-to-b from-white/[2%] to-transparent border border-white/5 space-y-3">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Tv className="w-5 h-5 text-brand-orange" />
          ثبت پروژه تولید محتوای سینمایی
        </h2>
        <p className="text-zinc-400 text-xs leading-relaxed max-w-3xl">
          می‌خواهید تولید سناریوی خود را به یک تیم فنی مجرب بسپارید؟ با پر کردن چک‌لیست زیر، کارشناسان ما یک پروپوزال دکوپاژ شده متناسب با بودجه و خواسته‌های شما تهیه کرده و جهت پیش‌تولید با شما تماس خواهند گرفت.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Multi-step form box */}
        <div className="lg:col-span-8 rounded-2xl p-6 bg-matte-black border border-white/5 space-y-6 shadow-xl relative min-h-[460px] flex flex-col justify-between">
          <div>
            {/* Step Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/5">
              <span className="text-xs font-bold text-brand-orange uppercase tracking-wider">مرحله {currentStep} از {totalSteps}</span>
              <div className="flex gap-1.5">
                {Array.from({ length: totalSteps }).map((_, idx) => (
                  <div 
                    key={idx} 
                    className={`h-1.5 rounded-full transition-all ${
                      idx + 1 <= currentStep ? 'w-6 bg-brand-orange' : 'w-2 bg-zinc-800'
                    }`} 
                  />
                ))}
              </div>
            </div>

            {/* Steps Content router */}
            <div className="mt-8">
              <AnimatePresence mode="wait">
                {currentStep === 1 && (
                  <motion.div
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 10 }}
                    className="space-y-4"
                  >
                    <h3 className="text-sm font-bold text-white">اقدام ۱. نوع محتوای مد نظر خود را انتخاب کنید</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {contentTypes.map((type) => (
                        <button
                          key={type.value}
                          onClick={() => setContentType(type.value)}
                          className={`p-4 rounded-xl text-right border transition-all ${
                            contentType === type.value 
                              ? 'bg-brand-orange/10 border-brand-orange/40 text-brand-orange shadow-md' 
                              : 'bg-white/[2%] border-white/5 text-zinc-400 hover:bg-white/[4%]'
                          }`}
                        >
                          <p className="text-xs font-bold text-white">{type.label}</p>
                          <p className="text-[10px] text-zinc-500 mt-1">{type.desc}</p>
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}

                {currentStep === 2 && (
                  <motion.div
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 10 }}
                    className="space-y-6"
                  >
                    <h3 className="text-sm font-bold text-white">اقدام ۲. محدوده بودجه تخمینی پروژه را مشخص کنید</h3>
                    
                    <div className="p-6 rounded-xl bg-zinc-950/50 border border-white/5 space-y-4 text-center">
                      <span className="text-[10px] font-bold text-zinc-500">بودجه نهایی فرضی در اختیار تولیدکننده</span>
                      <p className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-brand-orange to-brand-red font-mono py-1">
                        {formatToman(budget)}
                      </p>
                      
                      <input
                        type="range"
                        min={1000000}
                        max={50000000}
                        step={1000000}
                        value={budget}
                        onChange={(e) => setBudget(Number(e.target.value))}
                        className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-brand-orange"
                      />

                      <div className="flex justify-between text-[10px] text-zinc-650 font-bold px-1">
                        <span>۱ میلیون تومان</span>
                        <span>۲۵ میلیون</span>
                        <span>۵۰ میلیون تومان</span>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-orange-500/5 border border-brand-orange/20 text-[11px] text-brand-orange/80 leading-relaxed">
                      💡 راهنمایی: بودجه‌های بالای ۵ میلیون تومان امکان بهره‌گیری از نورپردازی و کیت‌های امبینت حرفه‌ای آکادمی ساو را فراهم می‌کنند.
                    </div>
                  </motion.div>
                )}

                {currentStep === 3 && (
                  <motion.div
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 10 }}
                    className="space-y-4"
                  >
                    <h3 className="text-sm font-bold text-white">اقدام ۳. سطح کیفیتی دوربین و تصویربرداری را تایید کنید</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {qualityTiers.map((tier) => (
                        <button
                          key={tier.value}
                          onClick={() => setQualityLevel(tier.value)}
                          className={`p-4 rounded-xl text-right border transition-all ${
                            qualityLevel === tier.value 
                              ? 'bg-brand-orange/10 border-brand-orange/40 text-brand-orange shadow-md' 
                              : 'bg-white/[2%] border-white/5 text-zinc-400 hover:bg-white/[4%]'
                          }`}
                        >
                          <p className="text-xs font-bold text-white">{tier.label}</p>
                          <p className="text-[10px] text-zinc-500 mt-1">{tier.desc}</p>
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}

                {currentStep === 4 && (
                  <motion.div
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 10 }}
                    className="space-y-4"
                  >
                    <h3 className="text-sm font-bold text-white">اقدام ۴. لینک نمونه کارهای رفرنس (الهام بخش) را بفرستید</h3>
                    <div className="space-y-2">
                      <label className="text-[10px] text-zinc-500">لینک ویدیوهای ریلز یا تیزرهایی که ریتم آنها را دوست دارید</label>
                      <textarea
                        value={referenceLinks}
                        onChange={(e) => setReferenceLinks(e.target.value)}
                        placeholder="آدرس ریلز فلان کریتور خارجی، آدرس پینترست فلان تم، یا هر نمونه فایل فشرده..."
                        rows={4}
                        className="w-full p-4 rounded-xl bg-white/[3%] border border-white/10 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-brand-orange/50 focus:ring-1 focus:ring-brand-orange/35 resize-none"
                      />
                    </div>
                  </motion.div>
                )}

                {currentStep === 5 && (
                  <motion.div
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 10 }}
                    className="space-y-4"
                  >
                    <h3 className="text-sm font-bold text-white">اقدام ۵. تاریخ پيشنهادی تصویربرداری (تقویم جلالی)</h3>
                    <div className="space-y-2">
                      <label className="text-[10px] text-zinc-500">تاریخ مد نظر را بنویسید</label>
                      <input
                        type="text"
                        value={jalaliDate}
                        onChange={(e) => setJalaliDate(e.target.value)}
                        placeholder="مثلا: ۱۴۰۵/۰۳/۱۸"
                        className="w-full px-4 py-3 rounded-xl bg-white/[3%] border border-white/10 text-xs text-white placeholder-zinc-650 focus:outline-none focus:border-brand-orange/40 transition-all font-mono"
                      />
                      <p className="text-[10px] text-zinc-500">معمولا هماهنگی تجهیزات و عوامل صحنه نیاز به حداقل ۴ روز برنامه‌ریزی از زمان سفارش دارد.</p>
                    </div>
                  </motion.div>
                )}

                {currentStep === 6 && (
                  <motion.div
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 10 }}
                    className="space-y-4"
                  >
                    <h3 className="text-sm font-bold text-white">اقدام ۶. یادداشت‌های نهایی و خلاصه سناریو</h3>
                    <div className="space-y-2">
                      <label className="text-[10px] text-zinc-500">توضیحات تکمیلی برای کارگردان هنری ساو</label>
                      <textarea
                        value={additionalNotes}
                        onChange={(e) => setAdditionalNotes(e.target.value)}
                        placeholder="تعداد لباس‌ها، لوکال‌های در دسترس، ساعت فیلمبرداری مورد علاقه و خواسته‌های فنی خاص..."
                        rows={4}
                        className="w-full p-4 rounded-xl bg-white/[3%] border border-white/10 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-brand-orange/50 focus:ring-1 focus:ring-brand-orange/35 resize-none"
                      />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Wizard Actions Footer */}
          <div className="flex items-center justify-between border-t border-white/5 pt-6 mt-8">
            <button
              disabled={currentStep === 1}
              onClick={handlePrev}
              type="button"
              className="px-4 py-2.5 rounded-xl bg-zinc-900 border border-white/5 hover:border-white/10 text-zinc-300 text-xs font-bold transition-all disabled:opacity-30 inline-flex items-center gap-1.5"
            >
              <ArrowRight className="w-3.5 h-3.5" />
              <span>مرحله قبلی</span>
            </button>

            {currentStep < totalSteps ? (
              <button
                onClick={handleNext}
                type="button"
                className="px-5 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-750 text-white text-xs font-extrabold transition-all inline-flex items-center gap-1.5"
              >
                <span>ادامه روند خلاق</span>
                <ArrowLeft className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                type="button"
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-brand-orange to-brand-red text-white text-xs font-black transition-all inline-flex items-center gap-1.5 shadow-lg shadow-brand-orange/15"
              >
                <span>ثبت نهایی سفارش و پرداخت بیعانه</span>
                <CheckCircle className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Dynamic tracker state sidebar */}
        <div className="lg:col-span-4 rounded-2xl p-6 bg-matte-black border border-white/5 space-y-5 shadow-xl">
          <h3 className="text-sm font-bold text-white flex items-center gap-2 pb-3 border-b border-white/5">
            <span className="w-1.5 h-1.5 rounded-full bg-zinc-400" />
            وضعیت پروژه در خردیداران ساو
          </h3>

          {productionRequests.length === 0 ? (
            <div className="text-center py-12 text-zinc-500 text-[11px] leading-relaxed">
              هنوز هیچ سفارش تصویربرداری ثبت نکرده‌اید. فرم سمت راست را پر کنید تا پروژه شما در سیستم آرشیو شود.
            </div>
          ) : (
            <div className="space-y-4">
              <span className="text-[10px] text-zinc-500 font-bold block">سفارشات تولید فعال من:</span>
              <div className="space-y-3">
                {productionRequests.map((req) => (
                  <div key={req.id} className="p-3.5 rounded-xl bg-white/[1.5%] border border-white/5 text-xs space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white text-xs">نوع: {req.contentType}</span>
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                        req.status === 'received' 
                          ? 'bg-amber-400/15 text-amber-400' 
                          : req.status === 'contacted'
                          ? 'bg-blue-500/15 text-blue-400'
                          : 'bg-green-500/15 text-green-400'
                      }`}>
                        {req.status === 'received' ? 'ارسال شده' : req.status === 'contacted' ? 'تماس گرفته شد' : 'قرارداد نهایی'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 text-[10px] text-zinc-400 gap-1 pt-1.5 border-t border-white/[2%]">
                      <span>بودجه فرضی:</span>
                      <span className="text-left font-mono font-bold text-white">{formatToman(req.budget)}</span>
                      <span>تاریخ قرار:</span>
                      <span className="text-left font-mono font-bold text-amber-300">{req.jalaliDate}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="p-4 rounded-xl bg-zinc-950 border border-white/5 space-y-2">
            <span className="text-[10px] font-bold text-zinc-400 block">پشتیبان متعهد پروژه ساو:</span>
            <p className="text-[10px] text-zinc-500 leading-relaxed">
              بلافاصله پس از پرداخت بیعانه، مربی ارشد و فوتودایرکتور ساو سناریوهای شما را مطالعه کرده و جهت تنظیم دکوپاژ نهایی و پلتفرم دکور با شما تماس خواهند گرفت.
            </p>
          </div>
        </div>
      </div>

      {/* Finished Modal overlay */}
      <AnimatePresence>
        {showFinishedModal && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-zinc-900 border border-white/10 rounded-3xl p-8 max-w-md w-full text-center space-y-6 shadow-2xl"
            >
              <div className="w-16 h-16 rounded-3xl bg-brand-orange/10 border border-brand-orange/25 mx-auto flex items-center justify-center text-brand-orange shadow-lg">
                <CheckCircle className="w-8 h-8" />
              </div>

              <div className="space-y-2">
                <h3 className="text-xl font-bold text-white">پروژه تولید با موفقیت ثبت شد!</h3>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  سفارش شما در اتاق تولید مربیان ساو ثبت شد و یک تراکنش خودکار بابت پرداخت بیعانه ۱۲ درصدی در پالس حسابداری شما تایید گردید. کارشناسان استودیو طی ۴۸ ساعت آینده با شما تماس خواهند گرفت.
                </p>
              </div>

              <button
                onClick={() => setShowFinishedModal(false)}
                type="button"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-brand-orange to-brand-red text-white text-xs font-black transition-all"
              >
                برگشت به پلتفرم
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
