/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAppState } from '../state';
import { WordProcessor } from './WordProcessor';
import { 
  ShieldCheck, 
  Settings2, 
  LayoutGrid, 
  BookOpen, 
  FileText, 
  DollarSign, 
  PlusCircle, 
  CheckCircle, 
  AlertCircle,
  TrendingUp,
  Sliders,
  Trash2,
  Users,
  Video,
  Eye,
  Settings,
  Flame,
  Search,
  Check,
  Smartphone,
  Send,
  MessageSquare,
  Bot,
  Zap,
  Lock,
  ArrowUpDown,
  ExternalLink,
  Percent,
  RefreshCw,
  Bell,
  Upload,
  Link,
  Clock,
  ChevronRight,
  ChevronLeft,
  Edit2,
  Save,
  Sparkles
} from 'lucide-react';

export const AdminPanel: React.FC = () => {
  const { 
    scenarios, 
    consultations, 
    productionRequests, 
    courses, 
    templates, 
    blogPosts, 
    payments, 
    settings,
    
    currentUser,
    usersList,
    tickets,
    homeSections,
    pushCampaigns,
    
    updateUserStatus,
    updateUserSubscription,
    addTicketMessage,
    updateTicketStatus,
    updateHomeSections,
    addPushCampaign,
    sendPushCampaignImmediately,
    
    submitExpertFeedback,
    updateProductionStatus,
    addTemplate,
    deleteTemplate,
    addBlogPost,
    editBlogPost,
    deleteBlogPost,
    addCourse,
    editCourse,
    addLessonToCourse,
    deleteLessonFromCourse,
    deleteCourse,
    updateSettings,
    copywriting,
    updateCopywriting,
    
    inspirationVideos,
    inspirationCategories,
    addInspirationVideo,
    updateInspirationVideo,
    deleteInspirationVideo,
    addInspirationCategory
  } = useAppState();

  const [activeAdminSubTab, setActiveAdminSubTab] = useState<'hub' | 'stats' | 'builder' | 'reviews' | 'tele_bot' | 'gemini' | 'users' | 'notifications' | 'gateways' | 'cms'>('hub');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  // CMS active sub-tab switching: Course management vs Blog Posts vs Templates
  const [cmsTab, setCmsTab] = useState<'templates' | 'courses' | 'articles' | 'inspirations'>('courses');

  // Selected course to manage its lessons and modules
  const [selectedCourseId, setSelectedCourseId] = useState<string>('');

  // Input states for templates addition
  const [newTplTitle, setNewTplTitle] = useState('');
  const [appTitleInput, setAppTitleInput] = useState(copywriting?.appName || 'ساو');

  useEffect(() => {
    if (copywriting?.appName) {
      setAppTitleInput(copywriting.appName);
    }
  }, [copywriting?.appName]);

  const [newTplCategory, setNewTplCategory] = useState('بلاگری شخصی');
  const [newTplPrompt, setNewTplPrompt] = useState('');
  const [newTplStyle, setNewTplStyle] = useState('سینماتیک و لوکس');
  const [tplWizardStep, setTplWizardStep] = useState(1);

  // Input states for managing Inspiration Videos
  const [newInspTitle, setNewInspTitle] = useState('');
  const [newInspVideoUrl, setNewInspVideoUrl] = useState('');
  const [newInspTranscript, setNewInspTranscript] = useState('');
  const [newInspScenario, setNewInspScenario] = useState('');
  const [newInspCategory, setNewInspCategory] = useState('بلاگری');
  const [newInspIsPinned, setNewInspIsPinned] = useState(false);
  const [newInspCustomCategory, setNewInspCustomCategory] = useState('');
  const [editingInspId, setEditingInspId] = useState<string | null>(null);

  // Input states for course addition
  const [newCourseTitle, setNewCourseTitle] = useState('');
  const [newCourseDesc, setNewCourseDesc] = useState(''); // Stores rich detail from Course WordProcessor
  const [newCoursePrice, setNewCoursePrice] = useState(2900000);
  const [newCourseCategory, setNewCourseCategory] = useState('سناریونویسی');
  const [newCourseImage, setNewCourseImage] = useState('https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&w=400&q=80');

  // Input states for managing lessons of selected course
  const [newLessonTitle, setNewLessonTitle] = useState('');
  const [newLessonContentType, setNewLessonContentType] = useState<'video' | 'text' | 'both'>('video');
  const [newLessonVideoUrl, setNewLessonVideoUrl] = useState('');
  const [newLessonDuration, setNewLessonDuration] = useState('12:00');
  const [newLessonSummary, setNewLessonSummary] = useState(''); // Stores the short bulleted or coded summary
  const [newLessonRichContent, setNewLessonRichContent] = useState(''); // Written with rich WordProcessor!
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadFileName, setUploadFileName] = useState('');

  // Input states for Blog posting
  const [newBlogTitle, setNewBlogTitle] = useState('');
  const [newBlogCategory, setNewBlogCategory] = useState('الگوریتم رشد');
  const [newBlogContent, setNewBlogContent] = useState(''); // Written with rich WordProcessor!
  const [newBlogSeo, setNewBlogSeo] = useState('');
  const [newBlogKeywords, setNewBlogKeywords] = useState('');
  const [newBlogVideoUrl, setNewBlogVideoUrl] = useState('');

  // Sourced Multi-Step Wizard and Edit functionality states
  const [courseWizardStep, setCourseWizardStep] = useState<number>(1);
  const [editingCourseId, setEditingCourseId] = useState<string | null>(null);
  const [newCourseLevel, setNewCourseLevel] = useState<string>('متوسط');
  const [newCourseDurationHours, setNewCourseDurationHours] = useState<string>('۱۰ ساعت');
  const [newCourseStatus, setNewCourseStatus] = useState<'draft' | 'published'>('published');
  const [newCourseSeoTitle, setNewCourseSeoTitle] = useState<string>('');
  const [newCourseSeoDesc, setNewCourseSeoDesc] = useState<string>('');
  const [newCourseTags, setNewCourseTags] = useState<string>('دکوپاژ, ریلز, ادیت, رشد');
  const [newCourseFeatured, setNewCourseFeatured] = useState<boolean>(true);
  const [tempLessons, setTempLessons] = useState<any[]>([]);

  const [articleWizardStep, setArticleWizardStep] = useState<number>(1);
  const [editingBlogId, setEditingBlogId] = useState<string | null>(null);
  const [newBlogStatus, setNewBlogStatus] = useState<'draft' | 'published' | 'scheduled'>('published');

  // Reviews and tickets state
  const [underReviewScenarioId, setUnderReviewScenarioId] = useState<string | null>(null);
  const [expertNoteInput, setExpertNoteInput] = useState('');
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const [ticketReplyText, setTicketReplyText] = useState('');

  // Page Builder States
  const [editingSectionId, setEditingSectionId] = useState<string | null>(null);
  const [editingSecTitle, setEditingSecTitle] = useState('');
  const [editingSecSub, setEditingSecSub] = useState('');

  // Telegram Wizard States
  const [telegramWizardStep, setTelegramWizardStep] = useState<1 | 2 | 3>(1);
  const [tgTempToken, setTgTempToken] = useState(settings.telegramToken || '');
  const [tgTempBot, setTgTempBot] = useState(settings.telegramBotName || '');
  const [tgTesting, setTgTesting] = useState(false);
  const [tgTestSuccess, setTgTestSuccess] = useState(false);

  // Gemini Setup States
  const [gemKeyTemp, setGemKeyTemp] = useState(settings.geminiApiKey || '');
  const [gemBackupTemp, setGemBackupTemp] = useState(settings.geminiBackupKey || '');

  // Users Filter States
  const [userSearchText, setUserSearchText] = useState('');
  const [userFilterRole, setUserFilterRole] = useState<'all' | 'guest' | 'registered' | 'premium' | 'suspended'>('all');
  const [drilledUserId, setDrilledUserId] = useState<string | null>(null);

  // Push Notifications States
  const [pushTitle, setPushTitle] = useState('');
  const [pushDesc, setPushDesc] = useState('');
  const [pushSeg, setPushSeg] = useState<'all' | 'guest' | 'premium'>('all');
  const [pushTriggerMock, setPushTriggerMock] = useState<any>(null);

  // Gateways Config States
  const [couponCode, setCouponCode] = useState('');
  const [couponPercent, setCouponPercent] = useState(25);
  const [activeCoupons, setActiveCoupons] = useState<{code: string, pct: number, active: boolean}[]>([
    { code: 'SAVNEW', pct: 15, active: true },
    { code: 'AX_SAV_OFF', pct: 30, active: true }
  ]);

  // Submit Template Handler
  const handleCreateTemplate = () => {
    if (!newTplTitle.trim() || !newTplPrompt.trim()) return;
    addTemplate({
      title: newTplTitle,
      category: newTplCategory,
      prompt: newTplPrompt,
      aiStyle: newTplStyle
    });
    setNewTplTitle('');
    setNewTplPrompt('');
  };

  // Submit/Update Course handler
  const handleCreateCourse = () => {
    if (!newCourseTitle.trim()) return;

    const courseData = {
      title: newCourseTitle,
      description: newCourseDesc,
      price: newCoursePrice,
      category: newCourseCategory,
      image: newCourseImage,
      isPremium: newCourseStatus === 'published'
    };

    if (editingCourseId) {
      editCourse(editingCourseId, courseData);
      setEditingCourseId(null);
    } else {
      addCourse(courseData);
    }

    // Reset full state
    setNewCourseTitle('');
    setNewCourseDesc('');
    setNewCoursePrice(2900000);
    setNewCourseCategory('سناریونویسی');
    setNewCourseImage('https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&w=400&q=80');
    setNewCourseLevel('متوسط');
    setNewCourseDurationHours('۱۰ ساعت');
    setNewCourseStatus('published');
    setNewCourseSeoTitle('');
    setNewCourseSeoDesc('');
    setNewCourseTags('دکوپاژ, ریلز, ادیت, رشد');
    setNewCourseFeatured(true);
    setCourseWizardStep(1);
    alert('✓ دوره آموزشی با موفقیت ذخیره شد.');
  };

  const handleSaveCourseDraft = () => {
    const courseData = {
      title: newCourseTitle || 'پیش‌نویس جدید دوره ساو',
      description: newCourseDesc,
      price: newCoursePrice,
      category: newCourseCategory,
      image: newCourseImage,
      isPremium: false
    };

    if (editingCourseId) {
      editCourse(editingCourseId, courseData);
    } else {
      // Simulate adding as draft, adding with unique ID
      addCourse(courseData);
    }
    alert('✓ پیش‌نویس دوره ساو با موفقیت به صورت محرمانه ذخیره شد.');
  };

  const handleCancelCourseEdit = () => {
    setEditingCourseId(null);
    setNewCourseTitle('');
    setNewCourseDesc('');
    setNewCoursePrice(2900000);
    setNewCourseCategory('سناریونویسی');
    setNewCourseImage('https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&w=400&q=80');
    setNewCourseLevel('متوسط');
    setNewCourseDurationHours('۱۰ ساعت');
    setNewCourseStatus('published');
    setNewCourseSeoTitle('');
    setNewCourseSeoDesc('');
    setNewCourseTags('دکوپاژ, ریلز, ادیت, رشد');
    setNewCourseFeatured(true);
    setCourseWizardStep(1);
    setTempLessons([]);
  };

  // Submit/Update Blog Handler
  const handleCreateBlog = () => {
    if (!newBlogTitle.trim() || !newBlogContent.trim()) return;

    const blogData = {
      title: newBlogTitle,
      category: newBlogCategory,
      content: newBlogContent,
      scheduledDate: new Date().toLocaleDateString('fa-IR'),
      seoTitle: newBlogSeo,
      seoKeywords: newBlogKeywords,
      videoUrl: newBlogVideoUrl,
      status: newBlogStatus
    };

    if (editingBlogId) {
      editBlogPost(editingBlogId, blogData);
      setEditingBlogId(null);
    } else {
      addBlogPost(blogData);
    }

    setNewBlogTitle('');
    setNewBlogContent('');
    setNewBlogSeo('');
    setNewBlogKeywords('');
    setNewBlogVideoUrl('');
    setNewBlogStatus('published');
    setArticleWizardStep(1);
    alert('✓ مقاله علمی با موفقیت ذخیره شد.');
  };

  const handleSaveBlogDraft = () => {
    const blogData = {
      title: newBlogTitle || 'پیش‌نویس جدید مقاله علمی',
      category: newBlogCategory,
      content: newBlogContent,
      scheduledDate: new Date().toLocaleDateString('fa-IR'),
      seoTitle: newBlogSeo,
      seoKeywords: newBlogKeywords,
      videoUrl: newBlogVideoUrl,
      status: 'draft' as const
    };

    if (editingBlogId) {
      editBlogPost(editingBlogId, blogData);
    } else {
      addBlogPost(blogData);
    }
    alert('✓ پیش‌نویس مقاله علمی با موفقیت ذخیره شد.');
  };

  // Submit Lesson/Lecture to a selected course
  const handleCreateLesson = () => {
    const courseId = selectedCourseId || (courses[0]?.id || '');
    if (!courseId) {
      alert('لطفا ابتدا یک دوره انتخاب کنید یا بسازید.');
      return;
    }
    if (!newLessonTitle.trim()) {
      alert('عنوان قسمت اجباری است.');
      return;
    }

    addLessonToCourse(courseId, {
      title: newLessonTitle,
      videoUrl: newLessonVideoUrl || 'https://assets.mixkit.co/videos/preview/mixkit-typing-on-a-glowing-neon-keyboard-41712-large.mp4',
      duration: newLessonDuration || '10:00',
      summary: newLessonSummary || 'توضیحات کوتاه ضبط شده با هوش مصنوعی ساو.',
      contentType: newLessonContentType,
      richContent: newLessonRichContent
    });

    // Reset fields
    setNewLessonTitle('');
    setNewLessonVideoUrl('');
    setNewLessonDuration('12:00');
    setNewLessonSummary('');
    setNewLessonRichContent('');
    setUploadFileName('');
    setUploadProgress(0);
    alert('✓ قسمت جدید با موفقیت به مسترکلاس اضافه شد.');
  };

  const handleVideoUploadSimulate = (fileName: string) => {
    setIsUploading(true);
    setUploadFileName(fileName);
    setUploadProgress(10);
    
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          // Set a cool mock video URL
          setNewLessonVideoUrl('https://assets.mixkit.co/videos/preview/mixkit-set-of-cinematic-shutter-screens-43093-large.mp4');
          return 100;
        }
        return prev + 30;
      });
    }, 250);
  };

  // Submit expert review answers
  const handleExpertAnswer = (id: string) => {
    submitExpertFeedback(id, 'completed', expertNoteInput);
    setUnderReviewScenarioId(null);
    setExpertNoteInput('');
  };

  // Reply ticket admin-side
  const handleTicketAdminReply = () => {
    if (!ticketReplyText.trim() || !selectedTicketId) return;
    addTicketMessage(selectedTicketId, ticketReplyText, 'admin');
    setTicketReplyText('');
  };

  // Move page section Up/Down
  const moveSectionOrder = (id: string, direction: 'up' | 'down') => {
    const idx = homeSections.findIndex(s => s.id === id);
    if (idx === -1) return;
    const newIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (newIdx < 0 || newIdx >= homeSections.length) return;

    const updated = [...homeSections];
    const temp = updated[idx];
    updated[idx] = updated[newIdx];
    updated[newIdx] = temp;

    // re-assign sequential orders
    const fullyUpdated = updated.map((item, index) => ({
      ...item,
      order: index + 1
    }));
    updateHomeSections(fullyUpdated);
  };

  // Save specific section block title/subtitle
  const handleSaveSectionEdit = () => {
    if (!editingSectionId) return;
    const updated = homeSections.map(s => {
      if (s.id === editingSectionId) {
        return { ...s, title: editingSecTitle, subtitle: editingSecSub };
      }
      return s;
    });
    updateHomeSections(updated);
    setEditingSectionId(null);
  };

  // Re-trigger visual validation for Telegram credentials
  const handleTestTelegramConnection = () => {
    setTgTesting(true);
    setTgTestSuccess(false);
    setTimeout(() => {
      setTgTesting(false);
      setTgTestSuccess(true);
      updateSettings({
        telegramToken: tgTempToken,
        telegramBotName: tgTempBot,
        telegramStatus: 'connected'
      });
    }, 1800);
  };

  // Apply visual settings keys
  const handleSaveGeminiKeys = () => {
    updateSettings({
      geminiApiKey: gemKeyTemp,
      geminiBackupKey: gemBackupTemp
    });
  };

  // Push campaigns dispatch
  const handleDispatchPush = () => {
    if (!pushTitle.trim() || !pushDesc.trim()) return;
    addPushCampaign({
      title: pushTitle,
      description: pushDesc,
      segment: pushSeg
    });

    const mockObj = {
      title: pushTitle,
      description: pushDesc,
      time: 'هم‌اکنون'
    };
    setPushTriggerMock(mockObj);
    setPushTitle('');
    setPushDesc('');

    // Clear simulation overlay in 5 seconds
    setTimeout(() => {
      setPushTriggerMock(null);
    }, 5000);
  };

  // Coupon submission
  const handleAddCoupon = () => {
    if (!couponCode.trim()) return;
    setActiveCoupons(prev => [
      ...prev,
      { code: couponCode.toUpperCase(), pct: couponPercent, active: true }
    ]);
    setCouponCode('');
  };

  // Toggle active coupon status
  const toggleCoupon = (code: string) => {
    setActiveCoupons(prev => prev.map(c => c.code === code ? { ...c, active: !c.active } : c));
  };

  // Statistics summaries
  const totalRevenue = payments
    .filter(p => p.status === 'successful')
    .reduce((sum, current) => sum + current.amount, 0);

  const formatToman = (val: number) => {
    return (val / 1000000).toFixed(1) + ' میلیون تومان';
  };

  // Users listing filtering logic
  const filteredUsers = usersList.filter(u => {
    const textMatch = 
      u.name.toLowerCase().includes(userSearchText.toLowerCase()) ||
      u.phone.includes(userSearchText) ||
      u.email.toLowerCase().includes(userSearchText.toLowerCase());

    if (!textMatch) return false;

    if (userFilterRole === 'all') return true;
    if (userFilterRole === 'guest') return u.isGuest;
    if (userFilterRole === 'registered') return !u.isGuest && !u.isPremium;
    if (userFilterRole === 'premium') return u.isPremium;
    if (userFilterRole === 'suspended') return u.status === 'suspended';
    return true;
  });

  const subPageNames: Record<string, { title: string; category: string; description: string; icon: any }> = {
    stats: {
      title: 'مانیتورینگ عمومی و تحلیل تراکنش‌ها',
      category: 'نظارت مالی',
      description: 'تحلیل آنی ترافیک تولید سناریو کلاکی، دریافتی‌های زرین‌پال و عملکرد فروش مسترکلاس‌ها',
      icon: TrendingUp
    },
    builder: {
      title: 'ویرایشگر چیدمان و صفحه‌ساز ماژولار',
      category: 'طراحی بصری',
      description: 'فعال‌سازی، تغییر ترتیب و ویرایش لحظه‌ای بلاک‌های فریمورک صفحه نخست ساو بدون کدنویسی',
      icon: LayoutGrid
    },
    reviews: {
      title: 'پیشخوان نقد مربیان و تیکت‌های پشتیبانی',
      category: 'ارتباطات',
      description: 'بررسی رکوردهای دکوپاژ در صف، تیکت‌های شکایات و پاسخ‌دهی لایو به دغدغه سازندگان',
      icon: MessageSquare
    },
    tele_bot: {
      title: 'راه‌اندازی اتومیشن و ربات اختصاصی تلگرام',
      category: 'اتصالات هوشمند',
      description: 'تنظیم وب‌هوک و اتصال توکن تلگرام جهت دیسپچ مستقیم رول آفیش فیلبرداری تهران به تیم ادمین',
      icon: Bot
    },
    gemini: {
      title: 'مرکز مغز هوش مصنوعی Clock AI',
      category: 'هوش مصنوعی مستقل',
      description: 'مدیریت کلیدهای اصلی و بک‌آپ گوگل جمینی لایو جهت استمرار سیستم سناریونویسی و کپشن‌ها',
      icon: Zap
    },
    users: {
      title: 'آنالیز ترافیک و فهرست اعضای ساو',
      category: 'پایگاه داده',
      description: 'کنترل کامل پرونده سازندگان، اعمال تعلیق یا مسدودسازی، ارتقا به اعضای رایگان به پلن ویژه ساو طلایی',
      icon: Users
    },
    notifications: {
      title: 'سیستم پرتاب نوتیفیکیشن همگانی',
      category: 'بازاریابی و وب‌هوش',
      description: 'ایجاد، زمان‌بندی و دیسپچ آنی اعلان‌های متحرک لایو روی شبیه‌ساز آیفون به هنرجویان ساو',
      icon: Bell
    },
    gateways: {
      title: 'پیکربندی درگاه‌های بانکی و کدهای تخفیف',
      category: 'مالی و مارکتینگ',
      description: 'تنظیم مرچنت‌آیدی زرین‌پال، استرایپ جهانی و صدور کوپن‌های دارای درصد تخفیف عضویت VIP',
      icon: DollarSign
    },
    cms: {
      title: 'بخش مدیریت محتوا (CMS) کاتالوگ',
      category: 'فروشگاه محتوا',
      description: 'افزودن قالب‌های دکوپاژ، انتشار مسترکلاس‌های آکادمی و مدیریت فایل‌های صوتی دپارتمان تالیف',
      icon: Sliders
    }
  };

  const subPages = [
    {
      id: 'stats',
      label: '📊 مانیتورینگ عمومی و مالی',
      desc: 'نگاه ۳۶۰ درجه به سیستم سناریونویسی، درآمدهای زرین‌پال، آمار پروژه‌ها و ترافیک در لحظه',
      icon: TrendingUp,
      badge: 'مشاهده لایو گراف',
      stats: formatToman(totalRevenue),
      statsLabel: 'تراکنش‌های تایید شده',
      color: 'border-emerald-500/10 hover:border-emerald-500/30 shadow-[0_0_20px_rgba(16,185,129,0.03)]'
    },
    {
      id: 'builder',
      label: '🧱 صفحه‌ساز ماژولار خانه',
      desc: 'کنترل کامل بلاک‌های صفحه اصلی پلتفرم، تغییر ترتیبات چیدمان، ویرایش عناوین و متن‌ها',
      icon: LayoutGrid,
      badge: 'طراحی پویا',
      stats: `${homeSections.length} ماژول فعال`,
      statsLabel: 'چیدمان لایو خانه',
      color: 'border-brand-orange/10 hover:border-brand-orange/30 shadow-[0_0_20px_rgba(255,87,34,0.03)]'
    },
    {
      id: 'reviews',
      label: '💬 پیشخوان نقد و تیکت‌ها',
      desc: 'پاسخگویی به سوالات کریتورها، ارائه فیدبک حرفه‌ای دکوپاژ روی سناریوها و مدیریت تیکت‌ها',
      icon: MessageSquare,
      badge: `${tickets.filter(t => t.status === 'open').length} تیکت جدید`,
      stats: `${tickets.length} پرونده پشتیبانی`,
      statsLabel: 'وضعیت تیکت‌های ساو',
      color: 'border-indigo-500/10 hover:border-indigo-500/30 shadow-[0_0_20px_rgba(99,102,241,0.03)]'
    },
    {
      id: 'tele_bot',
      label: '🤖 ربات اختصاصی تلگرام',
      desc: 'پیکربندی توکن بات، شبیه‌ساز اتومیشن ویس و اعلان‌های هماهنگی مستقیم آفیش‌ها',
      icon: Bot,
      badge: settings.telegramStatus === 'connected' ? 'ربات متصل' : 'بدون اتصال',
      stats: settings.telegramBotName ? `@${settings.telegramBotName}` : 'ثبت نشده',
      statsLabel: 'وب‌هوک تلگرام',
      color: 'border-blue-500/10 hover:border-blue-500/30 shadow-[0_0_20px_rgba(59,130,246,0.03)]'
    },
    {
      id: 'gemini',
      label: '🧠 مرکز مغز هوشمند Clock AI',
      desc: 'تعبیه API Key اصلی و زاپاس سرویس مدل‌های هوشمند کلاک ۳.۵ و کنترل استمرار هوش پلتفرم',
      icon: Zap,
      badge: settings.geminiApiKey ? 'دارای کلید فعال' : 'کمبود وب‌سرویس',
      stats: 'Gemini 2.5 Flash',
      statsLabel: 'مدل مغز پردازشگر کلاک',
      color: 'border-purple-500/10 hover:border-purple-500/30 shadow-[0_0_20px_rgba(168,85,247,0.03)]'
    },
    {
      id: 'users',
      label: '👥 اعضا و آنالیز ترافیک',
      desc: 'مدیریت کاربران، کارهای تعلیقی، گزارش سناریوها و ارتقای اعضای رایگان به پلن ویژه ساو طلایی',
      icon: Users,
      badge: `${usersList.filter(u => u.isPremium).length} VIP`,
      stats: `${usersList.length} کریتور`,
      statsLabel: 'اعضای ثبت شده',
      color: 'border-teal-500/10 hover:border-teal-500/30 shadow-[0_0_20px_rgba(20,184,166,0.03)]'
    },
    {
      id: 'notifications',
      label: '🔔 نوتیفیکیشن همگانی وب',
      desc: 'دیسپچ کردن کمپین‌های پوش نوتیفیکیشن برای کاربران و مشاهده آنی روی شبیه‌ساز آیفون ۱۵',
      icon: Bell,
      badge: 'پیش‌نمایش زنده',
      stats: `${pushCampaigns.length} اعلان`,
      statsLabel: 'کمپین‌های موفق دیسپچ',
      color: 'border-rose-500/10 hover:border-rose-500/30 shadow-[0_0_20px_rgba(239,68,68,0.03)]'
    },
    {
      id: 'gateways',
      label: '💳 درگاه‌ها و کوپن‌های تخفیف',
      desc: 'سوئیچ بر روی زرین‌پال، استرایپ جهانی، تعیین کدهای مرچنت و ثبت تخفیفات حق عضویت',
      icon: DollarSign,
      badge: 'شبیه‌ساز هوشمند شتاب',
      stats: `${activeCoupons.filter(c => c.active).length} کوپن معتبر`,
      statsLabel: 'بازاریابی و مدیریت مالی',
      color: 'border-yellow-500/10 hover:border-yellow-500/30 shadow-[0_0_20px_rgba(234,179,8,0.03)]'
    },
    {
      id: 'cms',
      label: '🎬 کاتالوگ و گالری CMS ساو',
      desc: 'بارگذاری قالب‌های آماده سناریونویسی و انتشار دوره‌ها، فیلم‌ها و مسترکلاس‌های پولی آکادمی',
      icon: Sliders,
      badge: 'مدیریت دارایی‌ها',
      stats: `${courses.length} دوره فعال`,
      statsLabel: 'دیتابیس آکادمی ساو',
      color: 'border-pink-500/10 hover:border-pink-500/30 shadow-[0_0_20px_rgba(236,72,153,0.03)]'
    }
  ];

  return (
    <div className="space-y-8 pb-16 text-right" dir="rtl">
      
      {/* Floating Push Notification Preview Mock */}
      <AnimatePresence>
        {pushTriggerMock && (
          <motion.div
            initial={{ opacity: 0, y: -80, scale: 0.9 }}
            animate={{ opacity: 1, y: 16, scale: 1 }}
            exit={{ opacity: 0, y: -80 }}
            className="fixed top-4 left-4 right-4 md:left-auto md:right-4 z-50 md:w-80 p-4 rounded-2xl bg-zinc-950/95 border border-brand-orange/30 shadow-[0_0_30px_rgba(255,87,34,0.3)] backdrop-blur-md text-right font-sans"
          >
            <div className="flex gap-3">
              <div className="w-10 h-10 rounded-xl bg-brand-orange/15 border border-brand-orange/30 flex items-center justify-center shrink-0">
                <Bell className="w-5 h-5 text-brand-orange animate-bounce" />
              </div>
              <div className="flex-1 min-w-0 space-y-1">
                <div className="flex justify-between items-center text-[9px] text-zinc-550 font-mono">
                  <span>ساو • ریلز لوکس</span>
                  <span>{pushTriggerMock.time}</span>
                </div>
                <h4 className="text-xs font-black text-white">{pushTriggerMock.title}</h4>
                <p className="text-[10px] text-zinc-400 leading-relaxed font-medium">{pushTriggerMock.description}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Dynamic Hub or Standalone Pages layout structure */}
      {activeAdminSubTab === 'hub' ? (
        /* Executive Control Room Hub View */
        <div className="space-y-8 animate-fade-in">
          {/* Master Board Header */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-6 border-b border-white/5">
            <div>
              <h2 className="text-2xl font-black text-white flex items-center gap-2">
                <ShieldCheck className="w-6 h-6 text-brand-orange animate-pulse" />
                مرکز پیشخوان مدیریت کلان ساو (SAV Studio Hub)
              </h2>
              <p className="text-zinc-400 text-xs mt-1 font-semibold">کنترل همه‌جانبه: مدیریت لایو درگاه‌ها، ویس فرستنده تلگرام، کلید هوش ۳.۵ کلاک و ویرایشگر بلاک‌های فریمورک پیش‌فرض</p>
            </div>

            {/* Maintenance Indicator Toggle */}
            <div className="flex items-center gap-3">
              <span className="text-[10px] font-bold text-zinc-400 font-sans">حالت تعمیرات موقت پلتفرم:</span>
              <button
                onClick={() => updateSettings({ maintenanceMode: !settings.maintenanceMode })}
                className={`w-12 h-6 rounded-full transition-all relative ${
                  settings.maintenanceMode ? 'bg-rose-600 animate-pulse' : 'bg-zinc-800'
                }`}
              >
                <div className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-all ${
                  settings.maintenanceMode ? 'left-1' : 'left-7'
                }`} />
              </button>
            </div>
          </div>

          {/* Welcome & Live stats card */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 p-6 rounded-3xl bg-zinc-950/40 border border-white/5 relative overflow-hidden flex flex-col justify-between min-h-[140px]">
              <div className="absolute top-0 right-0 w-64 h-64 bg-brand-orange/5 rounded-full blur-[80px]" />
              <div className="space-y-1.5 relative z-10">
                <span className="text-[9px] bg-brand-orange/15 border border-brand-orange/30 text-brand-orange px-2.5 py-1 rounded-full font-black tracking-wider uppercase inline-block">
                  🛡️ ریشه مدیریتی ساو فعال است
                </span>
                <h3 className="text-lg font-black text-white">خوش آمدید، همکار گرامی!</h3>
                <p className="text-[11px] text-zinc-400 leading-relaxed max-w-xl">
                  به مرکز یکپارچه فرماندهی و مانیتورینگ کلان آکادمی سناریونویسی و ویدیوهای وایرال ساو خوش آمدید. هرکدام از بخش‌های سیستم به صورت صفحاتی مستقل با دسترسی سریع طراحی شده‌اند.
                </p>
              </div>
            </div>

            <div className="p-6 rounded-3xl bg-zinc-950 border border-white/5 flex flex-col justify-between shadow-xl min-h-[140px]">
              <div className="flex justify-between items-start">
                <span className="text-[10px] text-zinc-400 font-bold">گردش مالی شبیه‌ساز</span>
                <TrendingUp className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              </div>
              <div className="space-y-0.5">
                <div className="text-xl font-black text-white font-mono">{formatToman(totalRevenue)}</div>
                <p className="text-[9px] text-zinc-500 font-semibold">تراکنش‌های شبیه‌سازی درگاه‌های بانکی</p>
              </div>
            </div>
          </div>

          {/* Grid layout representing custom separate pages */}
          <div className="space-y-4">
            <h3 className="text-xs font-black text-zinc-400 flex items-center gap-1.5">
              <LayoutGrid className="w-4 h-4 text-brand-orange" />
              جهت ورود، صفحه مدیریتی مورد نظر را انتخاب فرمایید:
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {subPages.map((page) => {
                const PageIcon = page.icon;
                return (
                  <div
                    key={page.id}
                    onClick={() => setActiveAdminSubTab(page.id as any)}
                    className="p-6 rounded-2xl bg-zinc-950/80 border border-white/5 hover:border-brand-orange/20 cursor-pointer group hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between min-h-[190px] relative overflow-hidden shadow-lg"
                  >
                    <div className="absolute top-0 left-0 w-24 h-24 bg-white/[0.01] rounded-full translate-x-[-10%] translate-y-[-10%]" />
                    
                    <div className="space-y-3 relative z-10">
                      <div className="flex justify-between items-center">
                        <div className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white">
                          <PageIcon className="w-4.5 h-4.5 text-zinc-300 group-hover:text-brand-orange transition-colors animate-fade-in" />
                        </div>
                        <span className="text-[8px] bg-white/[3%] border border-white/10 px-2 py-0.5 rounded font-black text-zinc-400">
                          {page.badge}
                        </span>
                      </div>

                      <div className="space-y-1">
                        <h4 className="text-xs font-black text-white group-hover:text-brand-orange transition-colors">
                          {page.label}
                        </h4>
                        <p className="text-[10px] text-zinc-500 leading-relaxed font-semibold">
                          {page.desc}
                        </p>
                      </div>
                    </div>

                    <div className="flex justify-between items-end pt-3 border-t border-white/5 relative z-10 text-[10px] mt-1 pr-0.5">
                      <div className="space-y-0.5">
                        <span className="text-[8px] text-zinc-550 block font-bold">{page.statsLabel}</span>
                        <span className="font-mono text-zinc-400 font-bold text-[11px]">{page.stats}</span>
                      </div>
                      <span className="text-[9px] text-brand-orange font-black flex items-center gap-1 opacity-80 group-hover:opacity-100 group-hover:translate-x-[-2px] transition-all">
                        ورود به صفحه ←
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        /* Standalone Active Sub-page layout with collapsible premium SaaS sidebar and fixed modern topbar */
        <div className="flex flex-col lg:flex-row gap-6 items-start w-full transition-all duration-300 animate-fadeIn" dir="rtl">
          
          {/* 1. SaaS COLLAPSIBLE SIDEBAR */}
          <div 
            className={`shrink-0 lg:sticky lg:top-4 bg-zinc-950/90 border border-white/5 shadow-2xl rounded-2xl p-4 transition-all duration-300 flex flex-col justify-between ${
              isSidebarCollapsed ? 'w-18' : 'w-64'
            }`}
          >
            <div className="space-y-4">
              {/* Sidebar Header & Collapse Toggle */}
              <div className={`flex items-center justify-between pb-3 border-b border-white/5 ${isSidebarCollapsed ? 'flex-col gap-2' : ''}`}>
                {!isSidebarCollapsed && (
                  <div className="flex items-center gap-1.5 font-black">
                    <ShieldCheck className="w-4 h-4 text-brand-orange shrink-0 animate-pulse" />
                    <span className="text-xs text-white">پیشخوان ساو</span>
                  </div>
                )}
                {isSidebarCollapsed && (
                  <ShieldCheck className="w-5 h-5 text-brand-orange animate-pulse" />
                )}
                
                <button
                  onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
                  className="p-1.5 rounded-lg bg-white/5 border border-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-all"
                  title={isSidebarCollapsed ? "بزرگ کردن منو" : "کوچک کردن منو"}
                >
                  <span className="text-[10px] font-black">{isSidebarCollapsed ? "◀" : "▶"}</span>
                </button>
              </div>

              {/* Sidebar Navigation Links */}
              <div className="flex flex-col gap-1.5">
                {/* Back to Hub Command Button */}
                <button
                  onClick={() => setActiveAdminSubTab('hub')}
                  className={`w-full text-right px-3 py-2 text-[10px] font-black rounded-lg text-zinc-400 hover:text-white hover:bg-white/5 transition-all flex items-center gap-2 ${
                    isSidebarCollapsed ? 'justify-center' : ''
                  }`}
                  title="بازگشت به هاب اصلی"
                >
                  <LayoutGrid className="w-3.5 h-3.5 text-zinc-550 shrink-0" />
                  {!isSidebarCollapsed && <span>🎛️ هاب اصلی مدیریت</span>}
                </button>

                <div className="h-[1px] bg-white/5 my-1" />

                {subPages.map((item) => {
                  const ItemIcon = item.icon;
                  const isItemActive = activeAdminSubTab === item.id;
                  const itemLabel = item.label.replace(/^[^\s]+\s/, ''); // strip emoji prefix
                  return (
                    <button
                      key={item.id}
                      onClick={() => setActiveAdminSubTab(item.id as any)}
                      className={`text-right px-3 py-2.5 text-[10px] font-bold rounded-xl transition-all flex items-center justify-between gap-2 border ${
                        isItemActive 
                          ? 'text-brand-orange bg-brand-orange/5 border-brand-orange/15 font-black' 
                          : 'text-zinc-500 border-transparent hover:text-zinc-350 hover:bg-white/[1.5%]'
                      } ${isSidebarCollapsed ? 'justify-center font-black' : ''}`}
                      title={item.label}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <ItemIcon className={`w-3.5 h-3.5 shrink-0 ${isItemActive ? 'text-brand-orange' : 'text-zinc-550'}`} />
                        {!isSidebarCollapsed && <span className="truncate">{itemLabel}</span>}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Collapsed Workspace Status indicators */}
            {!isSidebarCollapsed && (
              <div className="mt-8 p-3 rounded-xl bg-white/[1%] border border-white/5 text-center space-y-1.5">
                <div className="flex items-center justify-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-[8px] text-zinc-400 font-bold font-mono tracking-widest">SYSTEM WORKSPACE</span>
                </div>
                <p className="text-[8px] text-zinc-500 font-semibold leading-normal">کل صفحه از حداکثر پهنای نمایشگر استفاده می‌کند.</p>
              </div>
            )}
          </div>

          {/* 2. Premium Workspace Content Area */}
          <div className="flex-1 w-full min-w-0 space-y-6">
            
            {/* Fixed header and status line with professional breadcrumbs */}
            {subPageNames[activeAdminSubTab] && (
              <div className="p-6 rounded-2xl bg-[#09090a]/85 border border-white/5 flex flex-col md:flex-row items-center justify-between gap-4 mb-2 shadow-sm">
                <div className="space-y-1 text-right">
                  <div className="flex items-center gap-1.5 text-[9px] text-zinc-500 font-bold">
                    <button 
                      onClick={() => setActiveAdminSubTab('hub')}
                      className="hover:text-brand-orange transition-colors"
                    >
                      مدیریت کلان ساو
                    </button>
                    <span>/</span>
                    <span className="text-zinc-450">{subPageNames[activeAdminSubTab].category}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    {(() => {
                      const PageIcon = subPageNames[activeAdminSubTab].icon;
                      return <PageIcon className="w-4.5 h-4.5 text-brand-orange shrink-0 animate-pulse" />;
                    })()}
                    <h2 className="text-base font-black text-white">{subPageNames[activeAdminSubTab].title}</h2>
                  </div>
                  <p className="text-zinc-400 text-[10px] font-medium leading-relaxed">
                    {subPageNames[activeAdminSubTab].description}
                  </p>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <span className="text-[8px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/10 px-2.5 py-1 rounded font-black tracking-wide uppercase font-mono">
                    ● LATEST SYNC ACTIVE
                  </span>
                  <button
                    onClick={() => setActiveAdminSubTab('hub')}
                    className="px-4 py-2 rounded-xl bg-white/5 border border-white/10 hover:border-brand-orange/30 hover:text-white text-zinc-300 text-[10px] font-black transition-all flex items-center gap-1.5 shadow-md"
                  >
                    <span>برگشت به هاب اصلی</span>
                    <span className="font-mono text-brand-orange">←</span>
                  </button>
                </div>
              </div>
            )}

            {/* Standalone Sub-page Body Container */}
            <div className="min-h-[420px]">
        
        {/* SUBTAB 1: General Stats */}
        {activeAdminSubTab === 'stats' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="p-5 rounded-2xl bg-zinc-950 border border-white/5 space-y-1.5 shadow-xl">
                <span className="text-[10px] font-bold text-zinc-500 uppercase">کل درآمد تایید شده</span>
                <p className="text-xl font-black text-white font-mono">{formatToman(totalRevenue)}</p>
                <div className="text-[9px] text-green-400">▲ ۱۸٪ بابت کارمزدهای هفته جاری</div>
              </div>

              <div className="p-5 rounded-2xl bg-[#00000000] border border-white/5 space-y-1.5 shadow-xl bg-zinc-950">
                <span className="text-[10px] font-bold text-zinc-500 uppercase">سناریوهای کات آف</span>
                <p className="text-xl font-black text-white font-mono">
                  {scenarios.filter(s => s.reviewStatus === 'under_review').length} پروژه
                </p>
                <div className="text-[9px] text-amber-400">در صف بررسی مربیان آکادمی</div>
              </div>

              <div className="p-5 rounded-2xl bg-zinc-950 border border-white/5 space-y-1.5 shadow-xl">
                <span className="text-[10px] font-bold text-zinc-500 uppercase">پرونده‌های فعال چت</span>
                <p className="text-xl font-black text-white font-mono">
                  {tickets.filter(t => t.status === 'open' || t.status === 'pending').length} تیکت
                </p>
                <div className="text-[9px] text-blue-400">۲ تیکت باز ارجاع نشده</div>
              </div>

              <div className="p-5 rounded-2xl bg-zinc-950 border border-white/5 space-y-1.5 shadow-xl">
                <span className="text-[10px] font-bold text-zinc-500 uppercase">اعضای رسمی سامانه</span>
                <p className="text-xl font-black text-white font-mono">{usersList.length} کریتور</p>
                <div className="text-[9px] text-zinc-500">مهمان بدون حساب: ۴۷ کاربر روزانه</div>
              </div>
            </div>

            {/* Cinematic Graph */}
            <div className="p-6 rounded-2xl bg-zinc-950 border border-white/5 space-y-4">
              <div>
                <h3 className="text-base font-bold text-white">ترافیک درخواست‌های تولید سناریو هوش مصنوعی</h3>
                <p className="text-[10px] text-zinc-500">حجم استفاده روزانه از مدل‌های کلاک ۳.۵ در خرداد ۱۴۰۵</p>
              </div>

              <div className="w-full h-48 bg-black/40 rounded-xl relative border border-white/[2%] pt-6 overflow-hidden">
                <svg className="w-full h-full text-brand-orange" viewBox="0 0 800 150" fill="none">
                  <path 
                    d="M 50 120 C 150 70, 250 140, 350 40 C 450 110, 550 40, 650 90 C 700 80, 750 110, 780 120 L 780 150 L 50 150 Z" 
                    fill="url(#chart-grad)" 
                  />
                  <path 
                    d="M 50 120 C 150 70, 250 140, 350 40 C 450 110, 550 40, 650 90 C 700 80, 750 110, 780 120" 
                    stroke="#ff5722" 
                    strokeWidth="3" 
                    strokeLinecap="round" 
                  />
                  <line x1="0" y1="50" x2="800" y2="50" stroke="rgba(255,255,255,0.015)" strokeDasharray="4" />
                  <line x1="0" y1="100" x2="800" y2="100" stroke="rgba(255,255,255,0.015)" strokeDasharray="4" />
                </svg>
                <div className="absolute inset-x-6 bottom-2 flex justify-between text-[8px] text-zinc-650 font-mono">
                  <span>شنبه</span> <span>دوشنبه</span> <span>چهارشنبه</span> <span>جمعه</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 2: Visual Page Builder (Framer/Webflow Style) */}
        {activeAdminSubTab === 'builder' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 rounded-2xl p-6 bg-zinc-950 border border-white/5 space-y-4 shadow-xl">
              <div className="flex justify-between items-center pb-2 border-b border-white/[5%]">
                <div>
                  <h3 className="text-sm font-bold text-white">طراحی چیدمان ماژولار صفحه اصلی</h3>
                  <p className="text-[10px] text-zinc-500">بلاک‌های بصری را فعال/غیرفعال کنید، متن‌ها را ویرایش کنید یا ترتیب چیدمان نهایی را به صورت زنده تغییر دهید.</p>
                </div>
              </div>

              <div className="space-y-3">
                {homeSections.map((sec, index) => (
                  <div 
                    key={sec.id} 
                    className={`p-4 rounded-xl border transition-all ${
                      sec.enabled ? 'bg-white/[1.5%] border-white/10' : 'bg-transparent border-white/5 opacity-50'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-md bg-white/5 flex items-center justify-center text-[10px] text-zinc-400 font-mono">
                            {index + 1}
                          </span>
                          <span className="text-[10px] text-brand-orange bg-brand-orange/5 px-2 py-0.5 rounded font-bold uppercase font-mono">
                            {sec.type}
                          </span>
                          <h4 className="text-xs font-black text-white">{sec.title}</h4>
                        </div>
                        <p className="text-[10px] text-zinc-400 pr-7">{sec.subtitle}</p>
                      </div>

                      {/* Controls */}
                      <div className="flex items-center gap-3">
                        {/* Status Toggle */}
                        <button
                          onClick={() => {
                            const updated = homeSections.map(s => s.id === sec.id ? { ...s, enabled: !s.enabled } : s);
                            updateHomeSections(updated);
                          }}
                          className={`px-2 py-1 rounded text-[9px] font-bold transition-colors ${
                            sec.enabled ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-zinc-900 text-zinc-500'
                          }`}
                        >
                          {sec.enabled ? 'فعال در خانه' : 'پنهان شده'}
                        </button>

                        {/* Move Order */}
                        <div className="flex gap-1">
                          <button
                            disabled={index === 0}
                            onClick={() => moveSectionOrder(sec.id, 'up')}
                            className="p-1 rounded bg-zinc-900 border border-white/5 text-zinc-400 hover:text-white disabled:opacity-30 disabled:hover:text-zinc-500"
                          >
                            <ArrowUpDown className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Edit Text Trigger */}
                        <button
                          onClick={() => {
                            setEditingSectionId(sec.id);
                            setEditingSecTitle(sec.title);
                            setEditingSecSub(sec.subtitle);
                          }}
                          className="px-2 py-1 rounded text-[9px] font-bold bg-white/5 hover:bg-white/10 text-zinc-300 transition-all border border-white/5"
                        >
                          ویرایش محتوا
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Sidebar edit form & branding column */}
            <div className="lg:col-span-1 space-y-6">
              {/* BRANDING CARD */}
              <div id="admin_branding_section" className="rounded-2xl p-6 bg-zinc-950 border border-white/5 space-y-4 shadow-xl h-fit">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-brand-orange border-none" />
                    <span>برندینگ سراسری اپلیکیشن</span>
                  </h3>
                  <p className="text-[10px] text-zinc-500">تغییر نام اپلیکیشن در هدر، فوتر، پنل کاربری و تمامی عناوین زنده.</p>
                </div>

                <div className="space-y-3.5">
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-zinc-400 font-bold block">نام کل پلتفرم و سایت</label>
                    <input
                      type="text"
                      id="global_app_name_input"
                      value={appTitleInput}
                      onChange={(e) => setAppTitleInput(e.target.value)}
                      placeholder="مثال: ساو"
                      className="w-full px-3 py-2 rounded-xl bg-white/[1.5%] border border-[#ffffff15] text-xs text-white outline-none text-right placeholder-zinc-650"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      if (!appTitleInput.trim()) {
                        alert('وارد کردن نام اپلیکیشن الزامی است.');
                        return;
                      }
                      const newAppName = appTitleInput.trim();
                      updateCopywriting('appName', newAppName);
                      // Update other dynamic copywriting areas to match the branding name
                      updateCopywriting('siteTitle', `پلتفرم ${newAppName} دکوپاژ ریلز`);
                      updateCopywriting('siteLogoName', `آکادمی فیلم‌سازی و استودیو تولید ${newAppName}`);
                      updateCopywriting('heroWelcome', `سلام کاربر خلاق؛ به ${newAppName} خوش آمدی!`);
                      updateCopywriting('heroBigTitle', `دستیار خلاق لوکس ریلز ${newAppName}`);
                      updateCopywriting('servicesTitle', `مرکز خدمات لوکس تولید و رشد ${newAppName}`);
                      updateCopywriting('academyTitle', `آکادمی فیلمسازی موبایلی ${newAppName}`);
                      updateCopywriting('footerCopyright', `© ۱۴۰۵ تمامی حقوق برای آژانس دیجیتال و آکادمی ${newAppName} محفوظ است.`);
                      alert('نام سراسری اپلیکیشن با موفقیت به‌روزرسانی شد!');
                    }}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-brand-orange to-brand-red text-white text-xs font-black hover:opacity-95 transition-all text-center cursor-pointer shadow-lg shadow-brand-orange/10"
                  >
                    🚀 ثبت و اعمال نام سراسری
                  </button>
                </div>
              </div>

              {/* Sidebar edit form drawer */}
              <div className="rounded-2xl p-6 bg-matte-black border border-[#ffffff05] space-y-4 shadow-xl h-fit">
                <h3 className="text-sm font-bold text-white">پنل ویرایش متن زنده</h3>
                <p className="text-[10px] text-zinc-550 leading-relaxed">با تغییر متن‌های هدر و جزئیات بلاک، طراحی خانه بدون نیاز به کدنویسی تغییر خواهد کرد.</p>

                {editingSectionId ? (
                  <div className="space-y-4 pt-2">
                    <div className="space-y-1.5">
                      <label className="text-[10px] text-zinc-400 font-bold">عنوان بلاک (Title)</label>
                      <input
                        type="text"
                        value={editingSecTitle}
                        onChange={(e) => setEditingSecTitle(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] text-zinc-400 font-bold">توضیح یا زیرعنوان (Subtitle)</label>
                      <textarea
                        value={editingSecSub}
                        onChange={(e) => setEditingSecSub(e.target.value)}
                        rows={4}
                        className="w-full p-3 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white resize-none"
                      />
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={handleSaveSectionEdit}
                        className="flex-1 py-1.5 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 text-white text-xs font-bold"
                      >
                        ثبت اصلاحات
                      </button>
                      <button
                        onClick={() => setEditingSectionId(null)}
                        className="flex-1 py-1.5 rounded-xl bg-zinc-900 border border-white/5 text-zinc-400 text-xs font-bold"
                      >
                        لغو
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="py-12 text-center text-zinc-550 text-xs text-medium">
                    یک بخش را از لیست مقابل انتخاب کنید تا فرم ویرایش فعال شود.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 3: Review Desk & Chat Tickets Center */}
        {activeAdminSubTab === 'reviews' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Direct Tickets list (Intercom) */}
            <div className="lg:col-span-5 rounded-2xl p-6 bg-zinc-950 border border-white/5 space-y-4 shadow-xl">
              <div>
                <h3 className="text-sm font-bold text-white">پیشخوان چت و تیکت‌های پشتیبانی</h3>
                <p className="text-[10px] text-zinc-550">شکایات، ایرادات درگاه، نقد ویس‌ها و خروجی آیفون کاربران ساو</p>
              </div>

              <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
                {tickets.map(t => (
                  <div
                    key={t.id}
                    onClick={() => setSelectedTicketId(t.id)}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                      selectedTicketId === t.id 
                        ? 'bg-brand-orange/5 border-brand-orange/40 shadow-inner' 
                        : 'bg-white/[1%] border-white/5 hover:border-white/10'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span className="text-[9px] text-zinc-550 font-mono font-bold">{t.id.toUpperCase()}</span>
                      <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold ${
                        t.status === 'open' 
                          ? 'bg-blue-500/10 text-blue-400' 
                          : t.status === 'pending'
                          ? 'bg-amber-400/10 text-amber-400'
                          : 'bg-green-500/10 text-green-400'
                      }`}>
                        {t.status === 'open' ? 'باز شده' : t.status === 'pending' ? 'در انتظار' : 'پاسخ داده'}
                      </span>
                    </div>
                    <h4 className="text-xs font-black text-white mt-1.5 truncate">{t.title}</h4>
                    <p className="text-[10px] text-zinc-500 font-sans mt-1 truncate">کاربر ارجاعی: {t.userName}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Selected ticket timeline/editor */}
            <div className="lg:col-span-7 space-y-4">
              {selectedTicketId ? (
                <div className="rounded-2xl border border-white/5 bg-matte-black p-6 flex flex-col h-[480px]">
                  {/* Chat header info */}
                  {(() => {
                    const activeTicket = tickets.find(t => t.id === selectedTicketId);
                    if (!activeTicket) return null;
                    return (
                      <>
                        <div className="flex justify-between items-center pb-3 border-b border-white/5 mb-4">
                          <div>
                            <h4 className="text-xs font-black text-white">{activeTicket.title}</h4>
                            <p className="text-[9px] text-zinc-500 font-medium">مخاطب: {activeTicket.userName} • بخش: {activeTicket.department}</p>
                          </div>
                          <select
                            value={activeTicket.status}
                            onChange={(e) => updateTicketStatus(activeTicket.id, e.target.value as any)}
                            className="bg-zinc-950 px-2 py-1 rounded text-[10px] font-bold text-white border border-white/10 focus:outline-none"
                          >
                            <option value="open">تغییر به: باز شده</option>
                            <option value="pending">تغییر به: در انتظار</option>
                            <option value="answered">تغییر به: پاسخ داده</option>
                            <option value="closed">تغییر به: بسته شده</option>
                          </select>
                        </div>

                        {/* Timeline messages scroll */}
                        <div className="flex-1 overflow-y-auto space-y-3 px-1 mb-4 max-h-[300px]">
                          {activeTicket.messages.map((m, mIdx) => {
                            const isAdmin = m.sender === 'admin';
                            return (
                              <div key={mIdx} className={`flex flex-col ${isAdmin ? 'items-end' : 'items-start'} space-y-1`}>
                                <span className="text-[9px] text-zinc-550">{m.senderName}</span>
                                <div className={`p-3.5 rounded-2xl text-xs leading-relaxed ${
                                  isAdmin 
                                    ? 'bg-zinc-900 text-zinc-300 rounded-tr-none border border-white/5' 
                                    : 'bg-white/[3%] text-zinc-200 border border-white/5 rounded-tl-none'
                                }`}>
                                  {m.content}
                                </div>
                                <span className="text-[8px] text-zinc-650 font-mono">{m.createdAt}</span>
                              </div>
                            );
                          })}
                        </div>

                        {/* Editor Reply footer */}
                        <div className="bg-zinc-950/40 p-3 rounded-xl border border-white/5 flex gap-2">
                          <input
                            type="text"
                            value={ticketReplyText}
                            onChange={(e) => setTicketReplyText(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleTicketAdminReply();
                            }}
                            placeholder="پاسخ بفرمایید..."
                            className="flex-1 bg-transparent border-none text-xs text-white focus:outline-none placeholder-zinc-700"
                          />
                          <button
                            onClick={handleTicketAdminReply}
                            className="px-3.5 py-1.5 rounded-lg bg-brand-orange text-white text-xs font-bold shrink-0 hover:bg-brand-orange-light transition-colors"
                          >
                            ارسال
                          </button>
                        </div>
                      </>
                    );
                  })()}
                </div>
              ) : (
                <div className="rounded-2xl bg-zinc-950 border border-white/5 p-12 text-center text-zinc-550 text-xs">
                  یک تیکت را انتخاب کنید تا تاریخچه مکالمات با سازنده نمایش داده شود.
                </div>
              )}
            </div>

          </div>
        )}

        {/* SUBTAB 4: Telegram Setup Wizard */}
        {activeAdminSubTab === 'tele_bot' && (
          <div className="max-w-2xl rounded-2xl p-6 bg-zinc-950 border border-white/5 space-y-6 shadow-xl">
            <div className="space-y-1 pb-3 border-b border-white/5">
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <Bot className="w-5 h-5 text-brand-orange" />
                راه‌اندازی گام‌به‌گام ربات تلگرامی ساو
              </h3>
              <p className="text-[10px] text-zinc-500">موتور دیسپورت مستقیم نوتیفیکیشن‌ها و وب‌هوک‌های عکاسی آکادمی به آیدی ادمین‌های ایران</p>
            </div>

            {/* Stepper Wizard Headers */}
            <div className="flex gap-4 border-b border-white/[3%] pb-3 text-xs md:text-xs">
              {[
                { step: 1, label: '۱. ایجاد ربات در BotFather' },
                { step: 2, label: '۲. اتصال توکن API' },
                { step: 3, label: '۳. فعالسازی پایگاه گردش‌کار' }
              ].map(s => (
                <button
                  key={s.step}
                  onClick={() => setTelegramWizardStep(s.step as any)}
                  className={`pb-1 border-b-2 text-right transition-colors ${
                    telegramWizardStep === s.step ? 'border-brand-orange text-brand-orange font-bold' : 'border-transparent text-zinc-500'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>

            <AnimatePresence mode="wait">
              {telegramWizardStep === 1 && (
                <motion.div 
                  key="step-1" 
                  initial={{ opacity: 0 }} 
                  animate={{ opacity: 1 }} 
                  exit={{ opacity: 0 }} 
                  className="space-y-4 text-xs leading-relaxed text-zinc-400"
                >
                  <p className="text-white font-bold">برای ساخت ربات پیام‌رسان ساو، مراحل زیر را طی کنید:</p>
                  <ol className="list-decimal list-inside space-y-2 pr-2 text-zinc-400">
                    <li>اپلیکیشن تلگرام را باز کنید و وارد آیدی تلگرامی رسمی <span className="text-brand-orange font-mono font-bold">@BotFather</span> شوید.</li>
                    <li>دستور <span className="text-zinc-200 font-mono">/newbot</span> را بفرستید.</li>
                    <li>یک نام دلخواه برای محصول بنویسید (مثلاً: <span className="text-zinc-200">دستیار هوشمند ساو</span>).</li>
                    <li>یک یوزرنیم انحصاری که با پسوند <span className="text-zinc-200 font-mono">bot</span> تمام می‌گردد تعریف کنید (مثال: <span className="text-zinc-200 font-mono">SavReelsBot</span>).</li>
                    <li>بات‌فادر یک رشته طولانی به نام <span className="text-zinc-200 font-mono">HTTP API Token</span> به شما ارائه می‌دهد. دبل کلیک کرده و آن را کپی کنید.</li>
                  </ol>
                  <button
                    onClick={() => setTelegramWizardStep(2)}
                    className="mt-4 px-4 py-2 bg-zinc-900 border border-white/5 hover:border-white/10 text-white rounded-lg font-bold"
                  >
                    حله، نوشتم! رفتن به مرحله بعد ←
                  </button>
                </motion.div>
              )}

              {telegramWizardStep === 2 && (
                <motion.div
                  key="step-2"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="space-y-4"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[10px] text-zinc-400 font-bold">آیدی ربات ساخته شده (Username)</label>
                      <input
                        type="text"
                        value={tgTempBot}
                        onChange={(e) => setTgTempBot(e.target.value)}
                        placeholder="SavReelsBot"
                        className="w-full px-4 py-2.5 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white text-left font-mono"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] text-zinc-400 font-bold">توکن امنیتی API Token</label>
                      <input
                        type="text"
                        value={tgTempToken}
                        onChange={(e) => setTgTempToken(e.target.value)}
                        placeholder="7304192301:AAF-telegram-key-sav-mock-token"
                        className="w-full px-4 py-2.5 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white text-left font-mono"
                      />
                    </div>
                  </div>

                  <div className="flex gap-3 pt-2">
                    <button
                      type="button"
                      onClick={handleTestTelegramConnection}
                      className="px-4 py-2.5 rounded-xl bg-brand-orange text-white text-xs font-bold hover:brightness-110 flex items-center justify-center gap-1.5 min-w-[140px]"
                    >
                      {tgTesting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <span>بررسی و آزمایش اتصال</span>}
                    </button>
                    {tgTestSuccess && (
                      <span className="text-xs text-green-400 my-auto font-bold flex items-center gap-1">
                        <Check className="w-4 h-4" /> اتصال موفق! بات متصل شد.
                      </span>
                    )}
                  </div>
                </motion.div>
              )}

              {telegramWizardStep === 3 && (
                <motion.div
                  key="step-3"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="space-y-4 text-xs font-semibold"
                >
                  <p className="text-zinc-400 pb-2">تفکیک جریان‌های پیام رسانی اختصاصی که از طریق این بات به مدیران وب‌سایت شلیک می‌گردد:</p>
                  
                  <div className="space-y-3.5 max-w-md">
                    <label className="flex items-center gap-3 bg-zinc-950 p-3 rounded-xl border border-white/[3%] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={!!settings.telegramWorkflows?.notifyConsultations}
                        onChange={() => {
                          const w = { ...settings.telegramWorkflows, notifyConsultations: !settings.telegramWorkflows?.notifyConsultations };
                          updateSettings({ telegramWorkflows: w });
                        }}
                        className="w-4 h-4 text-brand-orange rounded bg-zinc-900 border-white/10"
                      />
                      <span>ارسال لایو درخواست‌های رزرو جلسه و کلینیک به تلگرام</span>
                    </label>

                    <label className="flex items-center gap-3 bg-zinc-950 p-3 rounded-xl border border-white/[3%] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={!!settings.telegramWorkflows?.notifyProduction}
                        onChange={() => {
                          const w = { ...settings.telegramWorkflows, notifyProduction: !settings.telegramWorkflows?.notifyProduction };
                          updateSettings({ telegramWorkflows: w });
                        }}
                        className="w-4 h-4 text-brand-orange rounded bg-zinc-900 border-white/10"
                      />
                      <span>ارسال رول آفیش فیلبرداری تهران به تیم تولید</span>
                    </label>

                    <label className="flex items-center gap-3 bg-zinc-950 p-3 rounded-xl border border-white/[3%] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={!!settings.telegramWorkflows?.notifyExpertReview}
                        onChange={() => {
                          const w = { ...settings.telegramWorkflows, notifyExpertReview: !settings.telegramWorkflows?.notifyExpertReview };
                          updateSettings({ telegramWorkflows: w });
                        }}
                        className="w-4 h-4 text-brand-orange rounded bg-zinc-900 border-white/10"
                      />
                      <span>هشدار فوری ثبت تیکت های نقد سناریو مربیگری طلایی</span>
                    </label>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        {/* SUBTAB 5: Gemini Keys Dashboard */}
        {activeAdminSubTab === 'gemini' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 rounded-2xl p-6 bg-zinc-950 border border-white/5 space-y-5 shadow-xl">
              <div className="space-y-1 pb-3 border-b border-white/5">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Zap className="w-5 h-5 text-brand-orange animate-pulse" />
                  مدیریت کلید وب‌ سرویس هوش مصنوعی Gemini
                </h3>
                <p className="text-[10px] text-zinc-550">تنظیم بک‌آپ کی‌ها جهت لود مداوم سیستم کپشن نویسی و دکوپاژ درگاه ساو</p>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5 col-span-1">
                    <label className="text-[10px] text-zinc-400 font-bold">کلید مستر اصلی (Master SDK Key)</label>
                    <input
                      type="password"
                      value={gemKeyTemp}
                      onChange={(e) => setGemKeyTemp(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white text-left font-mono"
                    />
                  </div>

                  <div className="space-y-1.5 col-span-1">
                    <label className="text-[10px] text-zinc-400 font-bold">کلید بک‌آپ پشتیبان (Backup Key)</label>
                    <input
                      type="password"
                      value={gemBackupTemp}
                      onChange={(e) => setGemBackupTemp(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white text-left font-mono"
                    />
                  </div>
                </div>

                <div className="flex justify-between items-center py-2">
                  <div className="space-y-0.5">
                    <h5 className="text-xs font-bold text-white">قابلیت سوئیچ آنلاین خودکار به بک‌آپ:</h5>
                    <p className="text-[10px] text-zinc-500">اگر گوگل خطای ۵۰۳ ری‌لیمیت داد کلید رزرو فورا لود شود</p>
                  </div>
                  <button
                    onClick={() => updateSettings({ gemini_mode_enabled: !settings.gemini_mode_enabled })}
                    className={`w-10 h-5 rounded-full transition-all relative ${
                      settings.gemini_mode_enabled ? 'bg-brand-orange' : 'bg-zinc-800'
                    }`}
                  >
                    <div className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-all ${
                      settings.gemini_mode_enabled ? 'left-1' : 'left-5'
                    }`} />
                  </button>
                </div>

                <button
                  onClick={handleSaveGeminiKeys}
                  className="px-4 py-2 bg-gradient-to-r from-brand-orange to-brand-red text-white text-xs font-bold rounded-lg hover:brightness-110 active:scale-95 transition-all"
                >
                  ذخیره و آزمایش سلامت سرور هوش مصنوعی ساو
                </button>
              </div>
            </div>

            {/* usage analytics meters */}
            <div className="lg:col-span-1 rounded-2xl p-6 bg-matte-black border border-white/5 space-y-4 shadow-xl text-xs">
              <h3 className="font-bold text-white">وضعیت پایداری API</h3>
              
              <div className="space-y-4 pt-2">
                <div className="space-y-1">
                  <div className="flex justify-between text-[10px]">
                    <span className="text-zinc-400">تعداد درخواست‌های موفق:</span>
                    <span className="text-white font-bold font-mono">۴۲۱,۰۵۰ بارگذاری</span>
                  </div>
                  <div className="w-full h-1.5 bg-zinc-900 rounded-full overflow-hidden">
                    <div className="w-[84%] h-full bg-green-400" />
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-[10px]">
                    <span className="text-zinc-400">کش ذخیره‌سازی ابری:</span>
                    <span className="text-white font-bold font-mono">۶۸٪ صرفه جویی سرعت</span>
                  </div>
                  <div className="w-full h-1.5 bg-zinc-900 rounded-full overflow-hidden">
                    <div className="w-[68%] h-full bg-blue-400" />
                  </div>
                </div>

                <div className="p-3 bg-white/[2%] border border-white/5 rounded-xl font-mono text-[10px] space-y-1 text-zinc-550">
                  <div className="flex justify-between">
                    <span>Average Latency:</span> <span className="text-green-400">122ms</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Model In-use:</span> <span className="text-amber-400">Gemini 2.5 Flash</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 6: User Analytics Matrix */}
        {activeAdminSubTab === 'users' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
              {/* Search bar */}
              <div className="relative w-full md:w-80">
                <input
                  type="text"
                  value={userSearchText}
                  onChange={(e) => setUserSearchText(e.target.value)}
                  placeholder="جستجو بر اساس نام، همراه یا ایمیل..."
                  className="w-full px-4 py-2.5 pr-10 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white placeholder-zinc-700 focus:outline-none"
                />
                <Search className="w-4 h-4 text-zinc-650 absolute right-3.5 top-1/2 -translate-y-1/2" />
              </div>

              {/* quick filters */}
              <div className="flex gap-1.5 overflow-x-auto max-w-full pb-1">
                {[
                  { id: 'all', label: 'همه اعضا' },
                  { id: 'guest', label: 'کاربران مهمان' },
                  { id: 'registered', label: 'ثبت شده استاندارد' },
                  { id: 'premium', label: 'طلایی (Premium)' },
                  { id: 'suspended', label: 'مسدود شده' }
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setUserFilterRole(tab.id as any)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors whitespace-nowrap ${
                      userFilterRole === tab.id ? 'bg-brand-orange/10 text-brand-orange border border-brand-orange/20' : 'bg-transparent text-zinc-500 hover:text-zinc-300'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Table */}
              <div className="lg:col-span-8 rounded-2xl p-5 bg-zinc-950 border border-white/5 space-y-3 overflow-x-auto overflow-y-auto max-h-[480px]">
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="border-b border-white/5 text-zinc-500">
                      <th className="py-2.5">کریتور</th>
                      <th className="py-2.5">اطلاعات تماس</th>
                      <th className="py-2.5">زمان عضویت</th>
                      <th className="py-2.5">سناریوهای کلاکی</th>
                      <th className="py-2.5">وضعیت</th>
                      <th className="py-2.5 text-center">عملیات اصلاحی</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/[3%] text-zinc-300">
                    {filteredUsers.map(u => (
                      <tr 
                        key={u.id} 
                        onClick={() => setDrilledUserId(u.id)}
                        className={`hover:bg-white/[1%] transition-colors cursor-pointer ${
                          drilledUserId === u.id ? 'bg-white/[1.5%]' : ''
                        }`}
                      >
                        <td className="py-3 items-center flex gap-1.5">
                          <span className={`w-2 h-2 rounded-full ${u.isGuest ? 'bg-zinc-600' : 'bg-emerald-400 animate-pulse'}`} />
                          <span className="font-bold">{u.name}</span>
                        </td>
                        <td className="py-3 font-mono font-semibold text-[11px] text-zinc-400">
                          {u.phone || u.email || 'مهمان موقت'}
                        </td>
                        <td className="py-3 text-zinc-450 font-mono">{u.registrationDate}</td>
                        <td className="py-3 font-mono text-center font-bold text-white">{u.aiCount} سناریو</td>
                        <td className="py-3">
                          <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                            u.status === 'suspended' 
                              ? 'bg-rose-550/15 text-rose-500' 
                              : u.isPremium 
                              ? 'bg-amber-400/10 text-amber-400' 
                              : 'bg-zinc-800 text-zinc-400'
                          }`}>
                            {u.status === 'suspended' ? 'فریز/مسدود' : u.isPremium ? 'طلایی ویژه' : 'رایگان'}
                          </span>
                        </td>
                        <td className="py-3" onClick={(e) => e.stopPropagation()}>
                          <div className="flex gap-2 justify-center">
                            {/* Toggle Suspend btn */}
                            <button
                              onClick={() => updateUserStatus(u.id, u.status === 'suspended' ? 'active' : 'suspended')}
                              className={`px-2 py-1 rounded text-[9px] font-bold transition-all ${
                                u.status === 'suspended' ? 'bg-teal-500/10 text-teal-400 border border-teal-500/20' : 'bg-rose-600/10 text-rose-500 border border-rose-500/20'
                              }`}
                            >
                              {u.status === 'suspended' ? 'آزاد سازی' : 'تعلیق حساب'}
                            </button>

                            {/* Toggle gold */}
                            <button
                              onClick={() => updateUserSubscription(u.id, !u.isPremium)}
                              className="px-2 py-1 rounded text-[9px] font-bold bg-white/5 border border-white/5 hover:bg-white/10 text-zinc-200 transition-all font-sans"
                            >
                              {u.isPremium ? 'تنزل به معمولی' : 'ارتقا به ویژه'}
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Drill-down info drawer */}
              <div className="lg:col-span-4 rounded-2xl p-6 bg-matte-black border border-white/5 space-y-4 shadow-xl text-xs">
                <h3 className="font-bold text-white">جزئیات پرونده سیستمی</h3>
                
                {drilledUserId ? (
                  (() => {
                    const selectedU = usersList.find(u => u.id === drilledUserId);
                    if (!selectedU) return null;
                    return (
                      <div className="space-y-4">
                        <div className="p-3 bg-zinc-950/60 rounded-xl space-y-2">
                          <p className="text-[11px] text-zinc-400 font-bold">شناسه کاربر: <span className="font-mono text-zinc-300">{selectedU.id}</span></p>
                          <p className="font-black text-sm text-white">{selectedU.name}</p>
                          <p className="text-[10px] text-zinc-500">ماتریس اهراز: <span className="capitalize text-zinc-300 font-semibold">{selectedU.provider} login</span></p>
                        </div>

                        <div className="space-y-2.5 pt-2 border-t border-white/5">
                          <div className="flex justify-between">
                            <span className="text-zinc-500">تعداد کارهای ضبط هماهنگ شده:</span>
                            <span className="text-zinc-200 font-bold font-mono">
                              {productionRequests.filter(pr => pr.creatorPhone === selectedU.phone).length} بار آفیش
                            </span>
                          </div>

                          <div className="flex justify-between">
                            <span className="text-zinc-500">تماس‌های مشاوره:</span>
                            <span className="text-zinc-200 font-bold font-mono">
                              {consultations.filter(c => c.phone === selectedU.phone).length} جلسه زنده
                            </span>
                          </div>

                          <div className="flex justify-between">
                            <span className="text-zinc-500">تیکت‌های چت مستقیم:</span>
                            <span className="text-zinc-200 font-bold font-mono">
                              {tickets.filter(t => t.userId === selectedU.id).length} تیکت
                            </span>
                          </div>
                        </div>

                        {selectedU.isGuest && (
                          <div className="p-3 bg-amber-500/5 border border-amber-500/15 rounded-xl text-amber-400 text-[10px] leading-relaxed">
                            💡 این کاربر یک مهمان است. بر اساس سیستم فریمیوم ساو، او مجاز به زدن حداکثر ۳ سناریو رایگان می‌باشد. (استفاده فعلی: <span className="font-bold font-mono">{selectedU.aiCount}</span> از ۳).
                          </div>
                        )}
                      </div>
                    );
                  })()
                ) : (
                  <div className="py-12 text-center text-zinc-550">
                    یک کریتور را از جدول روبرو انتخاب کنید تا جزئیات تاریخچه و دکوپاژ لود شود.
                  </div>
                )}
              </div>

            </div>
          </div>
        )}

        {/* SUBTAB 7: Broadcasters and Push Campaigns with active simulation mock screen */}
        {activeAdminSubTab === 'notifications' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-xs font-semibold">
            
            {/* Form */}
            <div className="lg:col-span-5 rounded-2xl p-6 bg-zinc-950 border border-white/5 space-y-4 shadow-xl">
              <div>
                <h3 className="text-sm font-bold text-white">کمپین نوتیفیکیشن همگانی وب (PWA Web Push)</h3>
                <p className="text-[10px] text-zinc-550 mt-0.5">ارسال در لحظه اعلان‌های وایرال اینستاگرام به مرورگر هنرجویان ساو</p>
              </div>

              <div className="space-y-4 pt-2">
                <div className="space-y-1.5">
                  <label className="text-[10px] text-zinc-400 font-bold">تیتر جذاب نوتیفیکیشن (قلاب ۳ ثانیه‌ای)</label>
                  <input
                    type="text"
                    value={pushTitle}
                    onChange={(e) => setPushTitle(e.target.value)}
                    placeholder="مثال: 🔥 دکوراسیون ریلز تاریک منتشر شد!"
                    className="w-full px-4 py-2.5 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-zinc-400 font-bold">شرح پیام نوتیفیکیشن (سئو متاتگ)</label>
                  <textarea
                    value={pushDesc}
                    onChange={(e) => setPushDesc(e.target.value)}
                    rows={3}
                    placeholder="محتوای ریلز جدید به صورت خودکار لایو شد..."
                    className="w-full p-3 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white resize-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-zinc-400 font-bold">بخش هدف مخاطب (Segment)</label>
                  <select
                    value={pushSeg}
                    onChange={(e) => setPushSeg(e.target.value as any)}
                    className="w-full px-3 py-2.5 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white"
                  >
                    <option value="all">همه کاربران (هم مهمان و هم ویژه)</option>
                    <option value="guest">فقط کاربران مهمان (جهت ترغیب به فعالسازی)</option>
                    <option value="premium">مخاطبین ویژه طلایی (VIP)</option>
                  </select>
                </div>

                <button
                  onClick={handleDispatchPush}
                  className="w-full py-3 bg-gradient-to-r from-brand-orange to-brand-red text-white font-black text-xs rounded-xl shadow-lg hover:brightness-110 active:scale-98 transition-all"
                >
                  پرتاب آنی نوتیفیکیشن لایو
                </button>
              </div>
            </div>

            {/* Listed campaigns along with a real smartphone preview */}
            <div className="lg:col-span-7 grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* List */}
              <div className="rounded-2xl p-5 bg-zinc-950 border border-white/5 space-y-4">
                <h4 className="font-bold text-white text-xs">کمپین‌های ارسال شده اخیر</h4>
                <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1">
                  {pushCampaigns.map(c => (
                    <div key={c.id} className="p-3 bg-white/[1.5%] border border-white/5 rounded-xl space-y-1.5 hover:border-white/10 transition-all">
                      <span className="text-[8px] bg-white/5 border border-white/10 text-zinc-450 px-1.5 py-0.5 rounded uppercase font-mono">
                        Target: {c.segment}
                      </span>
                      <h5 className="text-[11px] font-black text-white">{c.title}</h5>
                      <p className="text-[10px] text-zinc-400 font-medium leading-relaxed">{c.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Smartphone mockup */}
              <div className="rounded-2xl p-6 bg-matte-black border border-white/5 text-center flex flex-col justify-center items-center space-y-4">
                <span className="text-[10px] text-zinc-500 font-bold uppercase">پیش‌نمایش در موبایل آیفون ۱۵</span>
                
                {/* Visual smartphone container */}
                <div className="w-52 h-96 rounded-[40px] border-4 border-zinc-800 bg-zinc-950/70 relative shadow-2xl p-3 flex flex-col justify-start">
                  
                  {/* Dynamic Island */}
                  <div className="w-20 h-4 bg-black rounded-full mx-auto" />
                  
                  <div className="flex-1 mt-6 overflow-hidden relative">
                    <p className="text-[9px] text-zinc-600 font-black font-mono">LOCK SCREEN</p>
                    
                    {/* Glowing notification box */}
                    <div className="p-2.5 rounded-2xl bg-zinc-900/90 border border-white/10 mt-12 text-right space-y-1 shadow-lg text-[9px]">
                      <span className="text-brand-orange font-bold font-mono">Sav Reels App</span>
                      <p className="text-white font-bold leading-tight truncate">{pushTitle || '🔥 آپدیت بزرگ ساو'}</p>
                      <p className="text-zinc-400 max-h-12 overflow-hidden leading-relaxed">{pushDesc || 'اعلان وایرال جدید ماژولار...'}</p>
                    </div>
                  </div>

                  <div className="w-16 h-1 bg-white/40 rounded-full mx-auto bottom-2 absolute left-1/2 -translate-x-1/2" />
                </div>
              </div>

            </div>
          </div>
        )}

        {/* SUBTAB 8: Payment Gateway managers & Coupons */}
        {activeAdminSubTab === 'gateways' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 text-xs font-semibold">
            
            {/* Gateways Settings Switchboard */}
            <div className="rounded-2xl p-6 bg-zinc-950 border border-white/5 space-y-5 shadow-xl">
              <div className="space-y-1 pb-3 border-b border-white/5">
                <h3 className="text-sm font-bold text-white">مدیریت درگاه‌های بانکی لایو</h3>
                <p className="text-[10px] text-zinc-550">تغییر مرچنت‌کدها، سوئیچ بین زرین‌پال، آی‌دی‌پای و استرایپ</p>
              </div>

              <div className="space-y-5">
                {/* ZarinPal */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center bg-white/[1.5%] p-3.5 rounded-xl">
                    <div className="space-y-0.5">
                      <h4 className="text-xs font-bold text-white">درگاه زرین‌پال (ZarinPal Gateway)</h4>
                      <p className="text-[10px] text-zinc-500">مخصوص تراکنش‌های شتاب ریالی داخل کشور</p>
                    </div>
                    <button
                      onClick={() => updateSettings({ zarinpalEnabled: !settings.zarinpalEnabled })}
                      className={`w-10 h-5 rounded-full transition-all relative ${
                        settings.zarinpalEnabled ? 'bg-brand-orange' : 'bg-zinc-800'
                      }`}
                    >
                      <div className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-all ${
                        settings.zarinpalEnabled ? 'left-1' : 'left-5'
                      }`} />
                    </button>
                  </div>
                  {settings.zarinpalEnabled && (
                    <div className="space-y-1 pl-4">
                      <span className="text-[9px] text-zinc-500">شماره پذیرنده مرچنت کد (Merchant ID)</span>
                      <input
                        type="password"
                        value={settings.zarinpalCreds || ''}
                        onChange={(e) => updateSettings({ zarinpalCreds: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-white/10 text-[10px] text-white font-mono"
                      />
                    </div>
                  )}
                </div>

                {/* Stripe */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center bg-white/[1.5%] p-3.5 rounded-xl">
                    <div className="space-y-0.5">
                      <h4 className="text-xs font-bold text-white">استرایپ جهانی (Stripe Global Payment)</h4>
                      <p className="text-[10px] text-zinc-500">پذیرش تراکنش‌های دلاری بین‌المللی اعضای خارج از ایران</p>
                    </div>
                    <button
                      onClick={() => updateSettings({ stripeEnabled: !settings.stripeEnabled })}
                      className={`w-10 h-5 rounded-full transition-all relative ${
                        settings.stripeEnabled ? 'bg-brand-orange' : 'bg-zinc-800'
                      }`}
                    >
                      <div className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-all ${
                        settings.stripeEnabled ? 'left-1' : 'left-5'
                      }`} />
                    </button>
                  </div>
                  {settings.stripeEnabled && (
                    <div className="space-y-1 pl-4">
                      <span className="text-[9px] text-zinc-550">کلید لایو Secret/Publish Key</span>
                      <input
                        type="password"
                        value={settings.stripeCreds || ''}
                        onChange={(e) => updateSettings({ stripeCreds: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-white/10 text-[10px] text-white font-mono"
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Coupon and Discounts Builder */}
            <div className="rounded-2xl p-6 bg-zinc-950 border border-white/5 space-y-5 shadow-xl">
              <div className="space-y-1 pb-3 border-b border-white/5">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Percent className="w-4 h-4 text-brand-orange" />
                  سازنده و مدیریت کدهای تخفیف کمپین
                </h3>
                <p className="text-[10px] text-zinc-550">تعریف تخفیف بر روی اشتراک طلایی (VIP)</p>
              </div>

              <div className="space-y-4 pt-1">
                <div className="flex gap-3">
                  <div className="space-y-1 flex-1">
                    <span className="text-[9px] text-zinc-400">کد کوپن</span>
                    <input
                      type="text"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      placeholder="SAVGOLDOFF"
                      className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white text-center font-mono uppercase"
                    />
                  </div>
                  <div className="space-y-1 w-24">
                    <span className="text-[9px] text-zinc-400">% درصد تخفیف</span>
                    <input
                      type="number"
                      value={couponPercent}
                      onChange={(e) => setCouponPercent(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white text-center font-mono"
                    />
                  </div>
                  <button
                    onClick={handleAddCoupon}
                    className="px-4 py-2 bg-gradient-to-r from-brand-orange to-brand-red text-white text-xs font-bold rounded-xl shrink-0 h-fit my-auto"
                  >
                    ثبت کوپن با درصد
                  </button>
                </div>

                <div className="space-y-3 pt-3 border-t border-white/5">
                  <span className="text-[10px] text-zinc-450">لیست کوپن‌ها</span>
                  <div className="space-y-2 max-h-[220px] overflow-y-auto">
                    {activeCoupons.map((c, i) => (
                      <div key={i} className="flex justify-between items-center p-3 bg-white/[1.5%] rounded-lg">
                        <span className="font-mono text-xs text-zinc-200 font-bold">{c.code} (<span className="text-brand-orange">{c.pct}% off</span>)</span>
                        <button
                          onClick={() => toggleCoupon(c.code)}
                          className={`px-2 py-0.5 rounded text-[9px] font-bold transition-all ${
                            c.active ? 'bg-teal-500/10 text-teal-400 border border-teal-500/10' : 'bg-zinc-850 text-zinc-550'
                          }`}
                        >
                          {c.active ? 'فعال و معتبر' : 'منقضی شده'}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SUBTAB 9: Course Catalog and Scenario CMS */}
        {activeAdminSubTab === 'cms' && (
          <div className="space-y-6 text-xs font-semibold animate-fadeIn">
            {/* Tab navigation buttons */}
            <div className="flex flex-wrap items-center gap-3 bg-zinc-950/60 p-2.5 rounded-2xl border border-white/5 mx-auto max-w-2xl justify-center">
              <button
                type="button"
                onClick={() => setCmsTab('courses')}
                className={`px-5 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${
                  cmsTab === 'courses'
                    ? 'bg-gradient-to-r from-brand-orange to-brand-red text-white shadow-lg shadow-brand-orange/10'
                    : 'text-zinc-400 hover:text-white hover:bg-white/[2%]'
                }`}
              >
                <BookOpen className="w-4 h-4" />
                <span>مدیریت مسترکلاس‌ها و ویدیوها</span>
              </button>
              <button
                type="button"
                onClick={() => setCmsTab('articles')}
                className={`px-5 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${
                  cmsTab === 'articles'
                    ? 'bg-gradient-to-r from-brand-orange to-brand-red text-white shadow-lg shadow-brand-orange/10'
                    : 'text-zinc-400 hover:text-white hover:bg-white/[2%]'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>مقاله‌ها و مستندات رشد</span>
              </button>
              <button
                type="button"
                onClick={() => setCmsTab('templates')}
                className={`px-5 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${
                  cmsTab === 'templates'
                    ? 'bg-gradient-to-r from-brand-orange to-brand-red text-white shadow-lg shadow-brand-orange/10'
                    : 'text-zinc-400 hover:text-white hover:bg-white/[2%]'
                }`}
              >
                <LayoutGrid className="w-4 h-4" />
                <span>قالب‌های سناریوبند هوشمند</span>
              </button>
              <button
                type="button"
                onClick={() => setCmsTab('inspirations')}
                className={`px-5 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${
                  cmsTab === 'inspirations'
                    ? 'bg-gradient-to-r from-brand-orange to-brand-red text-white shadow-lg shadow-brand-orange/10'
                    : 'text-zinc-400 hover:text-white hover:bg-white/[2%]'
                }`}
              >
                <Video className="w-4 h-4 text-brand-orange" />
                <span>مدیریت فید الهام‌گیری</span>
              </button>
            </div>

            {/* Render selected CMS sub-tab components */}
            {cmsTab === 'templates' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Scenarios CMS additions with step-by-step wizard */}
                <div className="rounded-2xl p-6 bg-zinc-950 border border-white/5 space-y-5 shadow-xl">
                  <div className="border-b border-white/5 pb-2">
                    <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-brand-orange border-none" />
                      جادوگر افزودن قالب سناریو (مرحله {tplWizardStep} از ۴)
                    </h3>
                    <p className="text-[10px] text-zinc-500">طراحی گام‌به‌گام و علمی الگوهای هوش مصنوعی</p>
                  </div>

                  {/* Horizontal step indicators */}
                  <div className="flex justify-between items-center bg-zinc-900/50 p-2.5 rounded-xl border border-white/[3%] text-[9px] font-bold">
                    <span className={tplWizardStep === 1 ? "text-brand-orange" : "text-zinc-500"}>۱. شناسنامه</span>
                    <span className="text-zinc-750">◀</span>
                    <span className={tplWizardStep === 2 ? "text-brand-orange" : "text-zinc-500"}>۲. مهندسی پرامپت</span>
                    <span className="text-zinc-750">◀</span>
                    <span className={tplWizardStep === 3 ? "text-brand-orange" : "text-zinc-500"}>۳. پیش‌تنظیم سبک</span>
                    <span className="text-zinc-750">◀</span>
                    <span className={tplWizardStep === 4 ? "text-brand-orange" : "text-zinc-500"}>۴. تایید و ثبت</span>
                  </div>

                  <div className="space-y-4 pt-2">
                    {/* STEP 1: Basic identity fields */}
                    {tplWizardStep === 1 && (
                      <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="space-y-3.5">
                        <div className="space-y-1.5">
                          <span className="text-[10px] text-zinc-400 font-bold block">نام یا عنوان قالب سناریو نویس</span>
                          <input
                            type="text"
                            value={newTplTitle}
                            onChange={(e) => setNewTplTitle(e.target.value)}
                            placeholder="مثال: قلاب طوفانی ولاگ لایف‌استایل"
                            className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white placeholder-zinc-700"
                          />
                        </div>

                        <div className="space-y-1.5">
                          <span className="text-[10px] text-zinc-400 font-bold block">دسته‌بندی موضوعی</span>
                          <select
                            value={newTplCategory}
                            onChange={(e) => setNewTplCategory(e.target.value)}
                            className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white focus:outline-none cursor-pointer"
                          >
                            <option value="برند شخصی و آموزشی">برند شخصی و آموزشی</option>
                            <option value="ولاگ سبک زندگی">ولاگ سبک زندگی</option>
                            <option value="تکنولوژی و آنباکسینگ">تکنولوژی و آنباکسینگ</option>
                            <option value="مد، فشن و استایل">مد، فشن و استایل</option>
                            <option value="کسب‌وکار، دندان‌پزشکی و کلینیک">کسب‌وکار، دندان‌پزشکی و کلینیک</option>
                          </select>
                        </div>
                      </motion.div>
                    )}

                    {/* STEP 2: Main engineering prompts template structure */}
                    {tplWizardStep === 2 && (
                      <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="space-y-3.5">
                        <div className="space-y-1.5">
                          <span className="text-[10px] text-zinc-400 font-bold block">الگوی پرامپت نویسی هوشمند ساو</span>
                          <textarea
                            value={newTplPrompt}
                            onChange={(e) => setNewTplPrompt(e.target.value)}
                            rows={5}
                            placeholder="مثال: سناریوی ریلز زیر ۳۰ ثانیه بنویس شامل قلاب عاطفی، بادی اصلی و دعوت به اقدام (CTA) مخفی..."
                            className="w-full p-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white resize-none placeholder-zinc-700 leading-relaxed font-mono"
                          />
                        </div>
                      </motion.div>
                    )}

                    {/* STEP 3: Presets of AI and cinematography style */}
                    {tplWizardStep === 3 && (
                      <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="space-y-3.5">
                        <div className="space-y-1.5">
                          <span className="text-[10px] text-zinc-400 font-bold block">پیش‌فرض لحن و استایل تدوین</span>
                          <select
                            value={newTplStyle}
                            onChange={(e) => setNewTplStyle(e.target.value)}
                            className="w-full px-4 py-2.5 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white focus:outline-none cursor-pointer"
                          >
                            <option value="سینماتیک و لوکس">🎬 سینماتیک لوکس تاریک</option>
                            <option value="کلاسیک ادیتورال">💎 کلاسیک ادیتورال پرمیوم</option>
                            <option value="بلاگری صمیمی">💖 صمیمی و پرانرژی بلاگری</option>
                            <option value="قصه‌گویی تاریک">🕴️ مهیج و پرتعلیق مستند</option>
                          </select>
                        </div>
                      </motion.div>
                    )}

                    {/* STEP 4: Confirm summary and list values */}
                    {tplWizardStep === 4 && (
                      <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="space-y-3 p-3.5 rounded-xl bg-[#0b0b0c] border border-white/5 text-xs text-zinc-400">
                        <div className="flex justify-between flex-row-reverse border-b border-white/[2%] pb-2">
                          <span className="text-zinc-500 font-bold">عنوان قالب سناریو:</span>
                          <span className="text-white font-extrabold">{newTplTitle || '(خالی)'}</span>
                        </div>
                        <div className="flex justify-between flex-row-reverse border-b border-white/[2%] pb-2">
                          <span className="text-zinc-500 font-bold">دسته‌بندی موضوعی:</span>
                          <span className="text-brand-orange font-bold">{newTplCategory}</span>
                        </div>
                        <div className="flex justify-between flex-row-reverse border-b border-white/[2%] pb-2">
                          <span className="text-zinc-500 font-bold">سبک پیش‌فرض:</span>
                          <span className="text-zinc-250 font-bold">{newTplStyle}</span>
                        </div>
                        <div className="space-y-1 pt-1">
                          <span className="text-zinc-500 block font-bold">ساختار پرامپت:</span>
                          <p className="font-mono text-[10.5px] p-2.5 bg-zinc-950 rounded text-zinc-400 leading-relaxed truncate max-h-[100px] overflow-hidden">{newTplPrompt || '(خالی)'}</p>
                        </div>
                      </motion.div>
                    )}

                    {/* Wizard controls switcher (Next / Back) */}
                    <div className="flex items-center justify-between border-t border-white/5 pt-4">
                      {tplWizardStep > 1 ? (
                        <button
                          type="button"
                          onClick={() => setTplWizardStep(p => p - 1)}
                          className="px-4 py-2 rounded-lg bg-zinc-900 hover:bg-zinc-805 text-[11px] font-bold text-zinc-350 cursor-pointer"
                        >
                          بازگشت به قبل
                        </button>
                      ) : (
                        <div />
                      )}

                      {tplWizardStep < 4 ? (
                        <button
                          type="button"
                          disabled={tplWizardStep === 1 && !newTplTitle.trim()}
                          onClick={() => setTplWizardStep(p => p + 1)}
                          className="px-5 py-2 rounded-lg bg-white hover:bg-zinc-200 text-zinc-950 text-[11px] font-black disabled:opacity-40 cursor-pointer"
                        >
                          مرحله بعدی
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            handleCreateTemplate();
                            setTplWizardStep(1);
                          }}
                          className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-brand-orange to-brand-red text-white text-[11px] font-black hover:opacity-95 shadow-xl transition-all cursor-pointer"
                        >
                          تایید و انتشار نهایی قالب سناریو
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Show template removals list */}
                  <div className="space-y-3 pt-4 border-t border-white/5">
                    <h4 className="text-[11px] text-zinc-400 font-bold">قالب‌های فعال سیستم رباتی ({templates.length})</h4>
                    <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                      {templates.map(tpl => (
                        <div key={tpl.id} className="flex justify-between items-center p-3.5 bg-white/[1.5%] rounded-xl">
                          <div className="space-y-1">
                            <span className="px-1.5 py-0.5 rounded bg-zinc-900 text-brand-orange text-[8px] font-bold">{tpl.category}</span>
                            <h5 className="text-white font-black text-xs">{tpl.title}</h5>
                          </div>
                          <button
                            type="button"
                            onClick={() => deleteTemplate(tpl.id)}
                            className="text-zinc-500 hover:text-rose-455 p-1 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {cmsTab === 'courses' && (
              <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
                {/* Main Step Wizard (size 8/12) */}
                <div className="xl:col-span-8 rounded-2xl p-6 bg-zinc-950 border border-white/5 space-y-6 shadow-xl relative overflow-hidden">
                  {/* Stepper Header */}
                  <div className="mb-6 bg-zinc-900/40 p-5 rounded-2xl border border-white/5">
                    <div className="flex justify-between items-center mb-4">
                      <div>
                        <span className="text-[10px] font-black tracking-wider uppercase text-brand-orange bg-brand-orange/15 px-3 py-1 rounded-full">
                          {editingCourseId ? 'حالت ویرایش مسترکلاس ساو' : 'ساخت مسترکلاس جدید'}
                        </span>
                        {editingCourseId && (
                          <span className="text-[10px] text-zinc-400 mr-2 font-bold bg-white/5 px-2.5 py-1 rounded-full">
                            درحال ویرایش شناسه: {editingCourseId}
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] font-bold text-zinc-400 font-mono">مرحله {courseWizardStep} از ۴</span>
                    </div>

                    {/* Progress Bar and Step dots */}
                    <div className="relative pt-2 pb-1">
                      <div className="absolute top-[26px] left-[10%] right-[10%] h-[2px] bg-zinc-800 -z-0">
                        <div 
                          className="h-full bg-brand-orange transition-all duration-500"
                          style={{ width: `${((courseWizardStep - 1) / 3) * 100}%` }}
                        />
                      </div>
                      
                      <div className="relative z-10 flex justify-between items-center px-4">
                        {[
                          { num: 1, label: 'اطلاعات پایه', desc: 'عنوان، کاور، معرفی' },
                          { num: 2, label: 'جزئیات دوره', desc: 'قیمت، سطح، زمان' },
                          { num: 3, label: 'سرفصل‌ها', desc: 'ویدیوها و جزوات' },
                          { num: 4, label: 'تنظیمات نهایی', desc: 'سئو و انتشار' }
                        ].map((s) => {
                          const isActive = courseWizardStep === s.num;
                          const isCompleted = courseWizardStep > s.num;
                          return (
                            <button 
                              type="button"
                              key={s.num} 
                              onClick={() => setCourseWizardStep(s.num)}
                              className="flex flex-col items-center gap-1.5 focus:outline-none focus:ring-0 group"
                            >
                              <div className={`w-9 h-9 rounded-full flex items-center justify-center font-mono font-bold text-xs transition-all duration-300 ${
                                isActive 
                                  ? 'bg-brand-orange text-white ring-4 ring-brand-orange/20 scale-110 shadow-lg shadow-brand-orange/25 font-black' 
                                  : isCompleted 
                                    ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/15' 
                                    : 'bg-zinc-900 text-zinc-550 border border-white/5 group-hover:border-zinc-500'
                              }`}>
                                {isCompleted ? <Check className="w-4 h-4 text-white stroke-[3px]" /> : s.num}
                              </div>
                              <span className={`text-[10px] font-black transition-all ${
                                isActive ? 'text-brand-orange' : 'text-zinc-500 group-hover:text-zinc-400'
                              }`}>{s.label}</span>
                              <span className="hidden sm:block text-[8px] text-zinc-600 transition-all font-sans">
                                {s.desc}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Steps Content Area with Animated Entrance */}
                  <AnimatePresence mode="wait">
                    {courseWizardStep === 1 && (
                      <motion.div 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 10 }}
                        className="space-y-4"
                        key="course-step-1"
                      >
                        <div className="border-b border-white/5 pb-2">
                          <h3 className="text-xs font-black text-white flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-brand-orange"></span>
                            گام ۱: مشخصات کلان و هویت بصری مسترکلاس
                          </h3>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-1.5">
                            <span className="text-[10px] text-zinc-450 font-bold">نام و عنوان دوره آموزشی</span>
                            <input
                              type="text"
                              placeholder="مثال: مسترکلاس فوق‌حرفه‌ای تدوین سینمایی با پریمیر"
                              className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white focus:outline-none focus:border-brand-orange font-bold text-emerald-400"
                              value={newCourseTitle}
                              onChange={(e) => setNewCourseTitle(e.target.value)}
                            />
                          </div>

                          <div className="space-y-1.5">
                            <span className="text-[10px] text-zinc-450 font-bold">دسته‌بندی موضوعی مسترکلاس</span>
                            <select
                              value={newCourseCategory}
                              onChange={(e) => setNewCourseCategory(e.target.value)}
                              className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white focus:outline-none focus:border-brand-orange font-bold text-zinc-300"
                            >
                              <option value="سناریونویسی">سناریونویسی و قلاب</option>
                              <option value="تدوین موبایلی">تدوین ریتمیک موبایلی</option>
                              <option value="تکنیک‌های رشد">رشد و الگوریتم اینستاگرام</option>
                              <option value="کسب درآمد">کسب درآمد و مذاکره با کارفرما</option>
                            </select>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <span className="text-[10px] text-zinc-450 font-bold block">تصویر شاخص / بنر کاور مسترکلاس</span>
                          <div className="flex gap-3">
                            <input
                              type="text"
                              className="flex-1 px-3.5 py-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-zinc-350 font-mono text-left"
                              dir="ltr"
                              value={newCourseImage}
                              onChange={(e) => setNewCourseImage(e.target.value)}
                              placeholder="https://images.unsplash.com/..."
                            />
                            {newCourseImage && (
                              <img src={newCourseImage} className="w-12 h-10 rounded-lg object-cover border border-white/10 shrink-0" referrerPolicy="no-referrer" />
                            )}
                          </div>
                          
                          {/* Quick Cover Presets */}
                          <div className="space-y-1.5 pt-1.5">
                            <span className="text-[8px] text-zinc-550 font-bold">انتخاب سریع عکس کاور شیک برای تست:</span>
                            <div className="grid grid-cols-4 gap-2">
                              {[
                                { url: 'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&w=400&q=80', label: 'دکوپاژ حرفه‌ای' },
                                { url: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=400&q=80', label: 'تدوین با سیستم' },
                                { url: 'https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=400&q=80', label: 'سینماتوگرافی' },
                                { url: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=400&q=80', label: 'اتاق گیمینگ لوکس' }
                              ].map((preset, idx) => (
                                <button
                                  type="button"
                                  key={idx}
                                  onClick={() => setNewCourseImage(preset.url)}
                                  className={`p-1.5 bg-zinc-900 rounded-lg border text-[8px] font-black text-center truncate transition-all ${
                                    newCourseImage === preset.url ? 'border-brand-orange text-brand-orange bg-brand-orange/5' : 'border-white/5 text-zinc-500 hover:text-white'
                                  }`}
                                >
                                  {preset.label}
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="space-y-1.5">
                          <span className="text-[10px] text-zinc-450 font-bold mb-1 block">توضیحات مفصل و بدنه معرفی دوره (واژه‌پرداز غنی)</span>
                          <WordProcessor
                            value={newCourseDesc}
                            onChange={setNewCourseDesc}
                            placeholder="متن کامل و سناریوی معرفی دوره خود را با ابزارهای لوکس بنویسید..."
                            label="توضیحات کلان دوره"
                          />
                        </div>
                      </motion.div>
                    )}

                    {courseWizardStep === 2 && (
                      <motion.div 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 10 }}
                        className="space-y-4"
                        key="course-step-2"
                      >
                        <div className="border-b border-white/5 pb-2">
                          <h3 className="text-xs font-black text-white flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-brand-orange"></span>
                            گام ۲: جزئیات مالی و مشخصات فنی مسترکلاس
                          </h3>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-1.5">
                            <span className="text-[10px] text-zinc-450 font-bold">بهای ثبت‌نام مسترکلاس (تومان)</span>
                            <input
                              type="number"
                              className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white font-mono text-center focus:outline-none focus:border-brand-orange"
                              value={newCoursePrice}
                              onChange={(e) => setNewCoursePrice(Number(e.target.value))}
                            />
                            
                            <div className="flex gap-1.5 justify-center pt-1">
                              {[0, 990000, 1900000, 2900000].map((pr) => (
                                <button
                                  type="button"
                                  key={pr}
                                  onClick={() => setNewCoursePrice(pr)}
                                  className={`px-2 py-1 text-[8px] rounded font-mono font-bold ${
                                    newCoursePrice === pr ? 'bg-brand-orange/20 text-brand-orange border border-brand-orange/25' : 'bg-zinc-900 text-zinc-500 hover:text-white'
                                  }`}
                                >
                                  {pr === 0 ? 'رایگان' : `${(pr/1000000).toFixed(1)}M`}
                                </button>
                              ))}
                            </div>
                          </div>

                          <div className="space-y-1.5">
                            <span className="text-[10px] text-zinc-450 font-bold">مدت زمان تقریبی تدریس (ساعت)</span>
                            <input
                              type="text"
                              className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white font-semibold text-center"
                              placeholder="مثال: ۱۲ ساعت و ۳۰ دقیقه"
                              value={newCourseDurationHours}
                              onChange={(e) => setNewCourseDurationHours(e.target.value)}
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-1.5">
                            <span className="text-[10px] text-zinc-450 font-bold">سطح پیش‌نیاز آموزشی مسترکلاس</span>
                            <select
                              value={newCourseLevel}
                              onChange={(e) => setNewCourseLevel(e.target.value)}
                              className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white"
                            >
                              <option value="مبتدی">مبتدی (بدون نیاز به تجربه قبلی)</option>
                              <option value="متوسط">متوسط (آشنایی با ابزارهای اولیه)</option>
                              <option value="پیشرفته">پیشرفته (ویژه استخدام و اخذ پروژه‌های فریلنسری بزرگ)</option>
                            </select>
                          </div>

                          <div className="space-y-1.5">
                            <span className="text-[10px] text-zinc-450 font-bold">وضعیت انتشار مسترکلاس</span>
                            <select
                              value={newCourseStatus}
                              onChange={(e) => setNewCourseStatus(e.target.value as any)}
                              className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white font-bold text-amber-400"
                            >
                              <option value="published">منـتشر شده (نمایش و قابل دسترسی برای خریداران)</option>
                              <option value="draft">پیش‌نویس (مخفی تا اتمام کامل ویرایش و ضبط جلسات)</option>
                            </select>
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {courseWizardStep === 3 && (
                      <motion.div 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 10 }}
                        className="space-y-4"
                        key="course-step-3"
                      >
                        <div className="border-b border-white/5 pb-2 flex justify-between items-center">
                          <h3 className="text-xs font-black text-white flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-brand-orange"></span>
                            گام ۳: سرفصل نویسی و پیوست ویدیوها (کتابخانه قسمت‌ها)
                          </h3>
                          <span className="text-[9px] bg-brand-orange/20 text-brand-orange font-bold px-2.5 py-0.5 rounded-full">
                            تعداد جلسات: {tempLessons.length} قسمت
                          </span>
                        </div>

                        {/* Local Episode compiler form */}
                        <div className="p-4 rounded-2xl bg-zinc-900/30 border border-white/5 space-y-3.5">
                          <span className="text-[10px] text-zinc-300 font-black block text-brand-orange">فرم افزودن جلسه جدید به این مسترکلاس</span>
                          
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div className="space-y-1">
                              <span className="text-[9px] text-zinc-450">عنوان جلسه / سرفصل</span>
                              <input
                                type="text"
                                placeholder="مثال: جلسه اول - اصول نورپردازی نئون در تاریکی"
                                className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-white/10 text-xs text-white"
                                value={newLessonTitle}
                                onChange={(e) => setNewLessonTitle(e.target.value)}
                              />
                            </div>
                            
                            <div className="grid grid-cols-2 gap-2">
                              <div className="space-y-1">
                                <span className="text-[9px] text-zinc-450 text-center block">مدت زمان (دقیقه)</span>
                                <input
                                  type="text"
                                  placeholder="مثال: 12:45"
                                  className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-white/10 text-xs text-white font-mono text-center"
                                  value={newLessonDuration}
                                  onChange={(e) => setNewLessonDuration(e.target.value)}
                                />
                              </div>
                              <div className="space-y-1">
                                <span className="text-[9px] text-zinc-450 text-center block">نوع محتوای جلسه</span>
                                <select
                                  value={newLessonContentType}
                                  onChange={(e) => setNewLessonContentType(e.target.value as any)}
                                  className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-white/10 text-xs text-white"
                                >
                                  <option value="video">ویدیو پروژه‌محور</option>
                                  <option value="text">مکتوب آموزشی</option>
                                  <option value="both">دوگانه (ویدیو + مکتوب)</option>
                                </select>
                              </div>
                            </div>
                          </div>

                          {/* Video uploader & direct URL entry */}
                          {newLessonContentType !== 'text' && (
                            <div className="p-3.5 rounded-xl bg-zinc-950 border border-white/5 space-y-3">
                              
                              <div 
                                className="border border-dashed border-white/10 hover:border-brand-orange/40 rounded-xl p-3 text-center cursor-pointer bg-zinc-900/40"
                                onClick={() => {
                                  const input = document.createElement('input');
                                  input.type = 'file';
                                  input.accept = 'video/*';
                                  input.onchange = (e) => {
                                    const file = (e.target as any).files?.[0];
                                    if (file) handleVideoUploadSimulate(file.name);
                                  };
                                  input.click();
                                }}
                              >
                                {isUploading ? (
                                  <div className="space-y-1.5 py-1">
                                    <RefreshCw className="w-5 h-5 text-brand-orange animate-spin mx-auto" />
                                    <span className="text-[9px] text-zinc-300 block">آپلود امن ویدیو به کلود ساو ({uploadProgress}%)</span>
                                  </div>
                                ) : uploadFileName ? (
                                  <div className="space-y-0.5 py-1">
                                    <CheckCircle className="w-5 h-5 text-emerald-400 mx-auto" />
                                    <span className="text-[9px] text-emerald-300 block font-bold">✓ آپلود کامل در مخزن به وقوع پیوست</span>
                                  </div>
                                ) : (
                                  <div className="space-y-1 py-1">
                                    <Upload className="w-5 h-5 text-zinc-550 mx-auto" strokeWidth={1.5} />
                                    <span className="text-[9px] text-zinc-400 block font-bold">آپلود سریع با فشرده‌ساز محلی ساو (کلیک کنید)</span>
                                  </div>
                                )}
                              </div>

                              <div className="flex items-center gap-2">
                                <span className="text-[8px] text-zinc-500 font-mono font-bold shrink-0">URL مستقیم:</span>
                                <input
                                  type="text"
                                  className="w-full px-2.5 py-1.5 rounded bg-zinc-900 border border-white/5 text-[9px] text-zinc-300 font-mono"
                                  dir="ltr"
                                  value={newLessonVideoUrl}
                                  onChange={(e) => setNewLessonVideoUrl(e.target.value)}
                                  placeholder="https://test-link.com/lesson.mp4"
                                />
                              </div>
                            </div>
                          )}

                          <div className="space-y-1">
                            <span className="text-[9px] text-zinc-450 block">خلاصه سریع یا یادداشت آموزشی این فصل</span>
                            <input
                              type="text"
                              className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-white/10 text-xs text-white"
                              placeholder="مثال: در این جلسه یاد می‌گیریم چطور با کانال صوتی فرکانس ۷۰ هرتز کار کنیم..."
                              value={newLessonSummary}
                              onChange={(e) => setNewLessonSummary(e.target.value)}
                            />
                          </div>

                          <div className="space-y-1.5">
                            <span className="text-[9px] text-zinc-450 block">متن مکمل یا متن درس (WordProcessor)</span>
                            <WordProcessor
                              value={newLessonRichContent}
                              onChange={setNewLessonRichContent}
                              placeholder="جزوه متنی، تگ‌ها و کدهای این جلسه..."
                              label="جزوه جلسه"
                            />
                          </div>

                          <button
                            type="button"
                            onClick={() => {
                              if (!newLessonTitle.trim()) {
                                alert('عنوان جلسه الزامی است.');
                                return;
                              }
                              const lessonId = 'l_' + Math.random().toString(36).substr(2, 9);
                              const newLes = {
                                id: lessonId,
                                title: newLessonTitle,
                                videoUrl: newLessonVideoUrl || 'https://assets.mixkit.co/videos/preview/mixkit-typing-on-a-glowing-neon-keyboard-41712-large.mp4',
                                duration: newLessonDuration || '12:00',
                                summary: newLessonSummary || 'توضیحات تکمیلی اضافه شده از واژه‌پرداز.',
                                contentType: newLessonContentType,
                                richContent: newLessonRichContent
                              };
                              setTempLessons(prev => [...prev, newLes]);
                              
                              // Reset
                              setNewLessonTitle('');
                              setNewLessonVideoUrl('');
                              setNewLessonDuration('12:00');
                              setNewLessonSummary('');
                              setNewLessonRichContent('');
                              setUploadFileName('');
                              setUploadProgress(0);
                            }}
                            className="w-full py-2 bg-zinc-100 hover:bg-white text-zinc-950 text-xs font-black rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <PlusCircle className="w-4 h-4 text-zinc-950" />
                            <span>ثبت سرفصل و افزودن به جدول</span>
                          </button>
                        </div>

                        {/* List Added Lessons inside Local state */}
                        <div className="space-y-3 pt-3">
                          <h4 className="text-[10px] text-zinc-400 font-bold">لیست سرفصل‌های اختصاص یافته در این گام ({tempLessons.length})</h4>
                          <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                            {tempLessons.map((les, index) => (
                              <div key={les.id} className="flex justify-between items-center p-3 bg-zinc-900/60 border border-white/5 rounded-xl">
                                <div className="flex gap-2.5 items-center">
                                  <span className="w-5 h-5 rounded-full bg-zinc-850 border border-white/10 flex items-center justify-center text-[10px] text-zinc-400 font-mono font-bold">
                                    {index + 1}
                                  </span>
                                  <div>
                                    <h5 className="text-white font-bold text-xs">{les.title}</h5>
                                    <div className="flex gap-2 items-center mt-0.5 text-[9px] text-zinc-500 font-mono">
                                      <span>زمان: {les.duration} دقیقه</span>
                                      <span>•</span>
                                      <span className="text-amber-400">{les.contentType === 'text' ? 'مطلب متنی' : les.contentType === 'both' ? 'ویدیو + جزوه' : 'فقط ویدیو'}</span>
                                    </div>
                                  </div>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => setTempLessons(prev => prev.filter(l => l.id !== les.id))}
                                  className="text-zinc-500 hover:text-red-500 p-1.5 bg-zinc-950 rounded-lg border border-white/5"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ))}
                            {tempLessons.length === 0 && (
                              <p className="text-center py-8 text-zinc-650 text-[10px]">هیچ فصلی تعریف نشده است. لطفا از کادر بالا چند مبحث درسی را وارد کنید.</p>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {courseWizardStep === 4 && (
                      <motion.div 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 10 }}
                        className="space-y-4"
                        key="course-step-4"
                      >
                        <div className="border-b border-white/5 pb-2">
                          <h3 className="text-xs font-black text-white flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-brand-orange"></span>
                            گام ۴: سئو بهینه، کلمات کلیدی و پیش‌نمایش نهایی
                          </h3>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-1.5">
                            <span className="text-[10px] text-zinc-450 font-bold">عنوان مرورگر (Seo Title)</span>
                            <input
                              type="text"
                              value={newCourseSeoTitle || newCourseTitle}
                              onChange={(e) => setNewCourseSeoTitle(e.target.value)}
                              placeholder="عنوان متا تایتل سئو گوگل"
                              className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white"
                            />
                          </div>

                          <div className="space-y-1.5">
                            <span className="text-[10px] text-zinc-450 font-bold">تگ‌ها و کلمات کلیدی (باکامبول تفکیک شود)</span>
                            <input
                              type="text"
                              value={newCourseTags}
                              onChange={(e) => setNewCourseTags(e.target.value)}
                              placeholder="ریلز, تولید محتوا, ادیت حرفه‌ای, ساو"
                              className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-amber-300 font-mono"
                            />
                          </div>
                        </div>

                        <div className="space-y-1.5">
                          <span className="text-[10px] text-zinc-450 font-bold">توضیحات کوتاه متادر گوگل (Meta Description)</span>
                          <textarea
                            value={newCourseSeoDesc}
                            onChange={(e) => setNewCourseSeoDesc(e.target.value)}
                            rows={3}
                            placeholder="خلاصه دوره که کاربران در گوگل می‌بینند..."
                            className="w-full p-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-zinc-200 resize-none leading-relaxed"
                          />
                        </div>

                        <div className="space-y-3 pt-2">
                          <span className="text-[10px] text-zinc-450 font-bold block">کارت پیش‌نمایش زنده در پورتال کاربران :</span>
                          
                          {/* Live preview card */}
                          <div className="p-4 rounded-2xl bg-zinc-900/60 border border-white/10 max-w-sm mx-auto space-y-4 shadow-2xl relative overflow-hidden group">
                            {/* Course Banner */}
                            <div className="relative aspect-video rounded-xl overflow-hidden bg-zinc-950 border border-white/5">
                              {newCourseImage ? (
                                <img src={newCourseImage} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                              ) : (
                                <div className="absolute inset-0 flex items-center justify-center text-zinc-650 text-xs">بدون تصویر</div>
                              )}
                              <span className="absolute top-2.5 right-2.5 bg-zinc-950/80 backdrop-blur-md text-brand-orange font-bold text-[8px] px-2 py-0.5 rounded border border-brand-orange/20">
                                {newCourseCategory}
                              </span>
                            </div>

                            <div className="space-y-2">
                              <div className="flex justify-between items-center text-[9px] text-zinc-500">
                                <span className="font-mono">{newCourseDurationHours || '۰ ساعت'}</span>
                                <span className="font-sans font-bold bg-white/5 text-zinc-300 px-2 py-0.5 rounded">{newCourseLevel}</span>
                              </div>
                              <h4 className="text-white font-black text-xs text-right leading-relaxed truncate">{newCourseTitle || 'موضوع مسترکلاس ساو'}</h4>
                              
                              <div className="flex justify-between items-center text-xs pt-2 border-t border-white/5">
                                <span className="text-[9px] text-zinc-500">{tempLessons.length} جلسه آموزش صوتی و تصویری</span>
                                <span className="text-emerald-400 font-mono font-bold">
                                  {newCoursePrice === 0 ? 'کاملاً رایگان' : `${newCoursePrice.toLocaleString()} تومان`}
                                </span>
                              </div>
                            </div>

                            {/* Status badge */}
                            <div className="absolute bottom-2.5 left-2.5 text-[8px]">
                              {newCourseStatus === 'published' ? (
                                <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded font-bold">✓ منتشر شده</span>
                              ) : (
                                <span className="bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded font-bold">✏ پیش‌نویس</span>
                              )}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Stepper Wizard Control buttons */}
                  <div className="flex justify-between items-center pt-5 border-t border-white/5">
                    <div className="flex gap-2">
                      {courseWizardStep > 1 ? (
                        <button
                          type="button"
                          onClick={() => setCourseWizardStep(prev => prev - 1)}
                          className="px-4 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 text-xs font-black rounded-xl transition-all flex items-center gap-1 cursor-pointer border border-white/5"
                        >
                          <ChevronRight className="w-4 h-4" />
                          <span>مرحله قبلی</span>
                        </button>
                      ) : (
                        <div className="w-12"></div>
                      )}

                      {/* Quick Save Draft Button */}
                      <button
                        type="button"
                        onClick={handleSaveCourseDraft}
                        className="px-4 py-2.5 bg-amber-500/10 hover:bg-amber-550/20 text-amber-400 text-xs font-black rounded-xl transition-all border border-amber-400/20 flex items-center gap-1.5 cursor-pointer"
                        title="ذخیره موقت اطلاعات بدون انتشار"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>ذخیره چرک‌نویس</span>
                      </button>
                    </div>

                    <div className="flex gap-2">
                      {editingCourseId && (
                        <button
                          type="button"
                          onClick={handleCancelCourseEdit}
                          className="px-4 py-2.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs font-black rounded-xl transition-all border border-red-500/20 cursor-pointer"
                        >
                          لغو ویرایش
                        </button>
                      )}

                      {courseWizardStep < 4 ? (
                        <button
                          type="button"
                          onClick={() => setCourseWizardStep(prev => prev + 1)}
                          className="px-5 py-2.5 bg-white hover:bg-zinc-200 text-zinc-950 text-xs font-black rounded-xl transition-all flex items-center gap-1 cursor-pointer"
                        >
                          <span>مرحله بعدی</span>
                          <ChevronLeft className="w-4 h-4 text-zinc-950" />
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            if (!newCourseTitle.trim()) {
                              alert('نام مکتوب دوره الزامی است. لطفاً به گام ۱ بازگردید.');
                              setCourseWizardStep(1);
                              return;
                            }
                            
                            // Call submit handler which manages both creation / editing
                            handleCreateCourse();
                          }}
                          className="px-6 py-2.5 bg-gradient-to-r from-teal-500 to-emerald-600 hover:opacity-95 text-white text-xs font-black rounded-xl transition-all shadow-lg shadow-emerald-500/10 shrink-0"
                        >
                          {editingCourseId ? 'ثبت بروزرسانی دوره' : 'ذخیره و انتشار نهایی'}
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right col: masterclass list with Edit capability (size 4/12) */}
                <div className="xl:col-span-4 rounded-2xl p-6 bg-zinc-950 border border-white/5 space-y-4 shadow-xl">
                  <div className="border-b border-white/5 pb-2">
                    <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                      <BookOpen className="w-4 h-4 text-brand-orange" />
                      مدیریت دوره‌های فعال
                    </h3>
                    <p className="text-[10px] text-zinc-550">تعداد کل بسته‌های روی سایت ({courses.length})</p>
                  </div>

                  <div className="space-y-3.5 max-h-[580px] overflow-y-auto pr-1">
                    {courses.map(course => {
                      const isEditingThis = editingCourseId === course.id;
                      return (
                        <div 
                          key={course.id} 
                          className={`p-3 bg-zinc-900/40 rounded-xl hover:bg-zinc-900 transition-all border ${
                            isEditingThis ? 'border-brand-orange bg-brand-orange/[2%]' : 'border-white/5'
                          }`}
                        >
                          <div className="flex gap-2.5 items-center">
                            <img src={course.image} className="w-16 h-10 rounded-lg object-cover border border-white/5 shrink-0" referrerPolicy="no-referrer" />
                            <div className="flex-1 min-w-0">
                              <h5 className="text-white font-bold text-xs truncate">{course.title}</h5>
                              <div className="flex items-center gap-1.5 mt-1">
                                <span className="text-[8px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400">{course.category}</span>
                                <span className="text-[9px] text-zinc-500 font-mono">
                                  {course.lessons?.length || 0} جلسه
                                </span>
                              </div>
                            </div>
                          </div>

                          <div className="flex justify-between items-center mt-3 pt-2.5 border-t border-white/5 text-[9px]">
                            <span className="text-amber-400 font-mono font-bold">
                              {course.price === 0 ? 'رایگان' : `${course.price.toLocaleString()} تومان`}
                            </span>
                            
                            <div className="flex gap-1.5">
                              {/* Edit triggers wizard loading */}
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingCourseId(course.id);
                                  setNewCourseTitle(course.title);
                                  setNewCourseDesc(course.description);
                                  setNewCoursePrice(course.price);
                                  setNewCourseCategory(course.category);
                                  setNewCourseImage(course.image);
                                  setNewCourseStatus(course.isPremium ? 'published' : 'draft');
                                  setNewCourseLevel('متوسط');
                                  setNewCourseDurationHours('۱۰ ساعت');
                                  setNewCourseSeoTitle(course.title);
                                  setNewCourseSeoDesc(course.description.substring(0, 160));
                                  setTempLessons(course.lessons || []);
                                  setCourseWizardStep(1);
                                }}
                                className="px-2.5 py-1 bg-white/5 hover:bg-brand-orange hover:text-white rounded-lg text-zinc-300 transition-all flex items-center gap-1 border border-white/5 font-bold"
                              >
                                <Edit2 className="w-3 h-3" />
                                <span>ویرایش مرحله‌ای</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  if (confirm(`آیا از حذف مسترکلاس "${course.title}" مطمئن هستید؟`)) {
                                    deleteCourse(course.id);
                                  }
                                }}
                                className="p-1 text-zinc-500 hover:text-red-500 bg-white/5 rounded-lg border border-white/5"
                                title="حذف"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                    {courses.length === 0 && (
                      <p className="text-center py-12 text-zinc-650 text-xs">هیچ دوره‌ای در پلتفرم وجود ندارد.</p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {cmsTab === 'articles' && (
              <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
                {/* Article Wizard (size 8/12) */}
                <div className="xl:col-span-8 rounded-2xl p-6 bg-zinc-950 border border-white/5 space-y-6 shadow-xl relative overflow-hidden">
                  
                  {/* Stepper Header */}
                  <div className="mb-6 bg-zinc-900/40 p-5 rounded-2xl border border-white/5">
                    <div className="flex justify-between items-center mb-4">
                      <div>
                        <span className="text-[10px] font-black tracking-wider uppercase text-brand-orange bg-brand-orange/15 px-3 py-1 rounded-full">
                          {editingBlogId ? 'حالت ویرایش مقاله علمی ساو' : 'ساخت مقاله علمی جدید'}
                        </span>
                        {editingBlogId && (
                          <span className="text-[10px] text-zinc-400 mr-2 font-bold bg-white/5 px-2.5 py-1 rounded-full">
                            درحال ویرایش شناسه: {editingBlogId}
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] font-bold text-zinc-400 font-mono">مرحله {articleWizardStep} از ۴</span>
                    </div>

                    {/* Progress Bar and Step dots */}
                    <div className="relative pt-2 pb-1">
                      <div className="absolute top-[26px] left-[10%] right-[10%] h-[2px] bg-zinc-800 -z-0">
                        <div 
                          className="h-full bg-brand-orange transition-all duration-500"
                          style={{ width: `${((articleWizardStep - 1) / 3) * 100}%` }}
                        />
                      </div>
                      
                      <div className="relative z-10 flex justify-between items-center px-4">
                        {[
                          { num: 1, label: 'اطلاعات پایه', desc: 'موضوع و طبقه‌بندی' },
                          { num: 2, label: 'متن اصلی', desc: 'واژه‌پرداز غنی مقاله' },
                          { num: 3, label: 'تنظیمات سئو', desc: 'جستجوی بهینه گوگل' },
                          { num: 4, label: 'انتشار و پیش‌نمایش', desc: 'انتشار نهایی کار' }
                        ].map((s) => {
                          const isActive = articleWizardStep === s.num;
                          const isCompleted = articleWizardStep > s.num;
                          return (
                            <button 
                              type="button"
                              key={s.num} 
                              onClick={() => setArticleWizardStep(s.num)}
                              className="flex flex-col items-center gap-1.5 focus:outline-none focus:ring-0 group"
                            >
                              <div className={`w-9 h-9 rounded-full flex items-center justify-center font-mono font-bold text-xs transition-all duration-300 ${
                                isActive 
                                  ? 'bg-brand-orange text-white ring-4 ring-brand-orange/20 scale-110 shadow-lg shadow-brand-orange/25 font-black' 
                                  : isCompleted 
                                    ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/15' 
                                    : 'bg-zinc-900 text-zinc-550 border border-white/5 group-hover:border-zinc-500'
                              }`}>
                                {isCompleted ? <Check className="w-4 h-4 text-white stroke-[3px]" /> : s.num}
                              </div>
                              <span className={`text-[10px] font-black transition-all ${
                                isActive ? 'text-brand-orange' : 'text-zinc-500 group-hover:text-zinc-400'
                              }`}>{s.label}</span>
                              <span className="hidden sm:block text-[8px] text-zinc-600 transition-all font-sans text-center">
                                {s.desc}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Steps Content Area with Animated Entrance */}
                  <AnimatePresence mode="wait">
                    {articleWizardStep === 1 && (
                      <motion.div 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 10 }}
                        className="space-y-4"
                        key="article-step-1"
                      >
                        <div className="border-b border-white/5 pb-2">
                          <h3 className="text-xs font-black text-white flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-brand-orange"></span>
                            گام ۱: مشخصات کلی و موضوع مقاله علمی
                          </h3>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-1.5">
                            <span className="text-[10px] text-zinc-450 font-bold">عنوان مقاله علمی</span>
                            <input
                              type="text"
                              className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white focus:outline-none focus:border-brand-orange font-bold text-emerald-400"
                              placeholder="مثال: روش‌های طلایی تدوین ریتمیک ویدیو"
                              value={newBlogTitle}
                              onChange={(e) => setNewBlogTitle(e.target.value)}
                            />
                          </div>

                          <div className="space-y-1.5">
                            <span className="text-[10px] text-zinc-450 font-bold">طبقه‌بندی و دسته‌بندی موضوعی</span>
                            <select
                              value={newBlogCategory}
                              onChange={(e) => setNewBlogCategory(e.target.value)}
                              className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white"
                            >
                              <option value="الگوریتم رشد">الگوریتم رشد و تولید</option>
                              <option value="تکنیک‌های تدوین">تکنیک‌ها و ادیت حرفه‌ای</option>
                              <option value="تجهیزات و دوربین">تجهیزات صحنه و دوربین</option>
                              <option value="سناریونویسی ریلز">سناریونویسی و قلاب</option>
                            </select>
                          </div>
                        </div>

                        <div className="space-y-1 bg-zinc-900/20 p-4 rounded-xl border border-white/5 leading-relaxed">
                          <span className="text-[10px] text-zinc-450 font-black block text-amber-400 mb-1">راهنمای انتشار مقالات در ساو:</span>
                          <p className="text-[9px] text-zinc-500 leading-relaxed">نام‌نویسی و تولید محتوای ارزشمند علمی به مخاطبان کمک می‌کند شما را به عنوان برند برتر بشناسند. در گام بعدی با استفاده از واژه‌پرداز غنی، متن، نگاره‌ها و نمونه کد سناریو را وارد نمایید.</p>
                        </div>
                      </motion.div>
                    )}

                    {articleWizardStep === 2 && (
                      <motion.div 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 10 }}
                        className="space-y-4"
                        key="article-step-2"
                      >
                        <div className="border-b border-white/5 pb-2">
                          <h3 className="text-xs font-black text-white flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-brand-orange"></span>
                            گام ۲: بدنه غنی و ویرایشگر صوتی مقالات
                          </h3>
                        </div>

                        <div className="space-y-1.5">
                          <span className="text-[10px] text-zinc-450 font-bold mb-1 block">متن و نگاره‌های مقاله (واژه‌پرداز جامع)</span>
                          <WordProcessor
                            value={newBlogContent}
                            onChange={setNewBlogContent}
                            placeholder="متن کامل و سناریوهای مقاله علمی را اینجا بنویسید. می‌توانید عکس‌ها هم در آن بیفزایید..."
                            label="واژه‌پرداز مقالات"
                          />
                        </div>
                      </motion.div>
                    )}

                    {articleWizardStep === 3 && (
                      <motion.div 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 10 }}
                        className="space-y-4"
                        key="article-step-3"
                      >
                        <div className="border-b border-white/5 pb-2">
                          <h3 className="text-xs font-black text-white flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-brand-orange"></span>
                            گام ۳: سئو، کلمات کلیدی و جستجوی گوگل
                          </h3>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-1.5">
                            <span className="text-[10px] text-zinc-450 font-bold">عنوان سئوی مقاله در متاتایتل گوگل</span>
                            <input
                              type="text"
                              className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white"
                              placeholder="عنوان تمیز مکتوب برای مرورگر گوگل"
                              value={newBlogSeo}
                              onChange={(e) => setNewBlogSeo(e.target.value)}
                            />
                          </div>

                          <div className="space-y-1.5">
                            <span className="text-[10px] text-zinc-450 font-bold">کلمات کلیدی مقاله (با کاما جدا شود)</span>
                            <input
                              type="text"
                              className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-zinc-350 font-mono"
                              placeholder="تدوین, رشد, اینستاگرام, ساو, تدوین ریتمیک"
                              value={newBlogKeywords}
                              onChange={(e) => setNewBlogKeywords(e.target.value)}
                            />
                          </div>
                        </div>

                        <div className="space-y-1.5">
                          <span className="text-[10px] text-zinc-450 font-bold block">لینک ویدیو تصویری ضمیمه (لینک آپلود مستقیم یا یوتیوب/آپارات)</span>
                          <input
                            type="text"
                            className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white text-left font-mono"
                            dir="ltr"
                            placeholder="https://assets.mixkit.co/videos/preview/mixkit-..."
                            value={newBlogVideoUrl}
                            onChange={(e) => setNewBlogVideoUrl(e.target.value)}
                          />
                          <span className="text-[8.5px] text-zinc-550 block">با پر کردن این فیلد، یک پلیر شیک و جذاب بالای بدنه مقاله صادر خواهد شد.</span>
                        </div>

                        <div className="bg-[#090a0b] p-4 rounded-xl border border-white/5">
                          <span className="text-[9px] text-zinc-500 font-bold block mb-1">پیش‌نمایش ارگانیک جستجوی گوگل :</span>
                          <div className="space-y-1">
                            <p className="text-blue-400 hover:underline text-xs" dir="ltr">https://sav.academy/blog/{(newBlogTitle || 'post').replace(/\s+/g, '-')}</p>
                            <h4 className="text-teal-400 font-bold text-xs">{newBlogSeo || newBlogTitle || 'عنوان سئوی مقاله شما در گوگل'}</h4>
                            <p className="text-[10px] text-zinc-450">مقاله‌ جامع به قلم مدرسین آکادمی ساو در زمینه {newBlogCategory}...</p>
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {articleWizardStep === 4 && (
                      <motion.div 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 10 }}
                        className="space-y-4"
                        key="article-step-4"
                      >
                        <div className="border-b border-white/5 pb-2">
                          <h3 className="text-xs font-black text-white flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-brand-orange"></span>
                            گام ۴: وضعیت انتشار نهایی و پیش‌نمایش غنی
                          </h3>
                        </div>

                        <div className="space-y-1.5">
                          <span className="text-[10px] text-zinc-450 font-bold">گزینش وضعیت انتشار مقاله</span>
                          <select
                            value={newBlogStatus}
                            onChange={(e) => setNewBlogStatus(e.target.value as any)}
                            className="w-full px-3.5 py-3 rounded-xl bg-zinc-900 border border-white/10 text-xs text-amber-400 font-bold"
                          >
                            <option value="published">منـتشر شده فـوری (نمایش عمومی در وب‌سایت)</option>
                            <option value="draft">پیش‌نویس غیررسمی (فقط قابل ویرایش در پنل مدیریت)</option>
                            <option value="scheduled">زمان‌بندی شده برای آینده (انتشار خودکار در روزهای آتی)</option>
                          </select>
                        </div>

                        <div className="space-y-2 pt-2">
                          <span className="text-[10px] text-zinc-450 font-bold block">پیش‌نمایش زنده کارت مقاله خلاصه شده :</span>
                          
                          <div className="p-4 bg-zinc-950 rounded-xl border border-white/10 hover:border-white/20 transition-all space-y-3 max-w-md mx-auto">
                            <div className="flex justify-between items-start">
                              <div>
                                <span className="px-2 py-0.5 rounded bg-brand-orange/15 text-brand-orange text-[8px] font-bold">{newBlogCategory}</span>
                                <h4 className="text-white font-black text-xs mt-1.5 leading-relaxed">{newBlogTitle || 'عنوان مقاله وارد نشده است'}</h4>
                                <p className="text-[9px] text-zinc-550 font-mono mt-1">تـقویم انتشار: امروز (فـوری)</p>
                              </div>
                              
                              <span className="text-[8px] font-bold px-2 py-0.5 rounded bg-zinc-900 border border-white/5 text-zinc-400">
                                {newBlogStatus === 'published' ? 'عمومی' : newBlogStatus === 'draft' ? 'پیش‌نویس' : 'زمان‌بندی'}
                              </span>
                            </div>

                            {/* Snippet display text */}
                            <div className="text-[9px] text-zinc-400 line-clamp-3 bg-[#0d0e10] p-2 rounded-lg border border-white/5 leading-relaxed">
                              {newBlogContent ? (
                                <div dangerouslySetInnerHTML={{ __html: newBlogContent.substring(0, 140) + '...' }} />
                              ) : (
                                <span className="text-zinc-650">هیچ متنی نوشته نشده است...</span>
                              )}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Stepper Wizard Control buttons */}
                  <div className="flex justify-between items-center pt-5 border-t border-white/5">
                    <div className="flex gap-2">
                      {articleWizardStep > 1 ? (
                        <button
                          type="button"
                          onClick={() => setArticleWizardStep(prev => prev - 1)}
                          className="px-4 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 text-xs font-black rounded-xl transition-all flex items-center gap-1 cursor-pointer border border-white/5"
                        >
                          <ChevronRight className="w-4 h-4" />
                          <span>مرحله قبلی</span>
                        </button>
                      ) : (
                        <div className="w-12"></div>
                      )}

                      {/* Quick Save Draft Button */}
                      <button
                        type="button"
                        onClick={handleSaveBlogDraft}
                        className="px-4 py-2.5 bg-amber-500/10 hover:bg-amber-550/20 text-amber-400 text-xs font-black rounded-xl transition-all border border-amber-400/20 flex items-center gap-1.5 cursor-pointer"
                        title="ذخیره موقت مقاله به صورت پیشنویس"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>ذخیره چرک‌نویس</span>
                      </button>
                    </div>

                    <div className="flex gap-2">
                      {editingBlogId && (
                        <button
                          type="button"
                          onClick={() => {
                            setEditingBlogId(null);
                            setNewBlogTitle('');
                            setNewBlogContent('');
                            setNewBlogSeo('');
                            setNewBlogKeywords('');
                            setNewBlogStatus('published');
                            setArticleWizardStep(1);
                          }}
                          className="px-4 py-2.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs font-black rounded-xl transition-all border border-red-500/20 cursor-pointer"
                        >
                          لغو ویرایش
                        </button>
                      )}

                      {articleWizardStep < 4 ? (
                        <button
                          type="button"
                          onClick={() => setArticleWizardStep(prev => prev + 1)}
                          className="px-5 py-2.5 bg-white hover:bg-zinc-200 text-zinc-950 text-xs font-black rounded-xl transition-all flex items-center gap-1 cursor-pointer"
                        >
                          <span>مرحله بعدی</span>
                          <ChevronLeft className="w-4 h-4 text-zinc-950" />
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            if (!newBlogTitle.trim()) {
                              alert('عنوان مقاله الزامی است. لطفاً به گام ۱ بازگردید.');
                              setArticleWizardStep(1);
                              return;
                            }
                            if (!newBlogContent.trim()) {
                              alert('متن اصلی مقاله الزامی است. لطفاً به گام ۲ بازگردید.');
                              setArticleWizardStep(2);
                              return;
                            }
                            
                            handleCreateBlog();
                          }}
                          className="px-6 py-2.5 bg-gradient-to-r from-brand-orange to-brand-red text-white text-xs font-black rounded-xl hover:scale-[1.01] transition-all cursor-pointer shadow-lg shadow-brand-orange/10"
                        >
                          {editingBlogId ? 'ثبت بروزرسانی مقاله علمی' : 'انتشار نهایی مقاله ساو'}
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Published articles list (size 4/12) */}
                <div className="xl:col-span-4 rounded-2xl p-6 bg-zinc-950 border border-white/5 space-y-4 shadow-xl">
                  <div className="border-b border-white/5 pb-2">
                    <h3 className="text-sm font-bold text-white flex items-center gap-1.5 animate-pulse">
                      <FileText className="w-4 h-4 text-brand-orange" />
                      آخرین مقالات ساو ({blogPosts.length})
                    </h3>
                    <p className="text-[10px] text-zinc-550">تعداد مقالات روی وبلاگ اصلی آکادمی</p>
                  </div>

                  <div className="space-y-3 max-h-[580px] overflow-y-auto pr-1">
                    {blogPosts.map(post => {
                      const isEditingThisBlog = editingBlogId === post.id;
                      return (
                        <div 
                          key={post.id} 
                          className={`p-3.5 bg-zinc-900/40 rounded-xl hover:bg-zinc-900 transition-all border ${
                            isEditingThisBlog ? 'border-brand-orange bg-brand-orange/[2%]' : 'border-white/5'
                          }`}
                        >
                          <div className="space-y-2">
                            <div className="flex justify-between items-start">
                              <span className="px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 text-[8px] font-black">{post.category}</span>
                              <span className={`text-[8px] px-1.5 py-0.5 rounded font-bold ${
                                post.status === 'published' ? 'bg-emerald-500/10 text-emerald-400' : post.status === 'draft' ? 'bg-amber-500/10 text-amber-400' : 'bg-blue-500/10 text-blue-400'
                              }`}>
                                {post.status === 'published' ? 'عمومی' : post.status === 'draft' ? 'چرک‌نویس' : 'زمان‌بندی'}
                              </span>
                            </div>
                            
                            <h4 className="text-white font-bold text-xs leading-relaxed line-clamp-2">{post.title}</h4>
                            <p className="text-[9px] text-zinc-500 font-mono">انتشار: {post.scheduledDate}</p>

                            <div className="flex justify-end gap-1.5 pt-2 border-t border-white/5">
                              {/* Step Wizard Edit Loader button */}
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingBlogId(post.id);
                                  setNewBlogTitle(post.title);
                                  setNewBlogCategory(post.category);
                                  setNewBlogContent(post.content);
                                  setNewBlogSeo(post.seoTitle || '');
                                  setNewBlogKeywords(post.seoKeywords || '');
                                  setNewBlogStatus(post.status || 'published');
                                  setArticleWizardStep(1);
                                  
                                  // Smooth scroll to top of article area
                                  window.scrollTo({ top: 300, behavior: 'smooth' });
                                }}
                                className="px-2.5 py-1 bg-white/5 hover:bg-brand-orange hover:text-white rounded-lg text-zinc-300 text-[9px] transition-all flex items-center gap-1 border border-white/5 font-black"
                              >
                                <Edit2 className="w-3 h-3" />
                                <span>ویرایش مرحله‌ای</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  if (confirm(`آیا از حذف مقاله علمی "${post.title}" مطمئن هستید؟`)) {
                                    deleteBlogPost(post.id);
                                  }
                                }}
                                className="p-1 text-zinc-500 hover:text-red-500 bg-white/5 rounded-lg border border-white/5"
                                title="حذف"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                    {blogPosts.length === 0 && (
                      <p className="text-center py-12 text-zinc-650 text-xs">هیچ مقاله علمی روی وبگاه وجود ندارد.</p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {cmsTab === 'inspirations' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-right animate-fadeIn">
                
                {/* Form column: add or edit video */}
                <div className="lg:col-span-4 rounded-2xl bg-zinc-950 p-6 border border-white/5 space-y-4">
                  <div className="border-b border-white/5 pb-2">
                    <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                      <Video className="w-4 h-4 text-brand-orange" />
                      {editingInspId ? 'ویرایش ویدیوی الهام‌بخش مرجع' : 'افزودن ویدیوی الهام‌بخش مرجع'}
                    </h3>
                    <p className="text-[10px] text-zinc-500 font-sans">مشخصات ترانسکریپت و دکوپاژ را برای بهره‌برداری ادمین وارد کنید.</p>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-1">
                      <label className="text-[10px] text-zinc-400 font-bold block">عنوان ویدیو مرجع</label>
                      <input
                        type="text"
                        value={newInspTitle}
                        onChange={(e) => setNewInspTitle(e.target.value)}
                        placeholder="مثال: ریلز وایرال چالش فنجان قهوه زیگزاگ..."
                        className="w-full px-3 py-2 rounded-xl bg-white/[1.5%] border border-white/5 text-white text-[11px] outline-none text-right"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] text-zinc-400 font-bold block">آدرس مستقیم ویدیو (MP4 - جریان عمودی ۹:۱۶)</label>
                      <input
                        type="text"
                        value={newInspVideoUrl}
                        onChange={(e) => setNewInspVideoUrl(e.target.value)}
                        placeholder="https://example.com/video.mp4"
                        className="w-full px-3 py-2 rounded-xl bg-white/[1.5%] border border-white/5 text-white text-[11px] outline-none text-right font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setNewInspVideoUrl('https://assets.mixkit.co/videos/preview/mixkit-hand-holding-smartphone-with-a-vertical-scrolling-screen-42354-large.mp4')}
                        className="text-[9px] text-brand-orange hover:underline font-mono"
                      >
                        ⚡ استفاده از نمونه آزمایشی لوکس ساو
                      </button>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] text-zinc-400 font-bold block">انتخاب دسته‌بندی فعلی</label>
                      <select
                        value={newInspCategory}
                        onChange={(e) => setNewInspCategory(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-white/5 text-white text-[11px] outline-none text-right"
                      >
                        {inspirationCategories.map((c: string) => (
                          <option key={c} value={c}>{c}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] text-zinc-400 font-bold block">و یا افزودن دسته جدید</label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={newInspCustomCategory}
                          onChange={(e) => setNewInspCustomCategory(e.target.value)}
                          placeholder="مثال: ورزشی، آرایشی..."
                          className="w-full px-3 py-1.5 rounded-lg bg-white/[1.5%] border border-white/5 text-white text-[11px] outline-none text-right"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            if (newInspCustomCategory.trim()) {
                              addInspirationCategory(newInspCustomCategory.trim());
                              setNewInspCategory(newInspCustomCategory.trim());
                              setNewInspCustomCategory('');
                            }
                          }}
                          className="px-3 py-1 bg-white text-zinc-950 font-bold text-[10px] rounded-lg"
                        >
                          افزودن
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] text-zinc-400 font-bold block">متن ترانسکریپت کامل (دیالوگ کلامی یا نریشن‌ها)</label>
                      <textarea
                        rows={4}
                        value={newInspTranscript}
                        onChange={(e) => setNewInspTranscript(e.target.value)}
                        placeholder="متن نریشن صوتی یا دیالوگ‌هایی که در فیلم گفته می‌شود..."
                        className="w-full px-3 py-2 rounded-xl bg-white/[1.5%] border border-white/5 text-slate-300 text-[11px] outline-none text-right resize-none leading-relaxed"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] text-zinc-400 font-bold block">ساختار دکوپاژ و ریتم صحنه‌ها (مبنای استخوان‌بندی سناریو)</label>
                      <textarea
                        rows={5}
                        value={newInspScenario}
                        onChange={(e) => setNewInspScenario(e.target.value)}
                        placeholder="مثال: شات ۱: کلوزآپ محصول - شات ۲: ورود بازیگر - شات ۳: نشان دادن کارایی..."
                        className="w-full px-3 py-2 rounded-xl bg-white/[1.5%] border border-white/5 text-slate-300 text-[11px] outline-none text-right resize-none leading-relaxed font-mono"
                      />
                    </div>

                    <div className="flex items-center gap-2 bg-white/[1.5%] p-2 rounded-xl border border-white/5">
                      <input
                        type="checkbox"
                        id="insp_pinned"
                        checked={newInspIsPinned}
                        onChange={(e) => setNewInspIsPinned(e.target.checked)}
                        className="accent-brand-orange"
                      />
                      <label htmlFor="insp_pinned" className="text-[10px] text-zinc-300 font-bold select-none cursor-pointer">
                        سفارش پین شدن این ویدیو توسط ادمین در بالای فید
                      </label>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          if (!newInspTitle || !newInspVideoUrl || !newInspTranscript) {
                            alert('وارد کردن عنوان، آدرس ویدیو و کلماتی نریشن الزامی است.');
                            return;
                          }

                          const payload = {
                            title: newInspTitle,
                            videoUrl: newInspVideoUrl,
                            transcript: newInspTranscript,
                            scenario: newInspScenario,
                            category: newInspCategory,
                            isPinned: newInspIsPinned,
                            likes: 0,
                            likedByUsers: []
                          };

                          if (editingInspId) {
                            updateInspirationVideo(editingInspId, payload);
                            setEditingInspId(null);
                          } else {
                            addInspirationVideo(payload);
                          }

                          // Clear values
                          setNewInspTitle('');
                          setNewInspVideoUrl('');
                          setNewInspTranscript('');
                          setNewInspScenario('');
                          setNewInspIsPinned(false);
                        }}
                        className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-brand-orange to-brand-red text-white text-xs font-black hover:opacity-95 transition-all"
                      >
                        {editingInspId ? 'ثبت و ذخیره تغییرات' : 'انتشار در بخش الهام‌گیری'}
                      </button>

                      {editingInspId && (
                        <button
                          type="button"
                          onClick={() => {
                            setEditingInspId(null);
                            setNewInspTitle('');
                            setNewInspVideoUrl('');
                            setNewInspTranscript('');
                            setNewInspScenario('');
                            setNewInspIsPinned(false);
                          }}
                          className="px-4 py-2 bg-white/5 border border-white/10 text-white text-xs font-bold rounded-xl"
                        >
                          انصراف
                        </button>
                      )}
                    </div>

                  </div>
                </div>

                {/* List column: manage existing inspirations */}
                <div className="lg:col-span-8 rounded-2xl bg-zinc-950 p-6 border border-white/5 space-y-4">
                  <div className="border-b border-white/5 pb-2">
                    <h3 className="text-sm font-bold text-white">ویدیوهای فعلی منتشر شده در الهام‌گیری ({inspirationVideos?.length || 0})</h3>
                    <p className="text-[10px] text-zinc-500 font-sans">لیست کامل ویدیوها به همراه تعداد لایک‌های واقعی کاربران پرتال</p>
                  </div>

                  <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
                    {inspirationVideos && inspirationVideos.map((video) => (
                      <div
                        key={video.id}
                        className="p-4 rounded-xl bg-white/[1.5%] border border-white/5 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-right"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] bg-brand-orange/10 border border-brand-orange/20 text-brand-orange px-2 py-0.5 rounded">
                              {video.category}
                            </span>
                            {video.isPinned && (
                              <span className="text-[9px] bg-amber-500 text-black px-1.5 py-0.5 rounded font-black">
                                پین شده
                              </span>
                            )}
                            <span className="text-[9px] text-zinc-500 font-mono">شناسه: {video.id}</span>
                          </div>
                          <h4 className="text-xs font-black text-white">{video.title}</h4>
                          <p className="text-[10px] text-zinc-500 leading-relaxed truncate max-w-[400px]">
                            {video.transcript}
                          </p>
                        </div>

                        {/* Action buttons */}
                        <div className="flex items-center gap-2.5 shrink-0 self-end md:self-auto">
                          <span className="text-[10px] text-zinc-400 font-mono flex items-center gap-1 bg-white/5 px-2 py-1 rounded">
                            ❤️ {video.likes} لایک
                          </span>

                          <button
                            type="button"
                            onClick={() => {
                              updateInspirationVideo(video.id, { isPinned: !video.isPinned });
                            }}
                            className={`p-1.5 text-xs rounded-lg border ${video.isPinned ? 'text-amber-400 bg-amber-400/10 border-amber-400/20' : 'text-zinc-500 bg-white/5 border-white/5 hover:text-white'}`}
                            title="تغییر وضعیت پین"
                          >
                            📌 {video.isPinned ? 'پین‌شده' : 'پین کن'}
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setEditingInspId(video.id);
                              setNewInspTitle(video.title);
                              setNewInspVideoUrl(video.videoUrl);
                              setNewInspTranscript(video.transcript);
                              setNewInspScenario(video.scenario || '');
                              setNewInspCategory(video.category);
                              setNewInspIsPinned(video.isPinned || false);
                            }}
                            className="p-1 px-2.5 bg-white/5 text-[10px] text-zinc-400 hover:text-brand-orange hover:bg-white/10 transition-all rounded-lg"
                            title="ویرایش"
                          >
                            ویرایش ✏️
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              if (confirm(`آیا از حذف ویدئو "${video.title}" مطمئن هستید؟`)) {
                                deleteInspirationVideo(video.id);
                              }
                            }}
                            className="p-1 px-2.5 bg-white/5 text-[10px] text-zinc-400 hover:text-brand-red hover:bg-brand-red/10 transition-all rounded-lg"
                            title="حذف"
                          >
                            حذف 🗑️
                          </button>
                        </div>
                      </div>
                    ))}
                    {(!inspirationVideos || inspirationVideos.length === 0) && (
                      <p className="text-center py-12 text-zinc-500 text-xs">کتابخانه فید الهام‌گیری کاملاً خالی است.</p>
                    )}
                  </div>
                </div>

              </div>
            )}
          </div>
        )}
        </div>
        </div>
      </div>
    )}
  </div>
  );
};
