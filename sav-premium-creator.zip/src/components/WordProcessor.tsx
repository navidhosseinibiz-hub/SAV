import React, { useState, useRef } from 'react';
import { Bold, Italic, Heading1, Heading2, Image, List, AlertTriangle, Eye, Code, Trash2, ArrowLeftRight, Check, Sparkles } from 'lucide-react';

interface WordProcessorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  label?: string;
}

const PRESET_IMAGES = [
  {
    id: 'cinema',
    title: 'تجهیزات سینمایی',
    url: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80',
    description: 'تنظیمات دوربین و تجهیزات فیلمبرداری لوکس'
  },
  {
    id: 'neon',
    title: 'استودیو نئون ساو',
    url: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80',
    description: 'نورپردازی پرتره استودیویی خلاقانه'
  },
  {
    id: 'scripts',
    title: 'میز سناریونویسی',
    url: 'https://images.unsplash.com/photo-1496171367470-9ed9a91ea931?auto=format&fit=crop&w=800&q=80',
    description: 'لپ‌تاپ و صفحات نوشتن متون طلایی'
  },
  {
    id: 'editing',
    title: 'تدوین ریتمیک',
    url: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=800&q=80',
    description: 'محیط تایم‌لاین ادیت حرفه‌ای پریمیر'
  },
  {
    id: 'podcast',
    title: 'میکروفون پادکست',
    url: 'https://images.unsplash.com/photo-1478737270239-2f02b77fc618?auto=format&fit=crop&w=800&q=80',
    description: 'تجهیزات ضبط صدا لوکس کلاسیک'
  }
];

export const WordProcessor: React.FC<WordProcessorProps> = ({
  value,
  onChange,
  placeholder = 'شروع به نوشتن متن با فرمت واژه‌پرداز کنید...',
  label = 'متن غنی (واژه‌پرداز)'
}) => {
  const [activeTab, setActiveTab] = useState<'edit' | 'preview' | 'split'>('split');
  const [showImageDialog, setShowImageDialog] = useState(false);
  const [customImageUrl, setCustomImageUrl] = useState('');
  const [customImageAlt, setCustomImageAlt] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Helper helper to insert tags or HTML templates at cursor position
  const insertText = (beforeText: string, afterText: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const selected = text.substring(start, end);
    
    const replacement = beforeText + (selected || '') + afterText;
    const newValue = text.substring(0, start) + replacement + text.substring(end);
    
    onChange(newValue);
    
    // Reset cursor position
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + beforeText.length, start + beforeText.length + selected.length);
    }, 50);
  };

  const handleInsertImage = (url: string, altText: string) => {
    const cleanAlt = altText || 'تصویر محتوا آکادمی ساو';
    const imageHtml = `\n<div class="my-6 space-y-2 group relative overflow-hidden rounded-2xl border border-white/5 bg-zinc-950 p-1.5"><img src="${url}" alt="${cleanAlt}" class="rounded-xl w-full max-h-72 object-cover" referrerPolicy="no-referrer" /><p class="text-[10px] text-zinc-500 font-bold text-center mt-1.5">${cleanAlt}</p></div>\n`;
    insertText(imageHtml);
    setShowImageDialog(false);
    setCustomImageUrl('');
    setCustomImageAlt('');
  };

  const insertWarningBox = () => {
    const boxHtml = `\n<div class="my-5 p-4 rounded-xl bg-amber-500/10 border-r-4 border-amber-500 text-amber-300 text-xs font-semibold leading-relaxed space-y-1"><div class="flex items-center gap-1.5 font-bold"><span class="text-amber-400">⚠️ قلاب طلایی:</span></div><p>محتوای این بخش مستلزم رعایت استانداردهای واچ‌تایم ۳ ثانیه‌ای اول ریلز می‌باشد.</p></div>\n`;
    insertText(boxHtml);
  };

  const insertDivider = () => {
    const dividerHtml = `\n<hr class="my-6 border-t border-white/10" />\n`;
    insertText(dividerHtml);
  };

  return (
    <div className="w-full bg-[#0d0d0e] border border-white/10 rounded-2xl overflow-hidden shadow-2xl flex flex-col min-h-[380px]">
      {/* Header toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-zinc-950/70 border-b border-white/5">
        <span className="text-xs font-bold text-zinc-300 px-1 font-sans">{label}</span>
        
        {/* Formatting actions */}
        {(activeTab === 'edit' || activeTab === 'split') && (
          <div className="flex items-center gap-1.5 bg-white/[1.5%] p-1 rounded-xl border border-white/5">
            <button
              type="button"
              onClick={() => insertText('<strong>', '</strong>')}
              className="p-1.5 rounded-lg hover:bg-white/5 text-zinc-400 hover:text-white transition-all"
              title="متن برجسته (Bold)"
            >
              <Bold className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => insertText('<em>', '</em>')}
              className="p-1.5 rounded-lg hover:bg-white/5 text-zinc-400 hover:text-white transition-all"
              title="متن مورب (Italic)"
            >
              <Italic className="w-4 h-4" />
            </button>
            <hr className="w-[1px] h-4 border-l border-white/10 mx-1" />
            
            <button
              type="button"
              onClick={() => insertText('<h3 class="text-lg font-black text-white mt-5 mb-2 border-r-2 border-brand-orange pr-2">', '</h3>')}
              className="p-1.5 rounded-lg hover:bg-white/5 text-zinc-400 hover:text-white transition-all"
              title="عنوان بزرگ (H1)"
            >
              <Heading1 className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => insertText('<h4 class="text-sm font-bold text-brand-orange mt-4 mb-1.5">', '</h4>')}
              className="p-1.5 rounded-lg hover:bg-white/5 text-zinc-400 hover:text-white transition-all"
              title="عنوان متوسط (H2)"
            >
              <Heading2 className="w-4 h-4" />
            </button>
            <hr className="w-[1px] h-4 border-l border-white/10 mx-1" />

            <button
              type="button"
              onClick={() => insertText('<ul class="list-disc list-inside space-y-1.5 text-zinc-300 my-3 font-semibold">\n  <li>', '</li>\n  <li>آیتم‌های بعدی...</li>\n</ul>')}
              className="p-1.5 rounded-lg hover:bg-white/5 text-zinc-400 hover:text-white transition-all"
              title="لیست نشانه‌دار"
            >
              <List className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => setShowImageDialog(true)}
              className="p-1.5 rounded-lg bg-brand-orange/10 hover:bg-brand-orange/20 text-brand-orange transition-all flex items-center gap-1 text-[10px] font-bold"
              title="قرار دادن عکس در متن"
            >
              <Image className="w-3.5 h-3.5" />
              <span>+ عکس</span>
            </button>

            <button
              type="button"
              onClick={insertWarningBox}
              className="p-1.5 rounded-lg hover:bg-white/5 text-amber-400 transition-all"
              title="باکس طلایی هشدار الگوریتمی"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              onClick={insertDivider}
              className="p-1.5 rounded-lg hover:bg-white/5 text-zinc-500 hover:text-zinc-300 transition-all font-mono text-[10px] font-bold"
              title="خط جداکننده ظریف"
            >
              HR
            </button>
          </div>
        )}

        {/* View Toggle */}
        <div className="flex items-center gap-1 bg-white/[1.5%] p-1 rounded-xl border border-white/5">
          <button
            type="button"
            onClick={() => setActiveTab('edit')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-black transition-all flex items-center gap-1.5 ${
              activeTab === 'edit'
                ? 'bg-[#1a1c1e] text-white border border-white/5'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Code className="w-3 h-3" />
            <span>ویرایشگر کد</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('split')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-black transition-all flex items-center gap-1.5 ${
              activeTab === 'split'
                ? 'bg-brand-orange text-white'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Sparkles className="w-3 h-3 text-white" />
            <span>صفحه دو تایی (Split)</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('preview')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-black transition-all flex items-center gap-1.5 ${
              activeTab === 'preview'
                ? 'bg-[#1a1c1e] text-amber-400 border border-white/5'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Eye className="w-3 h-3" />
            <span>پیش‌نمایش زنده</span>
          </button>
        </div>
      </div>

      {/* Editor Main Canvas */}
      <div className="flex-1 relative min-h-[360px] flex flex-col">
        {activeTab === 'edit' && (
          <textarea
            ref={textareaRef}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            className="w-full flex-1 p-4 bg-transparent text-xs text-zinc-200 font-mono focus:outline-none resize-none leading-relaxed min-h-[340px]"
            dir={value.match(/^[a-zA-Z]/) ? 'ltr' : 'rtl'}
          />
        )}

        {activeTab === 'preview' && (
          <div 
            className="flex-1 p-6 overflow-y-auto bg-zinc-950/40 text-right text-xs leading-relaxed text-zinc-300 space-y-4 max-h-[480px] article-preview"
            dir="rtl"
          >
            {value.trim() ? (
              <div 
                className="space-y-4 font-semibold prose prose-invert max-w-none text-zinc-250 leading-loose"
                dangerouslySetInnerHTML={{ __html: value }} 
              />
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center py-20 text-zinc-600 space-y-2">
                <Sparkles className="w-8 h-8 text-zinc-700 animate-pulse" />
                <p className="font-bold text-xs">هیچ مکتوبی نوشته نشده است.</p>
                <p className="text-[10px]">در زبانه ویرایشگر متنی، مطالبتان و عکس‌ها را چیدمان کنید.</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'split' && (
          <div className="grid grid-cols-1 md:grid-cols-2 divide-x divide-white/5 md:divide-x-reverse h-full flex-1 min-h-[420px]">
            {/* Editor panel inputs */}
            <textarea
              ref={textareaRef}
              value={value}
              onChange={(e) => onChange(e.target.value)}
              placeholder={placeholder}
              className="w-full p-4 bg-[#080809] text-xs text-zinc-250 font-mono focus:outline-none resize-none leading-relaxed placeholder-zinc-550 h-full border-b md:border-b-0 border-white/5 outline-none"
              dir={value.match(/^[a-zA-Z]/) ? 'ltr' : 'rtl'}
            />
            {/* Realtime preview render */}
            <div 
              className="p-5 overflow-y-auto bg-[#0a0a0b]/50 text-right text-xs leading-relaxed text-zinc-300 space-y-4 max-h-[480px] article-preview h-full"
              dir="rtl"
            >
              {value.trim() ? (
                <div 
                  className="space-y-3 font-semibold prose prose-invert leading-loose"
                  dangerouslySetInnerHTML={{ __html: value }} 
                />
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center py-24 text-zinc-650 space-y-1.5">
                  <Eye className="w-7 h-7 text-zinc-700" />
                  <p className="text-[10px] font-black">پیش‌نمایش زمان‌واقعی (Real-time)</p>
                  <p className="text-[9px] text-zinc-500">وقتی در سمت چپ بنویسید، جلوه خروجی فورا اینجا نقش می‌بندد.</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Popup Dialog to insert Unsplash Image assets */}
      {showImageDialog && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-zinc-950 border border-white/10 rounded-3xl p-6 max-w-lg w-full space-y-5 text-right shadow-2xl relative">
            <button 
              onClick={() => setShowImageDialog(false)}
              className="absolute top-4 left-4 text-zinc-500 hover:text-white text-xs font-bold"
            >
              انصراف ×
            </button>

            <div className="space-y-1">
              <h3 className="text-sm font-bold text-white">درج تصویر و المان‌های ویدیویی در متن</h3>
              <p className="text-[10px] text-zinc-400">یکی از عکس‌های سینمایی و فیلم‌سازی زیبا زیر را انتخاب کنید یا یک آدرس عکس دلخواه بدهید:</p>
            </div>

            {/* Presets Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-[220px] overflow-y-auto">
              {PRESET_IMAGES.map((img) => (
                <button
                  key={img.id}
                  onClick={() => handleInsertImage(img.url, img.title)}
                  className="group relative rounded-xl overflow-hidden border border-white/5 hover:border-brand-orange/40 text-right transition-all"
                >
                  <img src={img.url} alt={img.title} className="w-full h-16 object-cover grayscale group-hover:grayscale-0 transition-all" referrerPolicy="no-referrer" />
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent p-1.5">
                    <p className="text-[9px] font-bold text-white truncate">{img.title}</p>
                  </div>
                </button>
              ))}
            </div>

            <div className="border-t border-white/5 pt-3 space-y-3">
              <span className="text-[10px] text-zinc-450 block">یا درج لینک تصویر سفارشی شما:</span>
              
              <div className="space-y-2">
                <input
                  type="text"
                  placeholder="https://example.com/photo.jpg"
                  value={customImageUrl}
                  onChange={(e) => setCustomImageUrl(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white font-mono text-left"
                  dir="ltr"
                />
                <input
                  type="text"
                  placeholder="توضیح کوتاه به فارسی (مثلا: کادربندی درست نور)"
                  value={customImageAlt}
                  onChange={(e) => setCustomImageAlt(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white text-right"
                  dir="rtl"
                />
              </div>

              <button
                onClick={() => {
                  if (customImageUrl.trim()) {
                    handleInsertImage(customImageUrl, customImageAlt);
                  }
                }}
                disabled={!customImageUrl.trim()}
                className="w-full py-2.5 bg-brand-orange hover:bg-brand-orange/90 text-white rounded-xl text-xs font-bold transition-all disabled:opacity-40"
              >
                ثبت و درج تصویر سفارشی
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
