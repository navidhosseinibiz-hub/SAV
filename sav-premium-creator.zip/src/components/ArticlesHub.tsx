/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAppState } from '../state';
import { BlogPost } from '../types';
import { 
  Search, 
  BookOpen, 
  Clock, 
  Eye, 
  ArrowRight, 
  Sparkles, 
  Compass, 
  Heart, 
  Share2, 
  Maximize2, 
  Minimize2, 
  Cpu, 
  CheckCircle2, 
  Bookmark, 
  Hash,
  Award
} from 'lucide-react';

const CATEGORY_IMAGES: Record<string, string> = {
  'تحلیل الگوریتم': 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80',
  'بازاریابی مدرن': 'https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=1200&q=80',
  'تکنیک‌های تدوین': 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=1200&q=80',
  'سناریونویسی ریلز': 'https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&w=1200&q=80',
  'DEFAULT': 'https://images.unsplash.com/photo-1542204172-e7052809f852?auto=format&fit=crop&w=1200&q=80'
};

export const ArticlesHub: React.FC = () => {
  const { blogPosts } = useAppState();
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('همه');
  const [minimalMode, setMinimalMode] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [likedPosts, setLikedPosts] = useState<Record<string, boolean>>({});
  const [bookmarkedPosts, setBookmarkedPosts] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'newest' | 'most_viewed'>('newest');

  // Auto scroll listener for the reading progress bar
  useEffect(() => {
    const handleScroll = () => {
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (totalHeight > 0) {
        const progress = (window.pageYOffset / totalHeight) * 100;
        setScrollProgress(progress);
      }
    };

    if (selectedPost) {
      window.addEventListener('scroll', handleScroll);
      // Reset scroll state
      setScrollProgress(0);
    }

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [selectedPost]);

  // Clean minimal mode scroll resets when switching posts
  const handleSelectPost = (post: BlogPost | null) => {
    setSelectedPost(post);
    if (!post) {
      setMinimalMode(false);
    }
    // Scroll window to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Setup list of category tabs
  const categories = ['همه', 'تحلیل الگوریتم', 'بازاریابی مدرن', 'تکنیک‌های تدوین', 'سناریونویسی ریلز'];
  const fullArticlesList: BlogPost[] = [
    {
      id: 'b1',
      title: 'چرا الگوریتم ۲۰۲۶ اینستاگرام عاشق ویدیوهای تیره و لوکس است؟',
      category: 'تحلیل الگوریتم',
      content: `### ۱. جادوی روانشناسی تاریکی (Dark Mood Aesthetic)
در سال ۲۰۲۶، الگوریتم اکسپلور تمرکز ویژه‌ای روی **میانگین زمان تماشا (Average Watch Time)** گذاشته است. ویدیوهای خوش‌ساخت با تم تاریک، کنتراست‌های زنده، رنگ‌های عمیق نارنجی و متون مینیمال شیک، احساس ارزشمندی بالایی تولید می‌کنند و مخاطب را جذب می‌کنند. این ویدیوها نور آبی کمتری تولید کرده و چشم را در مقایسه با تصاویر بسیار روشن کمتر خسته می‌کنند.

### ۲. مفهوم قلاب‌های متکثر (Multi-Hooks)
در ویدیوهای تیره، شما می‌توانید متن‌های طلایی با فونت فوق ریز خلاقانه ساو اضافه کنید. مخاطب مجبور می‌شود سرش را کج کرده و ویدیو را ۲ یا ۳ بار مرور کند تا خطوط را بخواند. همین موضوع باعث افزایش لول تکرار (Loop rate) می‌شود.

### ۳. مکانیزم انتقال به دایرکت با اتومیشن
کلمات کلیدی کوتاه مانند "ساو" یا "رشد" نباید صراحتا فرآیند فروش را تحریک کنند. بلکه این کلمات باید نقش یک دستگیره طلایی را بازی کنند تا ربات اتومیشن فایل PDF عمیقی را به دایرکت کاربر شلیک کند.`,
      scheduledDate: '۱۴۰۵/۰۳/۲۰',
      seoTitle: 'راز طلایی الگوریتم جدید اینستاگرام ۲۰۲۶ و رنگ‌های سینماتیک تیره',
      seoKeywords: 'ریلز لوکس, الگوریتم اینستاگرام ۲۰۲۶, سناریونویسی خلاق, روانشناسی رنگ تیره, ساو دستیار',
      videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-cinematic-foggy-pine-forest-42289-large.mp4',
      status: 'published'
    },
    {
      id: 'b2',
      title: 'نقشه راه طلایی تبدیل ریلزهای تصادفی به قیف فروش ارگانیک',
      category: 'بازاریابی مدرن',
      content: `### مقدمه: تراژدی ویوهای بی‌ثمر
بسیاری از سازندگان ریلز فکر می‌کنند ویو بالا مساوی است با ثروت. این یک خطای استراتژیک بزرگ است. اگر شما ۵۰۰ هزار بازدید بگیرید اما یک ریال درآمد ایجاد نکنید، سیستم شما مرده است.

### ساختار ۳ لایه‌ای قیف فروش ساو
۱. **لایه قلاب عاطفی (Emotional Hook)**: ۳ ثانیه اول. باید حس اضطراب کارآفرین یا عشق به زیبایی را بیدار کند.
۲. **لایه گشایش اطلاعاتی (Information Gap)**: جایی که شما راه‌حل ثروت‌ساز را بازگو می‌کنید اما مرحله نهایی را پنهان می‌کنید.
۳. **لایه محرک کادنا (Call-to-Action Automation)**: ارسال خودکار مینی‌کلاس یا جزوه سناریونویسی در دایرکت به کمک ربات ساو در تلگرام/اینستاگرام.`,
      scheduledDate: '۱۴۰۵/۰۳/۲۲',
      seoTitle: 'نقشه راه تبدیل ریلز به قیف فروش اتوماتیک',
      seoKeywords: 'قیف فروش اینستاگرام, جذب مشتری اتوماتیک, ساو بات, ریلز وایرال',
      status: 'published'
    },
    {
      id: 'b3',
      title: 'نورپردازی سینمایی پرو کالاها: کادربندی به روش برندهای لوکس',
      category: 'تکنیک‌های تدوین',
      content: `### ۱. حرکت دوربین مایور (Major Camera Movement)
وقتی می‌خواهید یک محصول گران‌قیمت یا لوکس را در ریلز نشان دهید، هرگز دوربین را ثابت نگه ندارید. استفاده از تکنیک "نمای چرخشی مایل" به دور سوژه همراه با لنز پرایم ۵۰ میلی‌متری و دیافراگم ۱.۴، فضایی وهم‌آلود و گران‌بها به کالا می‌دهد.

### ۲. زوایای پنهان‌گر (Mystery Framing)
نمایش محصول را از زوایایی شروع کنید که در نگاه اول ماهیت آن کشف نشود. مثلا رفلکس نور روی بدنه فلزی عینک، یا لبه چرمی کیف. کشف تدریجی کالا ذهن بیننده را تحریک می‌کند که تا انتهای ویدیو بماند.

### ۳. تطبیق فریم با فرکانس صدا
کافیست ترنزیشن‌های سریع را روی ضرب‌آهنگ ساب‌ووفر موزیک ست کنید. این هماهنگی ریتمیک (Syncing)، تماشای ویدیو را به شدت اعتیادآور می‌کند.`,
      scheduledDate: '۱۴۰۵/۰۳/۲۴',
      seoTitle: 'آموزش نورپردازی و تدوین ریلزهای لوکس محصولات با گوشی',
      seoKeywords: 'تدوین ریلز, حرکت دوربین سینمایی, عکاسی محصولات, ترفندهای لایتروم',
      status: 'published'
    },
    {
      id: 'b4',
      title: 'رازهای مگافست سناریونویسی: نوشتن دیالوگ‌های هیپنوتیزم‌کننده اکسپلورر',
      category: 'سناریونویسی ریلز',
      content: `### ۱. کلمات قدرت در زبان فارسی
کلماتی که ذهن فارسی‌زبان را قفل می‌کنند عبارتند از: "سقوط آزاد"، "فرمول پنهان"، "افشاگری"، "بایکوت سیستمی"، "کودتای ذهنی". استفاده از این کلمات در ۱.۵ ثانیه اول، زنگ هشدار مغز خزنده مخاطب را به صدا در می‌آورد.

### ۲. اصول سناریونویسی مدرن
دیالوگ شما در ویدیو نباید مثل گویندگی اخبار رادیو باشد. باید صمیمانه، قاطع، آرام و با تن صدای باس عمیق بیان شود. سکوت‌های عمدی بین حملات کلامی تاثیرگذاری را دو برابر می‌کند.

### ۳. فرمت دبل قلاب (Dual-Hook Framework)
در این فرمت، ابتدا روی تصویر یک سوال فلسفی شیک می‌نویسید، سپس خودتان کلام را با مخالفت با یک فرض رایج بازار شروع می‌کنید. این کنتراست ذهنی شدید، لایک و سیو ویدیو را تا ۳۵۰٪ ارتقا می‌دهد!`,
      scheduledDate: '۱۴۰۵/۰۳/۲۵',
      seoTitle: 'تکنیکهای سناریو نویسی ریلز وایرال اینستاگرام فارسی',
      seoKeywords: 'سناریو ریلز, دیالوگ نویسی, قلاب تند ۳ ثانیه‌ای, نقشه رشد ساو',
      status: 'published'
    }
  ];

  // Merge state blogPosts and custom ones to have plenty of rich material
  const mergedPosts = [...fullArticlesList, ...(blogPosts || [])].filter((post, index, self) => 
    self.findIndex(p => p.id === post.id) === index
  );

  // Filter based on search query and category
  const filteredPosts = mergedPosts.filter(post => {
    const matchesCategory = selectedCategory === 'همه' || post.category === selectedCategory;
    const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          post.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          post.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (post.seoKeywords && post.seoKeywords.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const handleLikePost = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLikedPosts(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleBookmarkPost = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setBookmarkedPosts(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCopyLink = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const link = `${window.location.origin}/articles/${id}`;
    navigator.clipboard.writeText(link);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const getPostCover = (category: string) => {
    return CATEGORY_IMAGES[category] || CATEGORY_IMAGES['DEFAULT'];
  };

  // Extract a nice mockup Table of Contents from content
  const extractToC = (content: string) => {
    const lines = content.split('\n');
    const headers = lines
      .filter(line => line.startsWith('###') || line.startsWith('##'))
      .map(line => {
        const title = line.replace(/^#+\s+/, '');
        return title;
      });
    return headers.length > 0 ? headers : ['مقدمه نویسنده', 'تحلیل و تشریح ریلز', 'تکنسین بازاریابی', 'خلاصه و اقدام نهایی'];
  };

  // Visual SEO Score card calculator
  const calculateSeoScore = (post: BlogPost) => {
    let score = 55;
    if (post.title.length > 25) score += 15;
    if (post.content.length > 500) score += 15;
    if (post.seoKeywords && post.seoKeywords.split(',').length > 3) score += 15;
    return Math.min(score, 100);
  };

  return (
    <div className="space-y-10 text-right pb-24" dir="rtl">
      
      {/* ARTICLE TOP READING PROGRESS BAR (only shown when selectedPost) */}
      <AnimatePresence>
        {selectedPost && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed top-0 left-0 right-0 h-1 bg-zinc-900 z-50 origin-right"
          >
            <div 
              className="h-full bg-gradient-to-l from-brand-orange to-brand-red transition-all duration-75"
              style={{ width: `${scrollProgress}%` }}
            />
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence mode="wait">
        {!selectedPost ? (
          /* ================= ARTICLES LIST/INDEX VIEW ================= */
          <motion.div
            key="list-view"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-12"
          >
            {/* Cinematic Editorial Hero Section */}
            <div className="relative rounded-[32px] p-8 md:p-12 bg-gradient-to-b from-zinc-950 via-zinc-950/90 to-transparent border border-white/5 overflow-hidden shadow-2xl">
              <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-rose-500/10 rounded-full blur-[120px] pointer-events-none" />
              <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-brand-orange/5 rounded-full blur-[100px] pointer-events-none" />
              
              <div className="max-w-4xl space-y-4 relative z-10">
                <span className="px-3.5 py-1.5 rounded-full bg-white/5 border border-white/10 text-rose-400 text-[10px] font-black tracking-wide uppercase flex items-center gap-2 w-max">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-550 animate-pulse" />
                  نشریه اختصاصی مقالات ساو (SAV EDITORIAL)
                </span>
                
                <h1 className="text-3xl md:text-5xl font-black text-white tracking-tight leading-tight">
                  سکوی پرتاب اندیشه برای <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-orange to-brand-red">برندهای لوکس</span> اینستاگرام
                </h1>
                
                <p className="text-zinc-400 text-xs md:text-sm font-medium leading-relaxed max-w-2xl">
                  تلفیقی هماهنگ از روانشناسی رسانه، تکنیک‌های تاریک تدوین، کاتالوگ سناریوهای خلاصه و الگوهای مهندسی معکوس الگوریتم ریلز جهت خلق ارزش پایدار.
                </p>

                {/* Search Bar Block with luxury outline */}
                <div className="pt-4 max-w-lg">
                  <div className="relative">
                    <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-zinc-500" />
                    <input
                      type="text"
                      className="w-full pl-4 pr-11 py-3.5 bg-zinc-900/80 border border-white/5 hover:border-white/10 focus:border-brand-orange focus:ring-1 focus:ring-brand-orange text-xs text-white rounded-2xl placeholder-zinc-500 font-bold transition-all shadow-inner"
                      placeholder="دنبال چه مهارتی در رشد ریلز هستید؟ (الگوریتم، سناریو، نورپردازی...)"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* CATEGORY SELECTOR + POSTS COUNT */}
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-white/5 pb-4">
              {/* Category buttons list */}
              <div className="flex flex-wrap items-center gap-2">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-4.5 py-2.5 rounded-xl text-xs font-black transition-all ${
                      selectedCategory === cat
                        ? 'bg-gradient-to-r from-brand-orange to-brand-red text-white shadow-lg shadow-brand-orange/15 border-none'
                        : 'bg-white/[1.5%] border border-white/5 text-zinc-400 hover:text-white hover:bg-white/[3%]'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              <span className="text-[10px] text-zinc-500 font-bold font-mono">
                نمایش {filteredPosts.length} مقاله تخصصی سئو شده
              </span>
            </div>

            {/* MAIN STAGGERED EDITORIAL GRID */}
            {filteredPosts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredPosts.map((post, idx) => {
                  const isFeatured = idx === 0 && searchQuery === '' && selectedCategory === 'همه';
                  const isLiked = !!likedPosts[post.id];
                  const isBookmarked = !!bookmarkedPosts[post.id];

                  return (
                    <motion.article
                      key={post.id}
                      onClick={() => handleSelectPost(post)}
                      className={`group cursor-pointer rounded-3xl bg-zinc-950 border border-white/5 hover:border-brand-orange/30 overflow-hidden shadow-xl flex flex-col justify-between transition-all duration-300 hover:-translate-y-1.5 ${
                        isFeatured ? 'md:col-span-2 lg:col-span-3 flex-col lg:flex-row lg:min-h-[420px]' : ''
                      }`}
                    >
                      {/* Thumbnail / cover block */}
                      <div className={`relative overflow-hidden shrink-0 ${
                        isFeatured 
                          ? 'w-full lg:w-1/2 h-64 lg:h-auto min-h-[260px]' 
                          : 'w-full h-56'
                      }`}>
                        <img 
                          src={getPostCover(post.category)} 
                          alt={post.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent" />
                        
                        {/* Badges positioning */}
                        <div className="absolute top-4 right-4 flex gap-1.5">
                          <span className="px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-rose-455 text-[9px] font-black">
                            {post.category}
                          </span>
                        </div>
                      </div>

                      {/* Info and text block */}
                      <div className="p-6 md:p-8 flex-1 flex flex-col justify-between space-y-6">
                        <div className="space-y-3">
                          <div className="flex items-center gap-2.5 text-[10px] text-zinc-500 font-bold">
                            <Clock className="w-3.5 h-3.5 text-zinc-550" />
                            <span>زمان مطالعه: ۵ دقیقه</span>
                            <span>•</span>
                            <span>{post.scheduledDate}</span>
                          </div>

                          <h3 className={`font-black text-white group-hover:text-brand-orange transition-colors tracking-tight leading-snug ${
                            isFeatured ? 'text-xl md:text-3xl font-extrabold' : 'text-base font-bold'
                          }`}>
                            {post.title}
                          </h3>

                          <p className="text-zinc-400 text-xs leading-relaxed font-normal line-clamp-3">
                            {post.content.replace(/[#*`]/g, '')}
                          </p>
                        </div>

                        {/* Interactive metadata footer inside the card */}
                        <div className="flex items-center justify-between pt-4 border-t border-white/5 text-[10px]">
                          <span className="text-[10px] text-brand-orange font-black flex items-center gap-1.5 group-hover:underline">
                            مطالعه کامل مقاله
                            <ArrowRight className="w-3.5 h-3.5 text-brand-orange" />
                          </span>

                          <div className="flex items-center gap-3" onClick={(e) => e.stopPropagation()}>
                            <button
                              onClick={(e) => handleLikePost(post.id, e)}
                              className={`p-1.5 rounded-lg border transition-all ${
                                isLiked 
                                  ? 'bg-rose-500/10 border-rose-550 text-rose-500' 
                                  : 'border-white/5 hover:border-white/10 text-zinc-500 hover:text-zinc-300'
                              }`}
                            >
                              <Heart className="w-3.5 h-3.5" fill={isLiked ? "currentColor" : "none"} />
                            </button>
                            <button
                              onClick={(e) => handleBookmarkPost(post.id, e)}
                              className={`p-1.5 rounded-lg border transition-all ${
                                isBookmarked 
                                  ? 'bg-amber-400/10 border-amber-400 text-amber-400' 
                                  : 'border-white/5 hover:border-white/10 text-zinc-500 hover:text-zinc-300'
                              }`}
                            >
                              <Bookmark className="w-3.5 h-3.5" fill={isBookmarked ? "currentColor" : "none"} />
                            </button>
                          </div>
                        </div>
                      </div>
                    </motion.article>
                  );
                })}
              </div>
            ) : (
              <div className="p-12 text-center rounded-2xl bg-zinc-950 border border-white/5 text-zinc-500 text-xs">
                هیچ مقاله‌ای با عنوان یا کلمات کلیدی "{searchQuery}" یافت نشد. طبقه‌بندی متنی دیگری را انتخاب فرمایید.
              </div>
            )}
          </motion.div>
        ) : (
          /* ================= IMMERSIVE ARTICLE DETAIL VIEW (Notion/Medium style) ================= */
          <motion.div
            key="detail-view"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className={`space-y-8 ${minimalMode ? 'max-w-3xl mx-auto' : 'w-full'}`}
          >
            {/* Top Back Menu & Focus controller */}
            {!minimalMode && (
              <div className="flex justify-between items-center pb-4 border-b border-white/5">
                <button
                  onClick={() => handleSelectPost(null)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-zinc-950 border border-white/5 hover:border-white/10 text-xs font-bold text-zinc-300 transition-all hover:text-white"
                >
                  <ArrowRight className="w-4 h-4 text-zinc-550" />
                  <span>بازگشت به مطبوعات ساو</span>
                </button>

                <div className="flex items-center gap-3">
                  {/* Minimal Reading toggle */}
                  <button
                    onClick={() => setMinimalMode(true)}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-white transition-all font-bold"
                  >
                    <Maximize2 className="w-3.5 h-3.5 text-zinc-400" />
                    <span>حالت مطالعه مینیمال (آرامش)</span>
                  </button>
                </div>
              </div>
            )}

            {/* MINIMAL MODE OVERLAY FLUSH EXIT BUTTON */}
            {minimalMode && (
              <div className="fixed top-6 left-6 z-40">
                <button
                  onClick={() => setMinimalMode(false)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#111112] border border-white/10 text-xs text-zinc-300 hover:text-white hover:bg-zinc-950 shadow-2xl transition-all"
                >
                  <Minimize2 className="w-3.5 h-3.5 text-brand-orange" />
                  <span>انصراف از تمرکز</span>
                </button>
              </div>
            )}

            {/* COVER PHOTOGRAPHY BLOCK */}
            {!minimalMode && (
              <div className="relative rounded-[32px] h-[340px] md:h-[420px] overflow-hidden border border-white/5">
                <img 
                  src={getPostCover(selectedPost.category)} 
                  alt={selectedPost.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/60 to-transparent" />
                
                {/* Visual Title Header inside overlay bottom */}
                <div className="absolute bottom-0 inset-x-0 p-8 md:p-12 space-y-4">
                  <span className="px-3.5 py-1.5 bg-brand-orange text-white text-[10px] font-black rounded-lg uppercase inline-block">
                    {selectedPost.category}
                  </span>
                  <h2 className="text-2xl md:text-4xl font-black text-white leading-tight max-w-4xl tracking-tight">
                    {selectedPost.title}
                  </h2>
                  
                  <div className="flex flex-wrap items-center gap-4 text-xs text-zinc-400 font-bold">
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-zinc-550" />
                      ۵ دقیقه مطالعه سودمند
                    </span>
                    <span>•</span>
                    <span>انتشار: {selectedPost.scheduledDate}</span>
                    <span>•</span>
                    <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/10 px-2 py-0.5 rounded text-[9px]">
                      پیشنهاد سردبیر
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* MAIN CONTENT SPLIT GRID */}
            <div className={`grid grid-cols-1 ${minimalMode ? 'max-w-2xl mx-auto' : 'lg:grid-cols-12'} gap-8 items-start`}>
              
              {/* Left Column (Article body) */}
              <div className={`${minimalMode ? 'w-full' : 'lg:col-span-8'} bg-zinc-950/20 p-6 md:p-10 rounded-[32px] border border-white/5 space-y-6 shadow-sm`}>
                
                {/* Minimal headers info block if in minimalMode */}
                {minimalMode && (
                  <div className="pb-6 border-b border-white/5 text-right space-y-4">
                    <span className="text-[10px] bg-rose-500/15 text-rose-400 border border-rose-500/10 px-3 py-1 rounded-full font-black">
                      {selectedPost.category}
                    </span>
                    <h1 className="text-3xl font-extrabold text-white leading-snug tracking-tight">
                      {selectedPost.title}
                    </h1>
                    <p className="text-xs text-zinc-400 font-mono">آخرین ویرایش: {selectedPost.scheduledDate} • زمان تخمینی مطالعه ۵ دقیقه</p>
                  </div>
                )}

                {/* DYNAMIC ATTACHED VIDEO PLAYER */}
                {selectedPost.videoUrl && (
                  <div className="rounded-2xl border border-white/10 overflow-hidden bg-zinc-900 shadow-xl group aspect-video relative my-4">
                    <video 
                      src={selectedPost.videoUrl} 
                      className="w-full h-full object-cover"
                      controls
                      playsInline
                    />
                  </div>
                )}

                {/* THE ARTICLE BODY TEXT WITH POLISHED TYPOGRAPHY */}
                <div className="prose prose-invert max-w-none text-zinc-250 leading-loose text-sm font-medium space-y-6">
                  {selectedPost.content.split('\n\n').map((paragraph, pIdx) => {
                    const trimmed = paragraph.trim();
                    if (!trimmed) return null;

                    // Header render
                    if (trimmed.startsWith('###')) {
                      return (
                        <h4 key={pIdx} className="text-lg font-black text-rose-400 pt-6 flex items-center gap-2">
                          <Hash className="w-4 h-4 text-brand-orange" />
                          {trimmed.replace(/^###\s+/, '')}
                        </h4>
                      );
                    }
                    if (trimmed.startsWith('##')) {
                      return (
                        <h3 key={pIdx} className="text-xl font-extrabold text-white pt-8 pb-1 border-b border-white/5">
                          {trimmed.replace(/^##\s+/, '')}
                        </h3>
                      );
                    }

                    // Bullets item render
                    if (trimmed.startsWith('۱.') || trimmed.startsWith('۲.') || trimmed.startsWith('۳.')) {
                      return (
                        <div key={pIdx} className="p-4 rounded-2xl bg-white/[1.5%] border-r-2 border-brand-orange space-y-1 my-3 pl-3">
                          <p className="text-sm font-semibold text-zinc-200">{trimmed}</p>
                        </div>
                      );
                    }

                    // Bold text emphasis formatting parser
                    const formattedText = trimmed.split('**').map((chunk, cIdx) => {
                      if (cIdx % 2 === 1) {
                        return <strong key={cIdx} className="text-brand-orange font-black text-xs md:text-sm">{chunk}</strong>;
                      }
                      return chunk;
                    });

                    return (
                      <p key={pIdx} className="leading-relaxed text-zinc-300 font-sans">
                        {formattedText}
                      </p>
                    );
                  })}
                </div>

                {/* Author Credentials signature Card */}
                <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row items-center gap-4 justify-between mt-12">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-brand-orange to-brand-red flex items-center justify-center text-white font-black">
                      س
                    </div>
                    <div>
                      <p className="text-xs font-black text-white">تیم مطالعات الگوریتم ساو</p>
                      <p className="text-[10px] text-zinc-500">منبع معتبر تحلیل‌های رشد کوانتومی پیج‌های تجاری</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => handleLikePost(selectedPost.id, e)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border ${
                        likedPosts[selectedPost.id]
                          ? 'bg-rose-500/10 border-rose-500 text-rose-400'
                          : 'border-white/5 hover:border-white/10 text-zinc-400 hover:text-white'
                      }`}
                    >
                      <Heart className="w-3.5 h-3.5" fill={likedPosts[selectedPost.id] ? "currentColor" : "none"} />
                      <span>{likedPosts[selectedPost.id] ? 'پسندیدم' : 'می‌پسندم'}</span>
                    </button>

                    <button
                      onClick={(e) => handleCopyLink(selectedPost.id, e)}
                      className="px-4 py-2 rounded-xl text-xs font-bold bg-white/5 border border-white/10 hover:border-white/15 text-zinc-300 transition-all flex items-center gap-1.5"
                    >
                      <Share2 className="w-3.5 h-3.5 text-zinc-400" />
                      <span>{copiedId === selectedPost.id ? 'پیوند کپی شد!' : 'هم‌رسانی پیوند'}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Right Column (Index sidebar metadata widgets & SEO tools) - hidden in minimal mode */}
              {!minimalMode && (
                <div className="lg:col-span-4 space-y-6">
                  
                  {/* WIDGET 1: Interactive Table Of Contents */}
                  <div className="p-6 rounded-2xl bg-zinc-950 border border-white/5 space-y-3 shadow-xl sticky top-4">
                    <div className="space-y-1 pb-3 border-b border-white/5">
                      <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                        <BookOpen className="w-4 h-4 text-brand-orange" />
                        فهرست مطالب مقاله (TOC)
                      </h4>
                      <p className="text-[9px] text-zinc-550">اسکرول سریع به سرفصل‌های علمی</p>
                    </div>

                    <div className="flex flex-col gap-2">
                      {extractToC(selectedPost.content).map((headerText, i) => (
                        <div 
                          key={i}
                          className="text-[10px] text-zinc-400 font-bold hover:text-brand-orange transition-all cursor-pointer flex items-center gap-1.5"
                        >
                          <span className="w-1.5 h-1.5 rounded-full bg-brand-orange/40" />
                          <span>{headerText}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* WIDGET 2: SEO Friendly Score simulation tool */}
                  <div className="p-6 rounded-2xl bg-zinc-950 border border-white/5 space-y-4 shadow-xl">
                    <div className="space-y-1 pb-3 border-b border-white/5">
                      <h4 className="text-xs font-black text-white flex items-center gap-1.5">
                        <Cpu className="w-4 h-4 text-rose-400" />
                        ماتریس آنالیز سئو محتوا (SEO Index)
                      </h4>
                      <p className="text-[9px] text-zinc-550">وضعیت سئو فرندلی مقاله در گوگل</p>
                    </div>

                    <div className="space-y-4 text-[10px]">
                      {/* Score gauge */}
                      <div className="flex justify-between items-center bg-white/[1.5%] p-3 rounded-xl border border-white/5">
                        <span className="text-zinc-400 font-semibold">امتیاز کل چگالی گوگل:</span>
                        <div className="flex items-center gap-1">
                          <span className="font-mono text-xs text-white font-extrabold">{calculateSeoScore(selectedPost)} / ۱۰۰</span>
                          <span className="text-emerald-400 text-[9px] font-black">✓ عالی</span>
                        </div>
                      </div>

                      {/* Detailed list Checklist */}
                      <div className="space-y-2.5">
                        <div className="flex items-center gap-2 text-zinc-300">
                          <CheckCircle2 className="w-4.5 h-4.5 text-teal-400 shrink-0" />
                          <span>تعبیه کلیدواژه‌های طلایی در متاتگ‌ها</span>
                        </div>
                        <div className="flex items-center gap-2 text-zinc-300">
                          <CheckCircle2 className="w-4.5 h-4.5 text-teal-400 shrink-0" />
                          <span>طول عنوان سولیوشن بهینه است (H1-H4)</span>
                        </div>
                        <div className="flex items-center gap-2 text-zinc-300">
                          <CheckCircle2 className="w-4.5 h-4.5 text-teal-400 shrink-0" />
                          <span>خوانایی بالای فونت لوکس در دسکتاپ و موبایل</span>
                        </div>
                      </div>

                      {/* SEO Tags list */}
                      <div className="space-y-1.5 pt-2 border-t border-white/5">
                        <span className="text-zinc-500 font-bold block mb-1">کدها و کلیدواژه‌های نمایه شده:</span>
                        <div className="flex flex-wrap gap-1">
                          {selectedPost.seoKeywords ? (
                            selectedPost.seoKeywords.split(',').map((kw, idx) => (
                              <span key={idx} className="bg-zinc-900 border border-white/10 px-2 py-0.5 rounded text-[9px] text-zinc-400 block font-mono">
                                #{kw.trim()}
                              </span>
                            ))
                          ) : (
                            <span className="text-zinc-650">ثبت نشده است.</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* WIDGET 3: Premium Call to Action (Upgrade gold) */}
                  <div className="p-6 rounded-2xl bg-gradient-to-tr from-brand-orange/10 to-transparent border border-brand-orange/20 space-y-3.5 text-center shadow-md">
                    <span className="text-[9px] text-amber-400 bg-amber-500/10 px-2.5 py-0.5 rounded-full inline-block font-black tracking-widest uppercase">
                      ★ عضویت ویژه طلایی ★
                    </span>
                    <h5 className="text-xs font-black text-white">برای دسترسی به بانک سناریوهای آماده؟</h5>
                    <p className="text-[10px] text-zinc-400 leading-relaxed leading-normal">
                      دسترسی به تمام مسترکلاس‌های ویدیویی آکادمی به همراه کاتالوگ ۲۰۰ سناریوی آماده‌ی مهندسی معکوس ریلز.
                    </p>
                    <div className="w-full h-1" />
                  </div>

                </div>
              )}

            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
