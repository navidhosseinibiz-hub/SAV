/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAppState } from '../state';
import { 
  Video, 
  ExternalLink, 
  Star, 
  Heart, 
  CheckCircle2, 
  Play, 
  TrendingUp,
  Award,
  Plus,
  Compass,
  ArrowRight,
  Sparkles,
  Info,
  Layers,
  Settings as SettingsIcon,
  Trash2
} from 'lucide-react';

export const ProductionTeam: React.FC = () => {
  const { teamMembers, addTeamMember, updateTeamMember, currentUser } = useAppState();

  const [activeVideoUrl, setActiveVideoUrl] = useState<string | null>(null);
  const [selectedCreatorId, setSelectedCreatorId] = useState<string | null>(null);
  const [likes, setLikes] = useState<Record<string, number>>({});
  
  // Registration and Dashboard states
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [appliedSuccess, setAppliedSuccess] = useState(false);
  const [newCreatorName, setNewCreatorName] = useState(currentUser.name || '');
  const [newCreatorRole, setNewCreatorRole] = useState('تدوین‌گر ریلز خلاق');
  const [newCreatorBio, setNewCreatorBio] = useState('');
  const [newCreatorAvatar, setNewCreatorAvatar] = useState('https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80');
  const [newCreatorTags, setNewCreatorTags] = useState('ریلز, واچ‌تایم, تدوین سینماتیک');

  // Creator personal workspace states (simulated login/editor)
  const [activeWorkspaceId, setActiveWorkspaceId] = useState<string | null>(() => {
    // If current logged-in user matches any team creator
    const matched = teamMembers.find(m => m.name.toLowerCase() === currentUser.name.toLowerCase());
    return matched ? matched.id : null;
  });

  // New portfolio item states
  const [newItemTitle, setNewItemTitle] = useState('');
  const [newItemCover, setNewItemCover] = useState('https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=420&auto=format&fit=crop&q=80');
  const [newItemVideo, setNewItemVideo] = useState('https://assets.mixkit.co/videos/preview/mixkit-cinematic-foggy-pine-forest-42289-large.mp4');

  const handleLike = (title: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setLikes(prev => ({
      ...prev,
      [title]: (prev[title] || 0) + 1
    }));
  };

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCreatorName || !newCreatorBio) return;

    // Register with isApproved: false
    const newMember = {
      id: 'cr_' + Math.random().toString(36).substr(2, 9),
      name: newCreatorName,
      role: newCreatorRole,
      avatar: newCreatorAvatar,
      bio: newCreatorBio,
      rating: 5.0,
      availability: 'available' as const,
      portfolio: [
        {
          title: 'اولین خلاقیت ریلز ساو',
          coverImage: 'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=420&auto=format&fit=crop&q=80',
          videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-cinematic-foggy-pine-forest-42289-large.mp4',
          views: 'صفر'
        }
      ],
      isApproved: false, // will require admin approval
      tags: newCreatorTags.split(',').map(t => t.trim()).filter(Boolean) as any
    };

    addTeamMember(newMember);
    setAppliedSuccess(true);
    setTimeout(() => {
      setShowApplyModal(false);
      setAppliedSuccess(false);
    }, 4000);
  };

  const handleAddPortfolio = () => {
    if (!newItemTitle) return;
    const targetId = activeWorkspaceId;
    if (!targetId) return;

    const me = teamMembers.find(m => m.id === targetId);
    if (!me) return;

    const updatedPortfolio = [
      ...me.portfolio,
      {
        title: newItemTitle,
        coverImage: newItemCover,
        videoUrl: newItemVideo,
        views: '۱۴۰'
      }
    ];

    updateTeamMember(targetId, { portfolio: updatedPortfolio });
    setNewItemTitle('');
  };

  // Filter approved members for list view
  const approvedMembers = teamMembers.filter(m => m.isApproved !== false);

  // Selected creator for detailed profile page
  const selectedCreator = teamMembers.find(m => m.id === selectedCreatorId);

  // Personal workspace matched creator
  const workspaceCreator = teamMembers.find(m => m.id === activeWorkspaceId);

  return (
    <div className="space-y-8" id="production_team_root">
      
      {/* Header Promo Card with workspace activation options */}
      <div className="relative overflow-hidden rounded-3xl p-8 bg-gradient-to-r from-zinc-950 via-matte-dark to-zinc-900 border border-white/5 shadow-2xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-brand-orange/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="max-w-xl space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-orange/15 border border-brand-orange/20 text-brand-orange text-[10px] font-bold">
              <Award className="w-3.5 h-3.5 border-none" />
              <span>پایگاه سازندگان خلاق و تدوین‌گران ساو</span>
            </div>
            <h2 className="text-xl font-black text-white leading-tight">پالت کادربندی‌های لوکس و ادیتورهای <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-orange to-brand-red">برون‌سپاری ساو</span></h2>
            <p className="text-zinc-400 text-xs leading-relaxed">
              اینجا کانون برترین ادیتورها، تصویربرداران و کارگردانانی است که خدمات لوکس ریلز ساو را پشتیبانی می‌کنند. می‌توانید نمونه کارها را تماشا کرده یا به عنوان تولیدکننده ثبت‌نام کنید.
            </p>
          </div>

          <div className="flex flex-wrap gap-3 shrink-0">
            {activeWorkspaceId ? (
              <button
                onClick={() => setSelectedCreatorId(activeWorkspaceId)}
                className="px-4 py-2.5 rounded-xl bg-brand-orange/10 border border-brand-orange/30 text-brand-orange text-xs font-black flex items-center gap-1.5 hover:bg-brand-orange/20 transition-all cursor-pointer"
              >
                <SettingsIcon className="w-4 h-4" />
                <span>میزکار کریتور من</span>
              </button>
            ) : (
              <button
                onClick={() => setShowApplyModal(true)}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-brand-orange to-brand-red text-white text-xs font-black flex items-center gap-1.5 shadow-lg shadow-brand-orange/10 hover:opacity-90 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>عضویت به عنوان کریتور (ادیتور)</span>
              </button>
            )}

            {/* Simulated selector to test different creator views instantly */}
            <select
              value={activeWorkspaceId || ''}
              onChange={(e) => setActiveWorkspaceId(e.target.value || null)}
              className="px-3 py-2 rounded-xl bg-zinc-900 border border-white/5 text-[10px] font-bold text-zinc-400 focus:outline-none cursor-pointer"
            >
              <option value="">(شبیه‌سازی کریتور)</option>
              {teamMembers.map(m => (
                <option key={m.id} value={m.id}>{m.name} ({m.isApproved === false ? 'در انتظار' : 'تائید شده'})</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Creator Profile Detail View Sheet */}
      {selectedCreator && (
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-3xl p-8 bg-zinc-950 border border-brand-orange/20 space-y-6 glow-red"
        >
          <div className="flex items-center justify-between border-b border-white/5 pb-4">
            <div className="flex items-center gap-4">
              <img 
                src={selectedCreator.avatar} 
                alt={selectedCreator.name} 
                className="w-14 h-14 rounded-full object-cover border-2 border-brand-orange" 
                referrerPolicy="no-referrer"
              />
              <div>
                <h3 className="text-lg font-black text-white flex items-center gap-1.5">
                  {selectedCreator.name}
                  <CheckCircle2 className="w-4 h-4 text-brand-orange" />
                </h3>
                <p className="text-xs text-zinc-400 mt-0.5">{selectedCreator.role}</p>
              </div>
            </div>
            <button 
              onClick={() => setSelectedCreatorId(null)}
              className="text-xs font-extrabold text-zinc-550 hover:text-white px-3 py-1.5 bg-zinc-900 border border-white/5 rounded-xl transition-colors cursor-pointer"
            >
              بستن جزئیات ×
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-4">
              {/* Bio & Skills */}
              <div className="space-y-2">
                <span className="text-[11px] font-black text-brand-orange uppercase">بیوگرافی و سبک کاری:</span>
                <p className="text-xs text-zinc-300 leading-relaxed bg-white/[1%] p-4 rounded-xl border border-white/5">
                  {selectedCreator.bio}
                </p>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5 pt-2">
                {(selectedCreator.tags || ['فیلم‌برداری ریلز', 'پرمیوم دکوپاژ', 'اصلاح رنگ لوکس']).map((tag, idx) => (
                  <span key={idx} className="px-2 py-0.5 bg-zinc-900 border border-white/5 text-[9px] font-bold text-zinc-400 rounded">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Quick Consultation contact info & ratings */}
            <div className="p-5 rounded-2xl bg-[#0b0b0c] border border-white/5 space-y-4 flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-zinc-500">امتیاز کومیونیتی:</span>
                  <span className="text-amber-400 font-extrabold flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 fill-amber-400 inline" />
                    {selectedCreator.rating} از ۵
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-zinc-500">وضعیت پذیرش پروژه:</span>
                  <span className={`font-bold ${selectedCreator.availability === 'available' ? 'text-green-400' : 'text-amber-400'}`}>
                    {selectedCreator.availability === 'available' ? '✓ فعال و آماده شوکیس' : '● مشغول'}
                  </span>
                </div>
              </div>

              <a
                href={`https://t.me/SavReelsBot?start=hire_${selectedCreator.id}`}
                target="_blank"
                rel="noreferrer"
                className="w-full text-center py-2.5 rounded-xl bg-brand-orange text-white text-xs font-black hover:opacity-90 transition-all block cursor-pointer"
              >
                ارسال درخواست همکاری مستقیم
              </a>
            </div>
          </div>

          {/* Expanded Portfolio Works inside Page */}
          <div className="space-y-3.5 pt-4">
            <h4 className="text-xs font-black text-zinc-400">تمام نمونه کارها ({selectedCreator.portfolio.length}):</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              {selectedCreator.portfolio.map((item, idx) => (
                <div 
                  key={idx}
                  onClick={() => setActiveVideoUrl(item.videoUrl)}
                  className="group rounded-xl overflow-hidden bg-zinc-950 border border-white/5 relative aspect-video cursor-pointer"
                >
                  <img 
                    src={item.coverImage} 
                    alt={item.title} 
                    className="w-full h-full object-cover transition group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-between p-2.5" />
                  <div className="absolute top-2 right-2 px-1.5 py-0.5 rounded bg-black/60 text-[8px] font-mono font-black text-amber-300">
                    {item.views} بازدید
                  </div>
                  <div className="absolute bottom-2 left-2 right-2 flex justify-between items-center z-10">
                    <p className="text-[9px] font-bold text-zinc-200 truncate max-w-[110px]">{item.title}</p>
                    <div className="p-1 rounded-full bg-brand-orange text-white">
                      <Play className="w-2.5 h-2.5 fill-white border-none" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {/* Creator Personal Workspace Management Panel */}
      {workspaceCreator && (
        <div className="rounded-3xl p-6 bg-zinc-950 border border-brand-orange/30 space-y-6">
          <div className="flex items-center gap-2 border-b border-white/5 pb-3">
            <SettingsIcon className="w-4 h-4 text-brand-orange" />
            <h3 className="text-sm font-black text-white">میزکار مدیریت پروفایل: {workspaceCreator.name}</h3>
            {workspaceCreator.isApproved === false && (
              <span className="px-2 py-0.5 rounded-md bg-amber-400/15 border border-amber-400/25 text-amber-400 text-[10px] font-bold">
                در انتظار تائید ادمین ساو
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            
            {/* Quick state change (cols 4) */}
            <div className="md:col-span-4 bg-[#0c0c0d] p-5 rounded-2xl border border-white/5 space-y-4">
              <h4 className="text-xs font-bold text-zinc-300">تنظیمات در دسترس بودن</h4>
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-zinc-500">وضعیت آفیش و پذیرش:</span>
                <select
                  value={workspaceCreator.availability}
                  onChange={(e) => updateTeamMember(workspaceCreator.id, { availability: e.target.value as any })}
                  className="px-3 py-1.5 rounded-lg bg-zinc-900 border border-white/10 text-xs text-white focus:outline-none cursor-pointer font-bold"
                >
                  <option value="available">✓ آماده پذیرش کار</option>
                  <option value="busy">● پر مشغله</option>
                </select>
              </div>

              <div className="space-y-1 pt-2">
                <span className="text-[11.5px] text-zinc-300 block">ویرایش عکس پروفایل من</span>
                <input 
                  type="text" 
                  value={workspaceCreator.avatar}
                  onChange={(e) => updateTeamMember(workspaceCreator.id, { avatar: e.target.value })}
                  className="w-full px-3 py-2 bg-zinc-900 border border-white/10 text-[11px] rounded-lg text-white font-mono"
                />
              </div>
            </div>

            {/* Add Portfolio video (cols 8) */}
            <div className="md:col-span-8 bg-[#0c0c0d] p-5 rounded-2xl border border-white/5 space-y-4">
              <h4 className="text-xs font-bold text-zinc-300">آپلود نمونه کار جدید ریلز</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] text-zinc-500">عنوان ریلز / ویدیو</label>
                  <input 
                    type="text" 
                    value={newItemTitle} 
                    onChange={(e) => setNewItemTitle(e.target.value)}
                    placeholder="نمونه: قلاب ریلز واچ‌تایم"
                    className="w-full px-3 py-2 bg-zinc-900 border border-white/10 text-xs text-white rounded-lg"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-zinc-500">کاور نمونه کار (عکس)</label>
                  <input 
                    type="text" 
                    value={newItemCover} 
                    onChange={(e) => setNewItemCover(e.target.value)}
                    className="w-full px-3 py-2 bg-zinc-900 border border-white/10 text-xs text-white rounded-lg font-mono text-left"
                    dir="ltr"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-zinc-500">لینک ویدیو تصویری</label>
                  <input 
                    type="text" 
                    value={newItemVideo} 
                    onChange={(e) => setNewItemVideo(e.target.value)}
                    className="w-full px-3 py-2 bg-zinc-900 border border-white/10 text-xs text-white rounded-lg font-mono text-left"
                    dir="ltr"
                  />
                </div>
              </div>
              <button
                onClick={handleAddPortfolio}
                disabled={!newItemTitle}
                className="px-4 py-2 rounded-xl bg-brand-orange text-white text-xs font-black disabled:opacity-40 transition-opacity flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>افزودن نمونه کار به شیت من</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Grid View of Approved Creators */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {approvedMembers.map((member) => (
          <div 
            key={member.id} 
            onClick={() => setSelectedCreatorId(member.id)}
            className="rounded-2xl p-6 bg-matte-black border border-white/5 space-y-6 shadow-xl relative hover:border-brand-orange/20 transition-all cursor-pointer group"
          >
            {/* Profile Header */}
            <div className="flex items-start justify-between">
              <div className="flex gap-4">
                <div className="relative">
                  <img 
                    src={member.avatar} 
                    alt={member.name} 
                    className="w-16 h-16 rounded-full object-cover border-2 border-brand-orange/40 group-hover:border-brand-orange transition-all"
                    referrerPolicy="no-referrer"
                  />
                  {/* Status Indicator */}
                  <span className={`absolute bottom-0 left-0 w-3.5 h-3.5 rounded-full border-2 border-matte-black ${
                    member.availability === 'available' ? 'bg-green-500' : 'bg-amber-400'
                  }`} />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-base font-black text-white group-hover:text-brand-orange transition-colors">{member.name}</h3>
                    <CheckCircle2 className="w-4 h-4 text-brand-orange fill-brand-orange/10 border-none" />
                  </div>
                  <p className="text-xs text-zinc-400 font-bold mt-0.5">{member.role}</p>
                  
                  {/* Rating Stars */}
                  <div className="flex items-center gap-1 mt-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className={`w-3 h-3 border-none ${i < Math.floor(member.rating) ? 'text-amber-400 fill-amber-400' : 'text-zinc-700'}`} />
                    ))}
                    <span className="font-mono text-[10px] text-zinc-500 mr-2">({member.rating})</span>
                  </div>
                </div>
              </div>

              {/* Badges */}
              <div className="space-y-1">
                <span className={`px-2.5 py-1 rounded-full text-[9px] font-bold block text-center ${
                  member.availability === 'available' 
                    ? 'bg-green-500/10 text-green-400 border border-green-500/20' 
                    : 'bg-amber-400/10 text-amber-400 border border-amber-400/20'
                }`}>
                  {member.availability === 'available' ? '✓ نوبت باز' : '● پر مشغله'}
                </span>
                <span className="text-[9px] font-bold block text-center text-zinc-550 mt-1">پیشکار آکادمی ساو</span>
              </div>
            </div>

            {/* Bio */}
            <p className="text-xs text-zinc-400 leading-relaxed font-semibold bg-white/[0.5%] p-3.5 rounded-xl border border-white/[2%] line-clamp-2">
              {member.bio}
            </p>

            {/* Portfolio Grid (Behance style) */}
            <div className="space-y-3.5">
              <h4 className="text-[11px] font-bold text-zinc-500 uppercase tracking-wider">شو-ریل ریلزهای من (برای تماشا کلیک کنید):</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {member.portfolio.slice(0, 2).map((item, idx) => (
                  <div 
                    key={idx}
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveVideoUrl(item.videoUrl);
                    }}
                    className="group/item rounded-xl overflow-hidden bg-zinc-950 border border-white/5 relative aspect-video cursor-pointer"
                  >
                    <img 
                      src={item.coverImage} 
                      alt={item.title} 
                      className="w-full h-full object-cover transition duration-500 group-hover/item:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-between p-3" />
                    
                    <div className="absolute top-2 right-2 px-2 py-0.5 rounded bg-black/60 text-[9px] font-mono font-extrabold text-amber-300">
                      {item.views} بازدید
                    </div>

                    <div className="absolute bottom-3 left-3 right-3 flex justify-between items-center z-10">
                      <p className="text-[10px] font-bold text-zinc-200 truncate max-w-[130px]">{item.title}</p>
                      <div className="flex gap-1.5 items-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleLike(item.title, e);
                          }}
                          className="p-1 px-2 rounded-md bg-white/10 hover:bg-white/20 text-[10px] text-rose-400 transition-all font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <Heart className="w-3 h-3 fill-rose-400 border-none" />
                          <span>{likes[item.title] || 15}</span>
                        </button>
                        <div className="p-1 rounded-full bg-brand-orange text-white">
                          <Play className="w-2.5 h-2.5 fill-white border-none" />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Profile Signup Proposal modal */}
      <AnimatePresence>
        {showApplyModal && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-zinc-950 border border-white/10 p-6 rounded-3xl max-w-lg w-full shadow-2xl relative text-right"
              dir="rtl"
            >
              <h3 className="text-md font-black text-white flex items-center gap-2 mb-4">
                <Sparkles className="w-5 h-5 text-brand-orange border-none" />
                درخواست عضویت در بانک سازندگان ساو
              </h3>

              {appliedSuccess ? (
                <div className="py-8 text-center space-y-3">
                  <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto border-none" />
                  <p className="text-sm font-black text-white">درخواست شما با موفقیت ثبت گردید!</p>
                  <p className="text-xs text-zinc-400">پس از بررسی نمونه کارها و بیوگرافی شما توسط ادمین ارشد ساو، تائیدیه پذیرش به بات تلگرام شما ارسال خواهد شد.</p>
                </div>
              ) : (
                <form onSubmit={handleApply} className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[11px] text-zinc-500 font-bold">نام و نام خانوادگی خلاقانه</label>
                    <input 
                      type="text" 
                      value={newCreatorName} 
                      onChange={(e) => setNewCreatorName(e.target.value)}
                      className="w-full px-3 py-2 bg-zinc-900 border border-white/10 rounded-xl text-xs text-white"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] text-zinc-500 font-bold">سمت / تخصص حرفه‌ای</label>
                    <input 
                      type="text" 
                      value={newCreatorRole} 
                      onChange={(e) => setNewCreatorRole(e.target.value)}
                      className="w-full px-3 py-2 bg-zinc-900 border border-white/10 rounded-xl text-xs text-white"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] text-zinc-500 font-bold">بیوگرافی کاری و سبک تدوین (قلاب، سرعت کات، افکت صدا و رنگ)</label>
                    <textarea 
                      value={newCreatorBio} 
                      onChange={(e) => setNewCreatorBio(e.target.value)}
                      rows={3}
                      placeholder="درباره پروژه‌های الهام گرفته، کارهای اجرا شده و سبک ریتمیک تدوین خود بنویسید..."
                      className="w-full px-3 py-2 bg-zinc-900 border border-white/10 rounded-xl text-xs text-white resize-none"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] text-zinc-500 font-bold">تگ‌های مهارتی (با ویرگول جدا کنید)</label>
                    <input 
                      type="text" 
                      value={newCreatorTags} 
                      onChange={(e) => setNewCreatorTags(e.target.value)}
                      placeholder="مثال: ریلز, کار با پریمیر, لوکس تاریک, اصلاح کادر"
                      className="w-full px-3 py-2 bg-zinc-900 border border-white/10 rounded-xl text-xs text-white"
                    />
                  </div>

                  <div className="flex justify-end gap-3 pt-3">
                    <button
                      type="button"
                      onClick={() => setShowApplyModal(false)}
                      className="px-4 py-2 rounded-xl bg-zinc-900 text-xs text-zinc-400 border border-white/5 cursor-pointer"
                    >
                      بستن
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-xl bg-brand-orange text-white text-xs font-black hover:opacity-90 transition-all cursor-pointer"
                    >
                      ثبت نهایی درخواست پروفایل
                    </button>
                  </div>
                </form>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Full screen Video Overlay Modal */}
      <AnimatePresence>
        {activeVideoUrl && (
          <div 
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
            onClick={() => setActiveVideoUrl(null)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-zinc-950 border border-white/10 rounded-2xl overflow-hidden max-w-2xl w-full aspect-video shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <video 
                src={activeVideoUrl} 
                className="w-full h-full object-contain"
                controls
                autoPlay
              />
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
