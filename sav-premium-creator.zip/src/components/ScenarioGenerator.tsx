/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAppState } from '../state';
import { 
  Sparkles, 
  Send, 
  Mic, 
  Copy, 
  Download, 
  Flame, 
  Heading, 
  Video, 
  Clapperboard, 
  Music, 
  ArrowRightLeft, 
  Loader2, 
  Share2, 
  Volume2, 
  Star,
  Check,
  FileDown
} from 'lucide-react';

export const ScenarioGenerator: React.FC = () => {
  const { 
    templates, 
    scenarios, 
    addScenario, 
    updateScenario, 
    requestExpertReview,
    currentUser,
    incrementAiCount
  } = useAppState();

  const [promptInput, setPromptInput] = useState('');
  const [selectedTone, setSelectedTone] = useState('سینماتیک و لوکس');
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeScenario, setActiveScenario] = useState<any>(null);
  const [refinementInput, setRefinementInput] = useState('');
  const [isRefining, setIsRefining] = useState(false);
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [resultTab, setResultTab] = useState<'script' | 'caption' | 'flow' | 'camera'>('script');
  const [showPaywallOverlay, setShowPaywallOverlay] = useState(false);

  // Simulation voice state
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSuccess, setRecordingSuccess] = useState(false);

  const tonePresets = [
    { value: 'سینماتیک و لوکس', label: '🎬 سینماتیک لوکس' },
    { value: 'وایرال شدید', label: '🔥 وایرال افشاگری' },
    { value: 'احساسی عمیق', label: '💖 عاطفی و احساسی' },
    { value: 'داستان‌سرایی تعلیق‌آمیز', label: '🕴️ مهیج و قصه‌گو' },
    { value: 'مستندسازی مینیمال', label: '🏛️ کلاسیک و اصیل' },
    { value: 'لحن لوکس ادیتورال', label: '💎 لاکچری و مجلل' }
  ];

  // Helper trigger copy
  const handleCopy = (text: string, section: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(section);
    setTimeout(() => setCopiedSection(null), 3000);
  };

  // Launch AI scenario generation using Express server endpoints
  const handleGenerate = async () => {
    if (!promptInput.trim()) return;

    if (currentUser.isGuest && currentUser.aiCount >= 3) {
      setShowPaywallOverlay(true);
      return;
    }

    setIsGenerating(true);
    setActiveScenario(null);

    try {
      const response = await fetch('/api/generate-scenario', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idea: promptInput, tone: selectedTone })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || 'خطا در تولید سناریو');
      }

      // Add to synced lists
      const saved = addScenario({
        idea: promptInput,
        tone: selectedTone,
        hook: data.hook,
        scenarioText: data.scenarioText,
        caption: data.caption,
        cta: data.cta,
        storyFlow: data.storyFlow,
        shotList: data.shotList,
        cameraDirections: data.cameraDirections,
        musicMood: data.musicMood
      });

      incrementAiCount();
      setActiveScenario(saved);
    } catch (err: any) {
      alert(err.message || 'مشکلی در اتصال رخ داد. آیا کلید وب‌سرویس فعال است؟');
    } finally {
      setIsGenerating(false);
    }
  };

  // Run AI refinement instruction on current scenario
  const handleRefine = async () => {
    if (!refinementInput.trim() || !activeScenario) return;

    setIsRefining(true);
    try {
      const response = await fetch('/api/refine-scenario', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ previousScenario: activeScenario, instruction: refinementInput })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || 'خطا در اعمال تغییرات هوش مصنوعی');
      }

      // Update in synced state
      updateScenario(activeScenario.id, {
        hook: data.hook,
        scenarioText: data.scenarioText,
        caption: data.caption,
        cta: data.cta,
        storyFlow: data.storyFlow,
        shotList: data.shotList,
        cameraDirections: data.cameraDirections,
        musicMood: data.musicMood
      });

      setActiveScenario({
        ...activeScenario,
        ...data
      });
      setRefinementInput('');
    } catch (err: any) {
      alert(err.message || 'خطا در ویرایش سناریو');
    } finally {
      setIsRefining(false);
    }
  };

  // Simulate audio recording to satisfy user prompt input requirement
  const toggleRecording = () => {
    if (!isRecording) {
      setIsRecording(true);
      setTimeout(() => {
        setIsRecording(false);
        setRecordingSuccess(true);
        setPromptInput('یک ایده خلاقانه درباره ریلز معرفی لوکس پمپ بنزین برقی و ماشین بنز برقی جدید ایران خودرو با افکت‌های نور لایتری.');
      }, 3500);
    }
  };

  // Simple HTML Print triggers editorial-like beautiful RTL document print/save
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Editorial Dashboard Hero */}
      <div className="relative overflow-hidden rounded-3xl p-8 bg-gradient-to-b from-white/[3%] to-transparent border border-white/5 shadow-2xl">
        <div className="absolute top-0 left-0 w-96 h-96 bg-brand-orange/10 rounded-full blur-3xl -z-10 pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-brand-red/5 rounded-full blur-3xl -z-10 pointer-events-none" />

        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-orange/10 border border-brand-orange/20 text-brand-orange text-xs font-bold leading-none animate-pulse">
            <Flame className="w-3 h-3" />
            <span>مجهز به کلاک ۳.۵ فلش هوشمند</span>
          </div>
          <h2 className="text-3xl font-black text-white leading-tight">با جادوی هوش مصنوعی، سناریوهایی خلق کنید که <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-orange to-brand-red">اکسپلور را منفجر کند</span></h2>
          <p className="text-zinc-400 text-sm leading-relaxed max-w-2xl">
            ایده خام خود را تایپ کنید، بنویسید، قالب‌های از پیش طراحی شده را لود کنید یا حتی با صدای خود توصیف کنید. سیستم ساو تمام زوایای دوربین، طراحی قلاب، شات لیست و متن را فورا برایتان دکوپاژ خواهد کرد.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Input Interface */}
        <div className="lg:col-span-1 space-y-6">
          <div className="rounded-2xl p-6 bg-matte-black border border-white/5 space-y-6 shadow-xl">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-brand-orange" />
              ورودی ایده‌ی خلاقانه
            </h3>

            {/* Quick Templates Selector */}
            <div className="space-y-2.5">
              <label className="text-xs font-semibold text-zinc-400">لود سریع قالب‌های طلایی ساو</label>
              <div className="grid grid-cols-1 gap-2">
                {templates.slice(0, 3).map((tpl) => (
                  <button
                    key={tpl.id}
                    onClick={() => {
                      setPromptInput(tpl.prompt);
                      setSelectedTone(tpl.aiStyle);
                    }}
                    className="w-full text-right p-3 rounded-xl bg-white/[2%] border border-white/5 hover:border-brand-orange/30 hover:bg-white/[4%] transition-all"
                  >
                    <p className="text-xs font-bold text-zinc-200">{tpl.title}</p>
                    <p className="text-[10px] text-zinc-500 mt-1 truncate">{tpl.prompt}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Prompt text input & Mic Simulation interface */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-zinc-400">توضیح ایده (یا استفاده از ویس)</label>
              <div className="relative">
                <textarea
                  value={promptInput}
                  onChange={(e) => setPromptInput(e.target.value)}
                  placeholder="ایده خود را بنویسید... مثلا: یک رستوران شیک کلاسیک در برج میلاد، که غذاهای سنتی گران‌قیمت با دکور نئون سرو می‌کند..."
                  rows={4}
                  className="w-full p-4 rounded-xl bg-white/[3%] border border-white/10 text-white text-xs leading-relaxed placeholder-zinc-600 focus:outline-none focus:border-brand-orange/50 focus:ring-1 focus:ring-brand-orange/30 transition-all resize-none"
                />

                {/* Simulated Microphone Recording button */}
                <button
                  onClick={toggleRecording}
                  type="button"
                  className={`absolute left-3 bottom-4 p-2.5 rounded-full border transition-all ${
                    isRecording 
                      ? 'bg-rose-500/10 border-rose-500 text-rose-500 animate-pulse' 
                      : 'bg-zinc-800 border-white/15 text-zinc-400 hover:text-white'
                  }`}
                  title="بارگذاری یادداشت صوتی"
                >
                  <Mic className="w-4 h-4" />
                </button>
              </div>

              {/* simulated output */}
              <AnimatePresence>
                {isRecording && (
                  <motion.div 
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="p-3 rounded-xl bg-rose-500/5 border border-rose-500/20 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1">
                        <span className="w-1 h-3 bg-rose-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                        <span className="w-1 h-5 bg-rose-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                        <span className="w-1 h-2 bg-rose-500 rounded-full animate-bounce" style={{ animationDelay: '0.3s' }} />
                        <span className="w-1 h-4 bg-rose-500 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
                      </div>
                      <span className="text-[10px] text-rose-400 font-bold">در حال شنیدن و رونویسی ویس شما...</span>
                    </div>
                  </motion.div>
                )}

                {recordingSuccess && !isRecording && (
                  <motion.p 
                    initial={{ opacity: 0 }} 
                    animate={{ opacity: 1 }}
                    className="text-[10px] text-green-400 font-bold"
                  >
                    ✓ ویس با موفقیت رونویسی و لود شد!
                  </motion.p>
                )}
              </AnimatePresence>
            </div>

            {/* Tone preset selector */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-zinc-400">لحن و سبک ویدیو</label>
              <div className="grid grid-cols-2 gap-2">
                {tonePresets.map((t) => (
                  <button
                    key={t.value}
                    onClick={() => setSelectedTone(t.value)}
                    className={`p-2.5 rounded-xl text-right text-xs font-medium transition-all border ${
                      selectedTone === t.value 
                        ? 'bg-brand-orange/10 border-brand-orange/40 text-brand-orange shadow-md' 
                        : 'bg-white/[2%] border-white/5 text-zinc-400 hover:bg-white/[4%]'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Dispatch submit */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleGenerate}
              disabled={isGenerating || !promptInput.trim()}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-brand-orange to-brand-red hover:from-orange-600 hover:to-rose-600 text-white font-extrabold text-sm shadow-xl shadow-brand-orange/20 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>تولید جادویی توسط هوش مصنوعی ساو...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>خلق فوری سناریوی اینستاگرام</span>
                </>
              )}
            </motion.button>
          </div>
        </div>

        {/* Output Area */}
        <div className="lg:col-span-2 space-y-6">
          <div className="rounded-2xl bg-matte-black border border-white/5 p-6 shadow-xl min-h-[500px] flex flex-col justify-between">
            
            {/* Fallback state when idle */}
            {!activeScenario && !isGenerating && (
              <div className="my-auto text-center space-y-4 max-w-md mx-auto p-8">
                <div className="w-16 h-16 rounded-2xl bg-white/[2%] border border-white/5 mx-auto flex items-center justify-center text-zinc-500">
                  <Sparkles className="w-8 h-8 text-brand-orange/30" />
                </div>
                <h4 className="text-base font-bold text-zinc-300">آماده جادوی خلق سناریو</h4>
                <p className="text-xs text-zinc-500 leading-relaxed">
                  از فرم سمت راست پارامترها را انتخاب کرده و ایده خود را ثبت کنید. نتایج ریلز شامل سناریو دکوپاژ شده درجه یک در این بخش ظاهر خواهد شد.
                </p>
              </div>
            )}

            {/* Loading Indicator with helpful text */}
            {isGenerating && (
              <div className="my-auto text-center space-y-4 py-12">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                  className="w-12 h-12 rounded-full border-t-2 border-r-2 border-brand-orange border-b-0 border-l-0 mx-auto"
                />
                <h4 className="text-base font-black text-white animate-pulse">تولید ساختار سناریو و جزئیات دکوپاژ...</h4>
                <p className="text-xs text-zinc-400 max-w-sm mx-auto">
                  هوش مصنوعی در حال تحلیل الگوریتم وایرال ریلز، پیوست با لحن {selectedTone} و نوشتن شات‌لیست سینمایی است. این روند ممکن است ۵ تا ۱۰ ثانیه طول بکشد.
                </p>
              </div>
            )}

            {/* Generated display section */}
            {activeScenario && !isGenerating && (
              <div className="space-y-6 flex-1 flex flex-col justify-between">
                <div>
                  {/* Top toolbar */}
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-white/5 gap-3">
                    <div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-brand-orange font-bold">کد سناریو: {activeScenario.id.toUpperCase()}</span>
                      <h4 className="text-md font-bold text-white mt-1">طرح دکوپاژ نهایی: {activeScenario.idea.substring(0, 30)}...</h4>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={handlePrint}
                        className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-white/5 hover:border-white/10 text-zinc-300 text-xs font-semibold transition-all flex items-center gap-1.5"
                      >
                        <FileDown className="w-3.5 h-3.5" />
                        <span>فرم چاپی / ذخیره PDF</span>
                      </button>

                      {/* Professional expert review trigger */}
                      {activeScenario.reviewStatus === 'pending' ? (
                        <button
                          onClick={() => requestExpertReview(activeScenario.id)}
                          className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500/10 to-orange-500/10 hover:from-amber-500/20 hover:to-orange-500/20 border border-amber-500/30 text-amber-300 text-xs font-bold transition-all flex items-center gap-1.5"
                          title="ارسال سناریو به مربیان فیلمسازی جهت بازبینی زنده"
                        >
                          <span>درخواست بررسی تخصصی</span>
                          <Star className="w-3.5 h-3.5 fill-amber-300/20" />
                        </button>
                      ) : (
                        <div className="px-3 py-1.5 rounded-lg bg-white/[2%] border border-white/10 text-zinc-400 text-xs font-bold flex items-center gap-1.5">
                          <Check className="w-3.5 h-3.5 text-green-400" />
                          <span>
                            {activeScenario.reviewStatus === 'under_review' ? 'در حال بررسی توسط مربی' : 'بررسی تکمیل شده'}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Editorial Layout with Beautiful Display Tabs */}
                  <div className="flex items-center gap-1 border-b border-white/5 mt-4 overflow-x-auto pb-1">
                    {[
                      { id: 'script', label: '🎬 متن و قلاب (Hook)', icon: Heading },
                      { id: 'caption', label: '✍ کپشن و اقدام (CTA)', icon: Share2 },
                      { id: 'flow', label: '🖼 استوری‌فلو و شات‌لیست', icon: Clapperboard },
                      { id: 'camera', label: '📹 حرکت دوربین و موزیک', icon: Music },
                    ].map((tab) => {
                      const Icon = tab.icon;
                      const isActive = resultTab === tab.id;
                      return (
                        <button
                          key={tab.id}
                          onClick={() => setResultTab(tab.id as any)}
                          className={`px-4 py-2 text-xs font-bold whitespace-nowrap rounded-lg transition-all relative ${
                            isActive ? 'text-brand-orange bg-brand-orange/5' : 'text-zinc-400 hover:text-zinc-200'
                          }`}
                        >
                          <span className="relative z-10 flex items-center gap-1.5">{tab.label}</span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Tab Contents styling */}
                  <div className="mt-6 min-h-[220px]">
                    <AnimatePresence mode="wait">
                      {resultTab === 'script' && (
                        <motion.div
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          className="space-y-4"
                        >
                          {/* 3 sec Hook display */}
                          <div className="p-4 rounded-xl bg-orange-500/5 border border-brand-orange/20 space-y-1.5 glow-orange">
                            <span className="text-[10px] font-bold text-brand-orange bg-brand-orange/10 px-2 py-0.5 rounded-full inline-block">قلاب طلایی ۳ ثانیه اول (🔥 Hook)</span>
                            <p className="text-sm font-black text-white leading-relaxed">{activeScenario.hook}</p>
                          </div>
                          {/* Scenario text body */}
                          <div className="p-4 rounded-xl bg-white/[2%] border border-white/5 space-y-2">
                            <span className="text-[10px] font-bold text-zinc-400">متن دیالوگ‌ها و فرآیند دکوپاژ خلاق</span>
                            <p className="text-xs text-zinc-300 leading-relaxed whitespace-pre-line">{activeScenario.scenarioText}</p>
                          </div>
                        </motion.div>
                      )}

                      {resultTab === 'caption' && (
                        <motion.div
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          className="space-y-4"
                        >
                          {/* CTA display */}
                          <div className="p-4 rounded-xl bg-rose-500/5 border border-rose-500/20 space-y-1.5">
                            <span className="text-[10px] font-bold text-brand-red bg-rose-500/10 px-2 py-0.5 rounded-full inline-block">دکمه اقدام به عمل (🚀 Call To Action)</span>
                            <p className="text-sm font-bold text-white leading-relaxed">{activeScenario.cta}</p>
                          </div>
                          {/* Caption body */}
                          <div className="p-4 rounded-xl bg-white/[2%] border border-white/5 space-y-2 relative">
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-bold text-zinc-400">کپشن آماده کپی با هشتگ‌های اختصاصی</span>
                              <button
                                onClick={() => handleCopy(activeScenario.caption, 'cap')}
                                className="p-1.5 rounded-md bg-zinc-900 border border-white/5 text-zinc-400 hover:text-white transition-all flex items-center gap-1"
                              >
                                {copiedSection === 'cap' ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                              </button>
                            </div>
                            <p className="text-xs text-zinc-300 leading-relaxed whitespace-pre-line bg-zinc-950/40 p-3 rounded-lg border border-white/[2%] font-sans">{activeScenario.caption}</p>
                          </div>
                        </motion.div>
                      )}

                      {resultTab === 'flow' && (
                        <motion.div
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          className="space-y-4"
                        >
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {/* Story Flow */}
                            <div className="p-4 rounded-xl bg-white/[2%] border border-white/5 space-y-3">
                              <span className="text-[10px] font-bold text-amber-400">روند استوری‌فلو هماهنگ (Storyboards)</span>
                              <div className="space-y-2">
                                {(activeScenario.storyFlow || []).map((step: string, idx: number) => (
                                  <div key={idx} className="flex gap-2.5 text-xs">
                                    <span className="w-5 h-5 rounded-md bg-amber-400/10 border border-amber-400/20 text-amber-300 font-bold flex items-center justify-center shrink-0">{idx + 1}</span>
                                    <p className="text-zinc-300 leading-relaxed">{step}</p>
                                  </div>
                                ))}
                              </div>
                            </div>
                            {/* Shot List */}
                            <div className="p-4 rounded-xl bg-white/[2%] border border-white/5 space-y-3">
                              <span className="text-[10px] font-bold text-rose-400">شات‌لیست تصویربرداری موبایلی</span>
                              <div className="space-y-2">
                                {(activeScenario.shotList || []).map((step: string, idx: number) => (
                                  <div key={idx} className="flex gap-2.5 text-xs">
                                    <span className="w-5 h-5 rounded-md bg-rose-500/10 border border-rose-500/20 text-rose-400 font-bold flex items-center justify-center shrink-0">{idx + 1}</span>
                                    <p className="text-zinc-300 leading-relaxed">{step}</p>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      )}

                      {resultTab === 'camera' && (
                        <motion.div
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          className="space-y-4"
                        >
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {/* Camera directions */}
                            <div className="p-4 rounded-xl bg-white/[2%] border border-white/5 space-y-2">
                              <div className="flex items-center gap-1.5 text-zinc-350">
                                <Video className="w-4 h-4 text-brand-orange" />
                                <span className="text-[10px] font-bold text-zinc-400">زوایای دوربین و دکوپاژ حرکتی</span>
                              </div>
                              <p className="text-xs text-zinc-300 leading-relaxed">{activeScenario.cameraDirections}</p>
                            </div>
                            {/* Music mood recommendations */}
                            <div className="p-4 rounded-xl bg-white/[2%] border border-white/5 space-y-2">
                              <div className="flex items-center gap-1.5 text-zinc-350">
                                <Music className="w-4 h-4 text-brand-red" />
                                <span className="text-[10px] font-bold text-zinc-400">ریتم موزیک و صدای امبینت پیشنهادی</span>
                              </div>
                              <p className="text-xs text-zinc-300 leading-relaxed">{activeScenario.musicMood}</p>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>

                {/* Scenario Refinement interface: Chat-with-existing to modify */}
                <div className="pt-6 border-t border-white/5 mt-6 space-y-4">
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-brand-orange" />
                    <h5 className="text-xs font-bold text-white">درخواست بازنویسی یا ویرایش جزئی سناریو</h5>
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={refinementInput}
                      onChange={(e) => setRefinementInput(e.target.value)}
                      placeholder="چه تغییری بدهم؟ مثلا: 'بیشتر لوسش کن'، 'قلاب را طوفانی‌تر کن'، 'لحن نهایی را با کلمات طنز جفت کن'..."
                      className="flex-1 px-4 py-3 rounded-xl bg-white/[3%] border border-white/10 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-brand-orange/40"
                    />
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={handleRefine}
                      disabled={isRefining || !refinementInput.trim()}
                      className="px-5 py-3 rounded-xl bg-zinc-900 border border-white/10 text-white font-bold text-xs flex items-center gap-2 hover:bg-zinc-800 disabled:opacity-50"
                    >
                      {isRefining ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ArrowRightLeft className="w-3.5 h-3.5 text-brand-orange" />}
                      <span>اعمال فیدبک</span>
                    </motion.button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Expert review summary status track for user's tranquility */}
      <AnimatePresence>
        {scenarios.length > 0 && (
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-2xl p-6 bg-matte-black border border-white/5 shadow-xl space-y-4"
          >
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <span className="inline-block w-2 h-2 rounded-full bg-amber-400" />
              صندوق نظارت و آرشیو سناریوهای من ({scenarios.length})
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="border-b border-white/5 text-zinc-500">
                    <th className="py-2.5 pb-4 font-bold">ایده شروع کالا</th>
                    <th className="py-2.5 pb-4 font-bold">لحن انتخابی</th>
                    <th className="py-2.5 pb-4 font-bold">تاریخ ثبت</th>
                    <th className="py-2.5 pb-4 font-bold">بررسی تخصصی</th>
                    <th className="py-2.5 pb-4 font-bold">یادداشت مربی ساو</th>
                    <th className="py-2.5 pb-4 font-bold">عملیات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[3%] text-zinc-300">
                  {scenarios.map((sc) => (
                    <tr key={sc.id} className="hover:bg-white/[1%] transition-colors">
                      <td className="py-3 font-semibold text-white max-w-[200px] truncate">{sc.idea}</td>
                      <td className="py-3">{sc.tone}</td>
                      <td className="py-3 font-mono">{sc.createdAt}</td>
                      <td className="py-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          sc.reviewStatus === 'pending' 
                            ? 'bg-zinc-800 text-zinc-400' 
                            : sc.reviewStatus === 'under_review'
                            ? 'bg-amber-400/10 text-amber-400 border border-amber-400/20'
                            : 'bg-green-500/10 text-green-400 border border-green-500/20'
                        }`}>
                          {sc.reviewStatus === 'pending' ? 'بدون درخواست' : sc.reviewStatus === 'under_review' ? 'در انتظار بررسی' : 'پایان بررسی تعاملی'}
                        </span>
                      </td>
                      <td className="py-3">
                        <p className="max-w-[150px] truncate text-slate-400 italic">
                          {sc.expertNotes || 'هنوز دیدگاهی ثبت نشده'}
                        </p>
                      </td>
                      <td className="py-3">
                        <button
                          onClick={() => {
                            setActiveScenario(sc);
                            setResultTab('script');
                          }}
                          className="px-2.5 py-1 rounded bg-zinc-900 hover:bg-brand-orange/10 hover:text-brand-orange border border-white/5 text-[11px] transition-all"
                        >
                          بارگذاری در ویرایشگر
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Freemium Limit Gate Modal */}
      <AnimatePresence>
        {showPaywallOverlay && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 text-right" dir="rtl">
            <motion.div
              initial={{ scale: 0.92, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.92, opacity: 0 }}
              className="bg-zinc-950 border border-brand-orange/30 p-8 rounded-3xl max-w-md w-full relative space-y-6 shadow-[0_0_50px_rgba(255,87,34,0.15)]"
            >
              <button
                onClick={() => setShowPaywallOverlay(false)}
                className="absolute top-4 left-4 text-zinc-550 hover:text-white text-xs font-bold"
              >
                بستن موقت ×
              </button>

              <div className="space-y-2 text-center">
                <span className="text-[10px] bg-brand-orange/15 border border-brand-orange/30 text-brand-orange px-3 py-1 rounded-full font-black tracking-wider uppercase inline-block">
                  🔒 سقف استفاده رایگان مهمان
                </span>
                <h3 className="text-xl font-black text-white mt-3">شما به سقف تولید مجانی ساو رسیده‌اید!</h3>
                <p className="text-xs text-zinc-400 leading-relaxed md:px-2">
                  به لایو دکوپاژ هوش مصنوعی ساو خوش آمدید. حساب‌های مهمان بدون ثبت‌نام مجاز به زدن حداکثر <span className="text-white font-bold">۳ سناریوی آزمایشی</span> هستند.
                </p>
              </div>

              {/* Status bar */}
              <div className="p-4 rounded-2xl bg-white/[2%] border border-white/5 space-y-3 text-xs">
                <div className="flex justify-between">
                  <span className="text-zinc-400">استفاده شده تا الان:</span>
                  <span className="text-brand-orange font-bold font-mono">{currentUser.aiCount} از ۳ دفعه</span>
                </div>
                <div className="w-full h-1.5 bg-zinc-900 rounded-full overflow-hidden">
                  <div className="w-full h-full bg-brand-orange" />
                </div>
              </div>

              {/* Action Guides */}
              <div className="space-y-3">
                <p className="text-[10px] text-zinc-500 font-extrabold text-start">برای برداشته شدن سقف ۳ تایی چه کنم؟</p>
                <div className="space-y-2">
                  <button
                    onClick={() => {
                      setShowPaywallOverlay(false);
                      // Trigger main header login modal simulation by instructing client
                      alert('💡 کریتور گرامی، لطفا روی دکمه "ورود / ثبت‌نام" در بالای صحنه کلیک فرمایید تا اکانت خود را بلافاصله ایجاد کنید.');
                    }}
                    className="w-full py-3.5 rounded-xl bg-white/5 hover:bg-white/10 text-white font-bold text-xs transition-all border border-white/15 flex items-center justify-center gap-2"
                  >
                    <span>ثبت‌نام ابری سریع (توسعه سقف استفاده)</span>
                  </button>

                  <div className="text-center text-[10px] text-zinc-650 my-1">یا با فعالسازی حق عضویت ویژه ساو سناریوهای نامحدود بسازید:</div>

                  <button
                    onClick={() => {
                      setShowPaywallOverlay(false);
                      // instruct header upgradeGold trigger
                      alert('💡 لطفا روی "ارتقا به ویژه" در منوی هدر کلیک کنید تا درگاه پرداخت طلایی شبیه‌سازی گردد.');
                    }}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-brand-orange to-brand-red text-white font-black text-xs shadow-lg shadow-brand-orange/15 transition-all"
                  >
                    🚀 عضویت در کلوب ریلز طلایی ساو (نامحدود)
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
