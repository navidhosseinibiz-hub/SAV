/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  Heart, 
  Compass, 
  ArrowLeft, 
  ArrowRight, 
  Copy, 
  Download, 
  Save, 
  Video, 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Loader2, 
  Check, 
  Bookmark, 
  Film, 
  Layers, 
  Music, 
  Tv, 
  Eye,
  Hash,
  Sparkle
} from 'lucide-react';
import { useAppState } from '../state';
import { InspirationVideo, Scenario } from '../types';

export const InspirationFeed: React.FC = () => {
  const { 
    inspirationVideos, 
    inspirationCategories, 
    likeInspirationVideo, 
    addScenario,
    currentUser,
    incrementAiCount
  } = useAppState();

  // State Management
  const [selectedCategory, setSelectedCategory] = useState<string>('همه');
  const [activeVideo, setActiveVideo] = useState<InspirationVideo | null>(null);
  const [isMuted, setIsMuted] = useState<boolean>(true);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  
  // Wizard State
  const [wizardOpen, setWizardOpen] = useState<boolean>(false);
  const [wizardStep, setWizardStep] = useState<number>(1);
  const [copied, setCopied] = useState<boolean>(false);
  const [isSaved, setIsSaved] = useState<boolean>(false);

  // Form Inputs for Wizard
  const [productName, setProductName] = useState<string>('');
  const [isSelling, setIsSelling] = useState<string>('بله');
  const [userIdea, setUserIdea] = useState<string>('');
  const [targetAudience, setTargetAudience] = useState<string>('');
  const [selectedTone, setSelectedTone] = useState<string>('دوستانه و صمیمی');

  // Generation Loading and Output
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generatingProgress, setGeneratingProgress] = useState<string>('');
  const [rewrittenScenario, setRewrittenScenario] = useState<any | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);

  // Mute control toggle
  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  // Play control toggle
  const togglePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play().catch(() => {});
      }
      setIsPlaying(!isPlaying);
    }
  };

  // Autoplay video when activeVideo changes
  useEffect(() => {
    if (activeVideo && videoRef.current) {
      setIsPlaying(true);
      videoRef.current.play().catch(() => {});
    }
  }, [activeVideo]);

  // Handle category filtering
  const filteredVideos = inspirationVideos.filter(video => {
    if (selectedCategory === 'همه') return true;
    return video.category === selectedCategory;
  });

  // Sort: pinned first, then by date/id
  const sortedVideos = [...filteredVideos].sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    return b.id.localeCompare(a.id);
  });

  // Progress Logger simulation
  useEffect(() => {
    if (isGenerating) {
      const logs = [
        'در حال اسکن ریتم و تدوین ویدئوی الهام‌بخش مرجع...',
        'استخراج زوایای دکوپاژ و شات‌لیست مبدأ...',
        'بارگذاری اطلاعات اختصاصی محصول شما («' + productName + '»)...',
        'تطبیق لحن درخواستی بومی‌سازی شده...',
        'بازآفرینی همه‌جانبه‌ی ساختار سناریو و قلاب ۳ ثانیه‌ای...'
      ];
      
      let index = 0;
      setGeneratingProgress(logs[0]);
      const interval = setInterval(() => {
        index++;
        if (index < logs.length) {
          setGeneratingProgress(logs[index]);
        } else {
          clearInterval(interval);
        }
      }, 1500);

      return () => clearInterval(interval);
    }
  }, [isGenerating, productName]);

  // Handle Rewrite Application
  const handleStartRewrite = async () => {
    if (!productName.trim()) {
      alert('لطفا نام محصول یا خدمت خود را بنویسید.');
      return;
    }

    setIsGenerating(true);
    setErrorMsg(null);
    setRewrittenScenario(null);

    try {
      const response = await fetch('/api/rewrite-inspiration', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          originalScenario: activeVideo?.scenario || '',
          originalTranscript: activeVideo?.transcript || '',
          productName,
          isSellingProduct: isSelling,
          userIdea,
          targetAudience,
          tone: selectedTone
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || 'خطا در برقراری ارتباط با وب‌سرویس هوش مصنوعی');
      }

      setRewrittenScenario(data);
      incrementAiCount(); // Update the user's AI usage count
      setWizardStep(4); // Advance to results
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'مشکلی در ارتباط با سرور ساو پیش آمد. مجدداً تلاش کنید.');
      setWizardStep(1);
    } finally {
      setIsGenerating(false);
    }
  };

  // Close wizard and reset state
  const handleCloseWizard = () => {
    setWizardOpen(false);
    setWizardStep(1);
    setIsSaved(false);
    setProductName('');
    setUserIdea('');
    setTargetAudience('');
    setSelectedTone('دوستانه و صمیمی');
    setRewrittenScenario(null);
    setErrorMsg(null);
  };

  // Copy scenario text to clipboard
  const handleCopyText = () => {
    if (!rewrittenScenario) return;
    
    const formattedText = `
عنوان سناریو الهام‌بخش: ${productName} - الهام گرفته از ${activeVideo?.title}
===================================================

[قلاب ۳ ثانیه‌ای طوفانی]
${rewrittenScenario.hook}

[متن سناریو ریتمیک]
${rewrittenScenario.scenarioText}

[کپشن الگوریتمی]
${rewrittenScenario.caption}

[دعوت به اقدام (CTA)]
${rewrittenScenario.cta}

[دکوپاژ و حرکات دوربین]
${rewrittenScenario.cameraDirections}

[نوع موزیک پیشنهادی]
${rewrittenScenario.musicMood}

[استوری فلو متصل]
${rewrittenScenario.storyFlow?.join('\n')}

[شات‌لیست تصویربرداری]
${rewrittenScenario.shotList?.join('\n')}
    `;

    navigator.clipboard.writeText(formattedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Save to the user's dynamic workspace list
  const handleSaveToWorkspace = () => {
    if (!rewrittenScenario) return;

    addScenario({
      idea: `الهام‌یافته: ${productName} (${activeVideo?.title})`,
      tone: selectedTone,
      hook: rewrittenScenario.hook,
      scenarioText: rewrittenScenario.scenarioText,
      caption: rewrittenScenario.caption,
      cta: rewrittenScenario.cta,
      storyFlow: rewrittenScenario.storyFlow || [],
      shotList: rewrittenScenario.shotList || [],
      cameraDirections: rewrittenScenario.cameraDirections || '',
      musicMood: rewrittenScenario.musicMood || ''
    });

    setIsSaved(true);
  };

  // Download Custom Highly Polished File
  const handleDownloadPDF = () => {
    if (!rewrittenScenario) return;

    const mockHTMLDoc = `
      <!DOCTYPE html>
      <html lang="fa" dir="rtl">
      <head>
        <meta charset="UTF-8">
        <title>سناریوی اختصاصی الهام‌گیری ساو</title>
        <style>
          body { font-family: Tahoma, sans-serif; background-color: #0c0a09; color: #f5f5f4; padding: 40px; line-height: 1.8; text-align: right; }
          .container { max-width: 800px; margin: 0 auto; border: 1px solid #78350f; background-color: #1c1917; padding: 30px; border-radius: 20px; box-shadow: 0 10px 40px rgba(0,0,0,0.5); }
          h1 { color: #f97316; font-size: 24px; border-bottom: 2px solid #2e2a24; padding-bottom: 15px; margin-bottom: 30px; }
          h2 { color: #fdba74; font-size: 18px; margin-top: 25px; border-right: 4px solid #f97316; padding-right: 10px; }
          .meta { font-size: 12px; color: #a8a29e; margin-bottom: 20px; background: #2e2a24; padding: 10px; border-radius: 8px; }
          .card { background-color: #292524; border: 1px solid #444; padding: 15px; border-radius: 12px; margin-bottom: 15px; }
          .hook { font-size: 16px; font-weight: bold; color: #fb923c; border-left: none; }
          .badge { background: #ea580c; color: white; padding: 3px 8px; font-size: 11px; border-radius: 4px; margin-right: 5px; }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>⚡ سناریوی اختصاصی ریلز برند ساو</h1>
          <div class="meta">
            <span><strong>محصول هدف:</strong> ${productName}</span> | 
            <span><strong>الهام‌گرفته از ویدئوی:</strong> ${activeVideo?.title}</span> | 
            <span><strong>لحن درخواستی:</strong> ${selectedTone}</span>
          </div>
          
          <h2>★ قلاب ۳ ثانیه‌ای اول ویدیو (Hook)</h2>
          <div class="card hook">${rewrittenScenario.hook}</div>

          <h2>🎬 دکوپاژ و متن کامل ویدیو (Scenario Text)</h2>
          <div class="card">${rewrittenScenario.scenarioText.replace(/\n/g, '<br>')}</div>

          <h2>✍️ کپشن الگوریتمی و آماده انتشار (Caption)</h2>
          <div class="card">${rewrittenScenario.caption.replace(/\n/g, '<br>')}</div>

          <h2>📣 دعوت به اقدام هوشمند (CTA)</h2>
          <div class="card">${rewrittenScenario.cta}</div>

          <h2>🎹 جزئیات فنی و اتمسفر</h2>
          <div class="card">
            <p><strong>تنظیمات لنز و حرکت دوربین:</strong> ${rewrittenScenario.cameraDirections}</p>
            <p><strong>موسیقی متن و ضرب‌آهنگ:</strong> ${rewrittenScenario.musicMood}</p>
          </div>

          <h2>📱 استوری فلوهای تکمیلی</h2>
          <div class="card">
            <ul>
              ${rewrittenScenario.storyFlow?.map((s: string) => `<li>${s}</li>`).join('')}
            </ul>
          </div>

          <h2>📸 شات‌لیست تصویربرداری</h2>
          <div class="card">
            <ul>
              ${rewrittenScenario.shotList?.map((s: string) => `<li>${s}</li>`).join('')}
            </ul>
          </div>
        </div>
      </body>
      </html>
    `;

    const blob = new Blob([mockHTMLDoc], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `SAV-Inspiration-${productName.replace(/\s+/g, '-')}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const isLikedByMe = (video: InspirationVideo) => {
    const userId = currentUser ? currentUser.id : 'anonymous';
    return video.likedByUsers?.includes(userId) || false;
  };

  return (
    <div className="space-y-8 select-none">
      
      {/* Editorial Title Banner */}
      <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-white/[5%] pb-5 gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-1 px-2.5 bg-brand-orange/10 border border-brand-orange/20 text-brand-orange font-bold text-[10px] rounded-full uppercase tracking-wider flex items-center gap-1.5">
              <Sparkle className="w-3 h-3 fill-brand-orange animate-pulse" /> ویدیوهای جریان‌ساز
            </div>
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight">کستینگ دمو و فید الهام‌گیری سناریو</h2>
          <p className="text-xs text-zinc-400">گلچینی از ریلزهای پربازدید ادمین؛ ریتم هر ویدیو را بررسی کنید و با کپی هوش مصنوعی فوراً نسخه بومی خودتان را بسازید.</p>
        </div>

        {/* Categories horizontal filter bar */}
        <div className="flex flex-wrap gap-1.5 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
          <button
            onClick={() => setSelectedCategory('همه')}
            className={`px-4 py-2 rounded-full text-xs font-black transition-all border shrink-0 ${
              selectedCategory === 'همه'
                ? 'bg-white text-zinc-950 border-white'
                : 'bg-white/[2%] text-zinc-400 border-white/5 hover:bg-white/[5%] hover:text-white'
            }`}
          >
            همه الهام‌ها
          </button>
          {inspirationCategories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-full text-xs font-black transition-all border shrink-0 ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-brand-orange to-brand-red text-white border-none shadow-[0_4px_20px_rgba(234,88,12,0.3)]'
                  : 'bg-white/[2%] text-zinc-400 border-white/5 hover:bg-white/[5%] hover:text-white'
              }`}
            >
              # {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Main vertical scrolling grid layout */}
      {sortedVideos.length === 0 ? (
        <div className="text-center p-16 rounded-3xl bg-zinc-950 border border-white/5 space-y-4">
          <Video className="w-12 h-12 text-zinc-600 mx-auto" />
          <h4 className="text-sm font-bold text-white">هیچ ویدیوی الهام‌بخشی در این دسته‌بندی وجود ندارد</h4>
          <p className="text-xs text-zinc-500">ادمین هنوز ویدیویی در این زمینه افزوده نکرده است.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {sortedVideos.map((video) => (
            <motion.div
              layoutId={`video-card-${video.id}`}
              onClick={() => setActiveVideo(video)}
              key={video.id}
              className="group cursor-pointer bg-zinc-950/80 border border-white/[5%] rounded-3xl overflow-hidden shadow-xl hover:border-brand-orange/30 transition-all flex flex-col relative"
            >
              {video.isPinned && (
                <div className="absolute top-3 right-3 z-10 bg-brand-orange hover:scale-105 transition-transform text-white font-black text-[9px] px-2 py-1 rounded-full flex items-center gap-1 shadow-md">
                  <Bookmark className="w-2.5 h-2.5 fill-white" /> پین شده ادمین
                </div>
              )}

              {/* Aspect ratio 9:16 vertical video placeholder */}
              <div className="relative aspect-[9/16] bg-black overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-black/30 z-1" />
                
                {/* Visual poster/backdrop */}
                <video
                  src={video.videoUrl}
                  muted
                  playsInline
                  loop
                  disabled={true}
                  className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700 pointer-events-none"
                />

                {/* Overlaid quick details */}
                <div className="absolute bottom-4 inset-x-4 z-2 space-y-2 text-right">
                  <span className="inline-block px-2.5 py-1 bg-white/10 backdrop-blur-md rounded-lg text-white font-bold text-[10px]">
                    {video.category}
                  </span>
                  <h3 className="text-sm font-black text-white leading-snug group-hover:text-amber-400 transition-colors">
                    {video.title}
                  </h3>
                  
                  {/* Likes and Date counts */}
                  <div className="flex items-center justify-between text-[10px] text-zinc-400 pt-1">
                    <span className="flex items-center gap-1.5 font-mono">
                      <Heart className={`w-3.5 h-3.5 ${isLikedByMe(video) ? 'fill-brand-red text-brand-red' : ''}`} /> {video.likes}
                    </span>
                    <span className="font-mono">{video.createdAt}</span>
                  </div>
                </div>

                {/* Floating Play Indicator */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10">
                  <div className="p-4 rounded-full bg-brand-orange/95 text-white shadow-lg shadow-brand-orange/30 scale-90 group-hover:scale-100 transition-transform">
                    <Play className="w-5 h-5 fill-white ml-0.5" />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Detail Overlay View (Clicking open a Video) */}
      <AnimatePresence>
        {activeVideo && (
          <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
            <motion.div
              layoutId={`video-card-${activeVideo.id}`}
              className="bg-zinc-950 border border-white/10 rounded-3xl max-w-5xl w-full grid grid-cols-1 md:grid-cols-12 gap-0 overflow-hidden shadow-2xl relative my-auto"
            >
              {/* Reset view close button */}
              <button
                onClick={() => setActiveVideo(null)}
                className="absolute top-4 left-4 z-50 p-2.5 rounded-full bg-black/40 border border-white/10 text-white hover:bg-white/15 hover:scale-105 transition-all"
              >
                بستن ×
              </button>

              {/* LEFT COLUMN: 9:16 Video Player with full custom interactive HUD controls */}
              <div className="md:col-span-5 bg-black flex flex-col items-center justify-center relative aspect-[9/16] md:aspect-auto md:h-[650px] border-b md:border-b-0 md:border-l border-white/10">
                <video
                  ref={videoRef}
                  src={activeVideo.videoUrl}
                  muted={isMuted}
                  playsInline
                  loop
                  autoPlay
                  className="w-full h-full object-cover"
                  onClick={togglePlay}
                />

                {/* Live sound and play controllers overlay */}
                <div className="absolute inset-x-4 bottom-4 z-40 flex items-center justify-between pointer-events-auto">
                  
                  {/* Play & Pause state indicator */}
                  <button
                    onClick={togglePlay}
                    className="p-3 rounded-full bg-black/60 border border-white/15 text-white hover:bg-black/90 transition-all shadow-md flex items-center justify-center"
                  >
                    {isPlaying ? <Pause className="w-4 h-4 text-white" /> : <Play className="w-4 h-4 fill-white text-white ml-0.5" />}
                  </button>

                  <div className="flex items-center gap-2">
                    {/* Like counter toggle */}
                    <button
                      onClick={() => likeInspirationVideo(activeVideo.id)}
                      className="px-4 py-2 rounded-full bg-black/60 border border-white/15 text-white hover:bg-black/90 transition-all flex items-center gap-1.5 shadow-md font-mono text-xs font-bold"
                    >
                      <Heart className={`w-3.5 h-3.5 ${isLikedByMe(activeVideo) ? 'fill-brand-red text-brand-red border-none' : ''}`} /> {activeVideo.likes}
                    </button>

                    {/* Mute and Unmute Toggle */}
                    <button
                      onClick={toggleMute}
                      className="p-3 rounded-full bg-black/60 border border-white/15 text-white hover:bg-black/90 transition-all shadow-md flex items-center justify-center"
                    >
                      {isMuted ? <VolumeX className="w-4 h-4 text-brand-orange" /> : <Volume2 className="w-4 h-4 text-white" />}
                    </button>
                  </div>

                </div>

                <div className="absolute top-4 right-4 z-30 pointer-events-none bg-black/40 backdrop-blur-md px-3 py-1 rounded-full border border-white/5 text-slate-300 font-bold text-[10px]">
                  {activeVideo.category}
                </div>
              </div>

              {/* RIGHT COLUMN: Script overview and full Transcript details */}
              <div className="md:col-span-7 p-6 md:p-8 flex flex-col justify-between h-auto md:h-[650px] overflow-y-auto space-y-6 text-right">
                
                <div className="space-y-4">
                  <div>
                    <span className="text-zinc-500 font-bold text-[10px] tracking-wider font-mono">ویدیو مرجع ساو</span>
                    <h3 className="text-xl font-extrabold text-white mt-1">{activeVideo.title}</h3>
                  </div>

                  {/* Editorial structured sections */}
                  <div className="border border-white/5 bg-white/[1.5%] rounded-2xl p-4.5 space-y-4">
                    <div>
                      <h4 className="text-xs font-black text-brand-orange mb-2.5 flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5" /> ترانسکریپت کامل دیالوگ‌ها (مبنای بازنویسی)
                      </h4>
                      <p className="text-xs text-zinc-300 leading-relaxed bg-black/40 p-3 rounded-xl border border-white/5 max-h-40 overflow-y-auto scrollbar-thin">
                        {activeVideo.transcript}
                      </p>
                    </div>

                    {activeVideo.scenario && (
                      <div>
                        <h4 className="text-xs font-black text-amber-400 mb-2.5 flex items-center gap-1.5">
                          <Film className="w-3.5 h-3.5" /> ساختار دکوپاژ و ریتم تصویری مرجع
                        </h4>
                        <div className="text-[11px] text-zinc-400 bg-black/40 p-3 rounded-xl border border-white/5 max-h-44 overflow-y-auto leading-relaxed scrollbar-thin">
                          <div className="whitespace-pre-wrap">{activeVideo.scenario}</div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Call-to-action button to open the rewrite Wizard */}
                <div className="pt-4 border-t border-white/[5%]">
                  <button
                    onClick={() => setWizardOpen(true)}
                    className="w-full py-4 rounded-2xl bg-gradient-to-r from-brand-orange to-brand-red text-white text-sm font-black transition-all hover:shadow-[0_4px_30px_rgba(234,88,12,0.5)] transform hover:-translate-y-0.5 flex items-center justify-center gap-2"
                  >
                    <Sparkles className="w-5 h-5 fill-white animate-bounce" /> الهام‌گیری از این ویدیو (تولید سناریوی اختصاصی)
                  </button>
                  <p className="text-[10px] text-zinc-500 text-center mt-2">
                    سیستم ترانسکریپت و دکوپاژ این ویدیو را حفظ کرده و برای محصول و برند شما بازنویسی عمیق انجام می‌دهد.
                  </p>
                </div>

              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Wizard Dialog Overlay (Step-by-step form input to Generation output) */}
      <AnimatePresence>
        {wizardOpen && (
          <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 30 }}
              transition={{ duration: 0.3 }}
              className="bg-zinc-950 border border-white/10 rounded-3xl p-6 md:p-8 max-w-2xl w-full shadow-2xl relative text-right"
            >
              
              {/* Close Button */}
              {!isGenerating && (
                <button
                  onClick={handleCloseWizard}
                  className="absolute top-4 left-4 text-zinc-500 hover:text-white font-extrabold text-sm"
                >
                  انصراف ×
                </button>
              )}

              {/* Wizard Title bar */}
              <div className="border-b border-white/[5%] pb-4 mb-6 flex justify-between items-center">
                <div className="space-y-1">
                  <h3 className="text-lg font-black text-white flex items-center gap-2">
                    <Sparkles className="text-brand-orange w-5 h-5 fill-brand-orange animate-spin" /> دستیار الهام‌گیری سناریونویسی وایرال
                  </h3>
                  <p className="text-[11px] text-zinc-400">
                    تبدیل هوشمند ریتم ریلز «{activeVideo?.title}» به سناریوی شخصی شما
                  </p>
                </div>
                {wizardStep < 4 && (
                  <span className="font-mono text-xs font-black text-brand-orange tracking-widest bg-brand-orange/10 px-3 py-1 rounded-full">
                    مرحله {wizardStep} از ۳
                  </span>
                )}
              </div>

              {/* Progress and status alerts */}
              {errorMsg && (
                <div className="p-4 bg-brand-red/10 border border-brand-red/30 rounded-2xl mb-4 text-right">
                  <p className="text-xs text-brand-red font-bold">⚠️ {errorMsg}</p>
                </div>
              )}

              {/* STEP 1: Product Name & Direct Sale */}
              {wizardStep === 1 && (
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-xs font-black text-zinc-300 block">۱. نام محصول یا خدمت شما چیست؟ <span className="text-brand-orange">*</span></label>
                    <input
                      type="text"
                      className="w-full px-4 py-3 rounded-xl bg-white/[2%] border border-white/10 text-white text-xs text-right outline-none focus:border-brand-orange/40"
                      value={productName}
                      onChange={(e) => setProductName(e.target.value)}
                      placeholder="مثال: ساعت مچی چرمی، پکیج آموزش بورس، خدمات فیبروز ابرو..."
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-black text-zinc-300 block">۲. آیا مستقیما این محصول یا خدمت را می‌فروشید؟</label>
                    <div className="grid grid-cols-2 gap-3">
                      {[
                        { id: 'بله', title: 'بله، فروش تجاری مستقیم است' },
                        { id: 'خیر', title: 'خیر، صرفا جذب فالوور یا برندینگ است' }
                      ].map((item) => (
                        <button
                          key={item.id}
                          onClick={() => setIsSelling(item.id)}
                          className={`p-4 rounded-xl border text-center transition-all flex flex-col justify-center items-center gap-1.5 ${
                            isSelling === item.id 
                              ? 'bg-brand-orange/5 border-brand-orange text-white' 
                              : 'bg-white/[1.5%] border-white/5 text-zinc-500 hover:text-white'
                          }`}
                        >
                          <span className="text-xs font-bold">{item.title}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex justify-end pt-4">
                    <button
                      onClick={() => setWizardStep(2)}
                      disabled={!productName.trim()}
                      className="px-6 py-2.5 rounded-xl bg-white text-zinc-900 text-xs font-black hover:bg-slate-200 transition-all disabled:opacity-40"
                    >
                      مرحله بعدی
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 2: Raw Idea & Audience */}
              {wizardStep === 2 && (
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-xs font-black text-zinc-300 block">۳. ایده اولیه یا خدمات خاص شما برای این ویدیو چیست؟</label>
                    <textarea
                      rows={3}
                      className="w-full px-4 py-3 rounded-xl bg-white/[2%] border border-white/10 text-white text-xs text-right outline-none focus:border-brand-orange/40 resize-none leading-relaxed"
                      value={userIdea}
                      onChange={(e) => setUserIdea(e.target.value)}
                      placeholder="مثال: می‌خوام بگم ساعتمون گارانتی مادام‌العمر داره و موتور سنگینه..."
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-black text-zinc-300 block">۴. مخاطب هدف اصلی ریلز شما کیست؟</label>
                    <input
                      type="text"
                      className="w-full px-4 py-3 rounded-xl bg-white/[2%] border border-white/10 text-white text-xs text-right outline-none focus:border-brand-orange/40"
                      value={targetAudience}
                      onChange={(e) => setTargetAudience(e.target.value)}
                      placeholder="مثال: خریداران ساعت‌های کادوئی لوکس، تاجران جوان..."
                    />
                  </div>

                  <div className="flex justify-between pt-4">
                    <button
                      onClick={() => setWizardStep(1)}
                      className="px-6 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-xs font-black hover:bg-white/10"
                    >
                      بازگشت
                    </button>
                    <button
                      onClick={() => setWizardStep(3)}
                      className="px-6 py-2.5 rounded-xl bg-white text-zinc-900 text-xs font-black hover:bg-slate-200"
                    >
                      مرحله نهایی
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 3: Tone Selection & Core triggers */}
              {wizardStep === 3 && (
                <div className="space-y-6">
                  <div className="space-y-3">
                    <label className="text-xs font-black text-zinc-300 block">۵. لحن سناریو برای تصویربرداری و تدوین چطور باشد؟</label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                      {[
                        { id: 'دوستانه و صمیمی', desc: 'گرم، خودمانی و راحت' },
                        { id: 'رسمی و فاخر', desc: 'باپرستیژ، کت‌وشلواری و متین' },
                        { id: 'هیجانی و تبلیغاتی', desc: 'فروش سریع، تند و کوبنده' },
                        { id: 'خلاق و جسور', desc: 'هنری، با کلمات قدرتمند' },
                        { id: 'طنز و خودمانی', desc: 'ریلکس، چاشنی کنایه و شوخی' }
                      ].map((tone) => (
                        <button
                          key={tone.id}
                          onClick={() => setSelectedTone(tone.id)}
                          className={`p-3 rounded-xl border text-right transition-all flex flex-col justify-between h-20 ${
                            selectedTone === tone.id 
                              ? 'bg-brand-orange/5 border-brand-orange text-white' 
                              : 'bg-white/[1.5%] border-white/5 text-zinc-400 hover:text-white hover:border-white/10'
                          }`}
                        >
                          <span className="text-[11px] font-black">{tone.id}</span>
                          <span className="text-[9px] text-zinc-500">{tone.desc}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex justify-between pt-6 border-t border-white/[5%]">
                    <button
                      onClick={() => setWizardStep(2)}
                      disabled={isGenerating}
                      className="px-5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-xs font-black"
                    >
                      بازگشت
                    </button>

                    <button
                      onClick={handleStartRewrite}
                      disabled={isGenerating}
                      className="px-8 py-2.5 rounded-xl bg-gradient-to-r from-brand-orange to-brand-red text-white text-xs font-black shadow-lg shadow-brand-orange/20 animate-pulse flex items-center gap-1.5"
                    >
                      {isGenerating ? 'در حال بازنویسی...' : '🚀 شروع بازنویسی هماهنگ'}
                    </button>
                  </div>
                </div>
              )}

              {/* LOADING SCREEN IN THE WIZARD */}
              {isGenerating && (
                <div className="py-12 flex flex-col items-center justify-center space-y-6 text-center">
                  <div className="relative">
                    <div className="w-16 h-16 rounded-full border-4 border-brand-orange/20 border-t-brand-orange animate-spin" />
                    <Sparkles className="w-6 h-6 text-brand-orange fill-brand-orange absolute inset-0 m-auto animate-pulse" />
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-sm font-black text-white">هوش مصنوعی ساو در حال محاسبات خلاقیت...</h4>
                    <p className="text-[11px] text-brand-orange font-bold animate-pulse font-mono tracking-wide">
                      {generatingProgress}
                    </p>
                  </div>
                  <div className="max-w-[340px] text-[10px] text-zinc-500 leading-relaxed bg-white/[1%] p-3.5 border border-white/5 rounded-xl">
                    این بازنویسی بر اساس ساختار دقیق ویدیو مرجع صورت می‌گیرد، به گونه‌ای که با کات خوردن یا تغییر زاویه دوربین ویدئو هماهنگ بماند.
                  </div>
                </div>
              )}

              {/* STEP 4: REWRITTEN OUTPUT DISPLAY SCREEN */}
              {wizardStep === 4 && rewrittenScenario && (
                <div className="space-y-6 max-h-[70vh] overflow-y-auto pr-1">
                  
                  <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3 flex items-center gap-2.5 text-right">
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs font-semibold text-emerald-400">سناریوی اختصاصی شما با حفظ ریتم و ضرب تصویربرداری با موفقیت بازنویسی شد!</span>
                  </div>

                  {/* Visual Editorial layout for the newly crafted scenario */}
                  <div className="space-y-5 bg-white/[1%] border border-white/5 rounded-2xl p-4.5">
                    
                    {/* Hook Section */}
                    <div className="p-4 bg-brand-orange/5 border border-brand-orange/20 rounded-xl">
                      <h4 className="text-xs font-black text-white flex items-center gap-1.5 mb-2">
                        <Sparkle className="w-3.5 h-3.5 text-brand-orange fill-brand-orange" /> قلاب ۳ ثانیه‌ای اول ویدیو (Hook)
                      </h4>
                      <p className="text-xs text-brand-white leading-relaxed font-bold font-sans">
                        {rewrittenScenario.hook}
                      </p>
                    </div>

                    {/* Main Script Text */}
                    <div className="p-4 bg-black/40 border border-white/5 rounded-xl">
                      <h4 className="text-xs font-black text-amber-400 flex items-center gap-1.5 mb-2">
                        <Film className="w-3.5 h-3.5 text-amber-400" /> بدنه و دیالوگ‌های سناریو (Scenario Text)
                      </h4>
                      <p className="text-xs text-zinc-300 leading-relaxed whitespace-pre-wrap font-sans">
                        {rewrittenScenario.scenarioText}
                      </p>
                    </div>

                    {/* Caption Section */}
                    <div className="p-4 bg-black/40 border border-white/5 rounded-xl">
                      <h4 className="text-xs font-black text-rose-400 flex items-center gap-1.5 mb-2">
                        <Hash className="w-3.5 h-3.5 text-rose-400" /> کپشن پیشنهادی و هشتگ‌ها (Caption)
                      </h4>
                      <p className="text-xs text-zinc-300 leading-relaxed whitespace-pre-wrap font-mono">
                        {rewrittenScenario.caption}
                      </p>
                    </div>

                    {/* CTA Section */}
                    <div className="p-4 bg-black/40 border border-white/5 rounded-xl">
                      <h4 className="text-xs font-black text-teal-400 flex items-center gap-1.5 mb-2">
                        <Compass className="w-3.5 h-3.5 text-teal-400" /> دعوت به اقدام (CTA)
                      </h4>
                      <p className="text-xs text-zinc-300 leading-relaxed font-sans">
                        {rewrittenScenario.cta}
                      </p>
                    </div>

                    {/* Video and Camera Specifications */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="p-3.5 bg-black/40 border border-white/5 rounded-xl text-right">
                        <h5 className="text-[11px] font-black text-sky-400 flex items-center gap-1">🎥 دکوپاژ و حرکت دوربین</h5>
                        <p className="text-[10px] text-zinc-400 mt-1.5 leading-relaxed">{rewrittenScenario.cameraDirections}</p>
                      </div>
                      <div className="p-3.5 bg-black/40 border border-white/5 rounded-xl text-right">
                        <h5 className="text-[11px] font-black text-purple-400 flex items-center gap-1">🎵 موسیقی فضا و ریتم</h5>
                        <p className="text-[10px] text-zinc-400 mt-1.5 leading-relaxed">{rewrittenScenario.musicMood}</p>
                      </div>
                    </div>

                    {rewrittenScenario.storyFlow && rewrittenScenario.storyFlow.length > 0 && (
                      <div className="p-4 bg-black/40 border border-white/5 rounded-xl">
                        <h4 className="text-xs font-black text-blue-400 flex items-center gap-1.5 mb-2">
                          <Layers className="w-3.5 h-3.5 text-blue-400" /> ایده استوری فلوهای تکمیلی (Story Flow)
                        </h4>
                        <ul className="list-disc list-inside text-xs text-zinc-300 space-y-1 bg-black/30 p-2.5 rounded-lg">
                          {rewrittenScenario.storyFlow.map((s: string, ind: number) => (
                            <li key={ind} className="leading-relaxed">{s}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {rewrittenScenario.shotList && rewrittenScenario.shotList.length > 0 && (
                      <div className="p-4 bg-black/40 border border-white/5 rounded-xl">
                        <h4 className="text-xs font-black text-indigo-400 flex items-center gap-1.5 mb-2">
                          <Video className="w-3.5 h-3.5 text-indigo-400" /> لیست صحنه‌ها برای تصویربرداری (Shot List)
                        </h4>
                        <ul className="list-decimal list-inside text-xs text-zinc-300 space-y-1 bg-black/30 p-2.5 rounded-lg">
                          {rewrittenScenario.shotList.map((s: string, ind: number) => (
                            <li key={ind} className="leading-relaxed">{s}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                  </div>

                  {/* Actions Bar: Copy, Download PDF, Save, Like */}
                  <div className="pt-4 border-t border-white/[5%] flex flex-wrap gap-2 justify-end">
                    
                    {/* Copy Button */}
                    <button
                      onClick={handleCopyText}
                      className="px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-xs font-black hover:bg-white/10 transition-all flex items-center gap-1.5"
                    >
                      {copied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" /> کپی شد!
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" /> کپی کلاژ متن
                        </>
                      )}
                    </button>

                    {/* Download beautiful styled layout button */}
                    <button
                      onClick={handleDownloadPDF}
                      className="px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-xs font-black hover:bg-white/10 transition-all flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5 text-brand-orange" /> دانلود فایل شکیل سناریو
                    </button>

                    {/* Save to workspace list button */}
                    <button
                      onClick={handleSaveToWorkspace}
                      disabled={isSaved}
                      className="px-4 py-2.5 rounded-xl bg-brand-orange text-white text-xs font-black hover:bg-opacity-95 transition-all flex items-center gap-1.5 disabled:opacity-55 disabled:cursor-not-allowed"
                    >
                      {isSaved ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-white" /> در میزکار ذخیره شد
                        </>
                      ) : (
                        <>
                          <Save className="w-3.5 h-3.5" /> ذخیره در میزکار
                        </>
                      )}
                    </button>

                    {/* Close wizard button */}
                    <button
                      onClick={handleCloseWizard}
                      className="px-5 py-2.5 rounded-xl bg-white text-zinc-950 font-black text-xs hover:bg-slate-200 transition-all"
                    >
                      پایان کار سناریو
                    </button>

                  </div>

                </div>
              )}

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};
