/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, GraduationCap, FileText, Tv, ShieldCheck, MessageSquare, ArrowLeft, TrendingUp, Zap, Clock, Users } from 'lucide-react';
import { useAppState } from '../state';

interface HomeViewProps {
  onChangeTab: (tab: string) => void;
  onUpgradeGold: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ onChangeTab, onUpgradeGold }) => {
  const { currentUser, blogPosts, courses } = useAppState();

  const handleQuickAction = (tabId: string) => {
    onChangeTab(tabId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-10 text-right pb-12" dir="rtl">
      {/* Welcome Banner */}
      <div className="relative rounded-[32px] p-8 md:p-12 bg-gradient-to-br from-zinc-950 via-zinc-950/80 to-transparent border border-white/5 overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-[350px] h-[350px] bg-brand-orange/10 rounded-full blur-[110px] pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-[250px] h-[250px] bg-rose-500/5 rounded-full blur-[90px] pointer-events-none" />
        
        <div className="max-w-3xl space-y-5 relative z-10">
          <span className="px-3.5 py-1.5 rounded-full bg-white/5 border border-white/10 text-brand-orange text-[10px] font-black tracking-wide uppercase flex items-center gap-2 w-max">
            <span className="w-1.5 h-1.5 rounded-full bg-brand-orange animate-pulse" />
            سیستم عامل خلاقیت اینستاگرام
          </span>
          
          <h1 className="text-3xl md:text-5xl font-black text-white tracking-tight leading-tight">
            سلام، <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-orange to-brand-red">{currentUser.name}</span> عزیز
          </h1>
          
          <p className="text-zinc-405 text-xs md:text-sm font-medium leading-relaxed max-w-2xl text-zinc-300">
            به مرکز فرماندهی رشد ساو خوش آمدید. امروز می‌خواهید چه چیزی خلق کنید؟ از فید الهام‌گیری سناریونویسی استفاده کنید یا با آخرین مقالات و تکنیک‌های جدید ارتقا پیدا کنید.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-3">
            <button
              onClick={() => handleQuickAction('user')}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-brand-orange to-brand-red text-white text-xs font-black shadow-lg shadow-brand-orange/20 hover:shadow-brand-orange/30 transition-all flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-white" />
              <span>شروع سناریونویسی هوشمند</span>
            </button>

            {!currentUser.isPremium && (
              <button
                onClick={onUpgradeGold}
                className="px-5 py-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white text-xs font-bold transition-all"
              >
                ارتقا به عضویت ویژه طلایی ★
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Metrics Counter cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'ساعات یادگیری در آکادمی', val: '۴۲ ساعت', icon: GraduationCap, color: 'text-amber-400' },
          { label: 'سناریوهای شبیه‌سازی شده', val: '۱۸ سناریو', icon: Sparkles, color: 'text-orange-500' },
          { label: 'مقالات علمی و آموزشی', val: '۱۲ مقاله', icon: FileText, color: 'text-rose-400' },
          { label: 'درخواست‌های تولید فعال', val: '۳ پروژه', icon: Tv, color: 'text-teal-400' }
        ].map((met, idx) => {
          const Icon = met.icon;
          return (
            <div key={idx} className="p-5 rounded-2xl bg-zinc-950 border border-white/5 space-y-2 flex flex-col justify-between">
              <span className="text-[10px] text-zinc-500 font-bold">{met.label}</span>
              <div className="flex items-center justify-between">
                <span className="text-base font-black text-white">{met.val}</span>
                <Icon className={`w-4 h-4 ${met.color}`} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Featured Launchpad Grid */}
      <div className="space-y-4">
        <div className="border-b border-white/5 pb-2">
          <h3 className="text-sm font-black text-white flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-brand-orange" />
            بخش‌های طلایی پلتفرم
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Card 1: AI Assistant */}
          <div 
            onClick={() => handleQuickAction('user')}
            className="group cursor-pointer p-6 rounded-2xl bg-zinc-950 border border-white/5 hover:border-brand-orange/30 transition-all flex flex-col justify-between h-56 hover:-translate-y-1"
          >
            <div className="space-y-2">
              <div className="w-10 h-10 rounded-xl bg-orange-500/10 flex items-center justify-center border border-orange-500/10">
                <Sparkles className="w-5 h-5 text-orange-500" />
              </div>
              <h4 className="text-sm font-black text-white group-hover:text-brand-orange transition-colors">الهام‌گیری سناریو</h4>
              <p className="text-[10px] text-zinc-505 leading-relaxed text-zinc-400">فرمول‌نویسی، کپی ریتم و دکوپاژ ریلزهای پربازدید ادمین با هوش مصنوعی.</p>
            </div>
            <span className="text-[10px] font-black text-zinc-550 flex items-center gap-1 group-hover:text-white transition-all">
              ورود به بخش الهام‌گیری
              <ArrowLeft className="w-3.5 h-3.5" />
            </span>
          </div>

          {/* Card 2: Services */}
          <div 
            onClick={() => handleQuickAction('services')}
            className="group cursor-pointer p-6 rounded-2xl bg-zinc-950 border border-white/5 hover:border-teal-400/35 transition-all flex flex-col justify-between h-56 hover:-translate-y-1"
          >
            <div className="space-y-2">
              <div className="w-10 h-10 rounded-xl bg-teal-400/10 flex items-center justify-center border border-teal-400/10">
                <Tv className="w-5 h-5 text-teal-400" />
              </div>
              <h4 className="text-sm font-black text-white group-hover:text-teal-400 transition-colors">خدمات تخصصی</h4>
              <p className="text-[10px] text-zinc-505 leading-relaxed text-zinc-400">سفارش فیلم‌برداری سینمایی، استخدام تدوین‌گران حرفه‌ای و اتاق فکر.</p>
            </div>
            <span className="text-[10px] font-black text-zinc-550 flex items-center gap-1 group-hover:text-white transition-all">
              مشاهده خدمات
              <ArrowLeft className="w-3.5 h-3.5" />
            </span>
          </div>

          {/* Card 3: Academy */}
          <div 
            onClick={() => handleQuickAction('education')}
            className="group cursor-pointer p-6 rounded-2xl bg-zinc-950 border border-white/5 hover:border-amber-400/35 transition-all flex flex-col justify-between h-56 hover:-translate-y-1"
          >
            <div className="space-y-2">
              <div className="w-10 h-10 rounded-xl bg-amber-400/10 flex items-center justify-center border border-amber-400/10">
                <GraduationCap className="w-5 h-5 text-amber-400" />
              </div>
              <h4 className="text-sm font-black text-white group-hover:text-amber-400 transition-colors">آکادمی رشد</h4>
              <p className="text-[10px] text-zinc-505 leading-relaxed text-zinc-400">دوره‌های مسترکلاس تولید محتوا، نورپردازی موبایلی و بیزنس ریلز.</p>
            </div>
            <span className="text-[10px] font-black text-zinc-550 flex items-center gap-1 group-hover:text-white transition-all">
              ورود به آکادمی
              <ArrowLeft className="w-3.5 h-3.5" />
            </span>
          </div>

          {/* Card 4: Articles */}
          <div 
            onClick={() => handleQuickAction('articles')}
            className="group cursor-pointer p-6 rounded-2xl bg-zinc-950 border border-white/5 hover:border-rose-400/35 transition-all flex flex-col justify-between h-56 hover:-translate-y-1"
          >
            <div className="space-y-2">
              <div className="w-10 h-10 rounded-xl bg-rose-420/10 flex items-center justify-center border border-rose-500/10">
                <FileText className="w-5 h-5 text-rose-400" />
              </div>
              <h4 className="text-sm font-black text-white group-hover:text-rose-400 transition-colors">آخرین مقالات</h4>
              <p className="text-[10px] text-zinc-505 leading-relaxed text-zinc-400">تکنیکال‌ترین تحلیل‌های الگوریتمی، روانشناسی رنگ و بازاریابی رسانه‌ای.</p>
            </div>
            <span className="text-[10px] font-black text-zinc-550 flex items-center gap-1 group-hover:text-white transition-all">
              مطالعه مقالات
              <ArrowLeft className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>
      </div>

      {/* Grid of latest items */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="p-6 rounded-2xl bg-zinc-950 border border-white/5 space-y-4">
          <div className="border-b border-white/5 pb-2">
            <h4 className="text-xs font-black text-white uppercase tracking-wider">★ آکادمی: جدیدترین مباحث آمادگی ریلز</h4>
          </div>
          <div className="space-y-3">
            {[
              { title: 'اصول نورپردازی مودی (Mood Light) محصول با تلفن همراه', dur: '۱۴ دقیقه' },
              { title: 'تکنیک‌های نوشتن قلاب ۳ ثانیه‌ای با کنتراست شدید روانشناختی', dur: '۱۸ دقیقه' }
            ].map((course, idx) => (
              <div key={idx} className="flex justify-between items-center text-[10px] p-2 hover:bg-white/[1.5%] rounded-lg transition-all">
                <span className="text-zinc-300 font-bold">{course.title}</span>
                <span className="text-zinc-500 font-mono font-bold">{course.dur}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="p-6 rounded-2xl bg-zinc-950 border border-white/5 space-y-4">
          <div className="border-b border-white/5 pb-2">
            <h4 className="text-xs font-black text-white uppercase tracking-wider">✍ مقالات پیشنهادی امروز</h4>
          </div>
          <div className="space-y-3">
            {[
              { title: 'چرا الگوریتم ۲۰۲۶ اینستاگرام عاشق ویدیوهای تیره و لوکس است؟', cat: 'تحلیل الگوریتم' },
              { title: 'نقشه راه طلایی تبدیل ریلزهای تصادفی به قیف فروش ارگانیک', cat: 'بازاریابی مدرن' }
            ].map((post, idx) => (
              <div key={idx} className="flex justify-between items-center text-[10px] p-2 hover:bg-white/[1.5%] rounded-lg transition-all">
                <span className="text-zinc-300 font-bold">{post.title}</span>
                <span className="text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded text-[9px] font-black">{post.cat}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
