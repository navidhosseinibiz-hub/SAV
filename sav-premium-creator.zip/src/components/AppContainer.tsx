/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface AppContainerProps {
  currentTab: string;
  children: React.ReactNode;
}

export const AppContainer: React.FC<AppContainerProps> = ({ currentTab, children }) => {
  const isFullWidthTab = currentTab === 'admin';
  return (
    <main className={`flex-1 w-full ${isFullWidthTab ? 'max-w-none px-6 md:px-10' : 'max-w-7xl mx-auto px-4 md:px-6'} md:pr-72 pt-8 pb-24 md:pb-12 transition-all`}>
      <AnimatePresence mode="wait">
        <motion.div
          key={currentTab}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -15 }}
          transition={{ duration: 0.35, ease: 'easeOut' }}
          className="relative w-full"
        >
          {children}
        </motion.div>
      </AnimatePresence>
    </main>
  );
};
