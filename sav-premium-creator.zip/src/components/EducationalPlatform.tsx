/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAppState } from '../state';
import { 
  Play, 
  Clock, 
  Trash2, 
  CheckCircle2, 
  Lock,
  Sparkles,
  ArrowRight,
  TrendingUp,
  BookmarkCheck,
  Video,
  List,
  Pin
} from 'lucide-react';

export const EducationalPlatform: React.FC = () => {
  const { courses, notes, addNote, deleteNote, currentUser } = useAppState();

  // Multi-view navigation inside Academy: 'list' | 'details' | 'player'
  const [viewState, setViewState] = useState<'list' | 'details' | 'player'>('list');
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);
  
  // Players state variables
  const [activeLessonId, setActiveLessonId] = useState<string | null>(null);
  const [noteContent, setNoteContent] = useState('');
  
  // Custom video player stats
  const [isPlaying, setIsPlaying] = useState(false);
  const [progressPercent, setProgressPercent] = useState(35);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const selectedCourse = courses.find(c => c.id === selectedCourseId) || courses[0];

  const lessonsCount = selectedCourse?.lessons?.length || 0;

  // Set active lesson when entering player
  useEffect(() => {
    if (selectedCourse?.lessons && selectedCourse.lessons.length > 0 && !activeLessonId) {
      setActiveLessonId(selectedCourse.lessons[0].id);
    }
  }, [selectedCourse, activeLessonId]);

  const activeLesson = selectedCourse?.lessons?.find(l => l.id === activeLessonId) || selectedCourse?.lessons?.[0];

  const handlePlayToggle = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play().catch(() => {});
      }
      setIsPlaying(!isPlaying);
    } else {
      setIsPlaying(!isPlaying);
    }
  };

  const handleAddNote = () => {
    if (!noteContent.trim() || !activeLesson) return;
    addNote(
      activeLesson.id,
      activeLesson.title,
      "02:40",
      noteContent
    );
    setNoteContent('');
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percentage = Math.round((clickX / rect.width) * 100);
    setProgressPercent(percentage);
  };

  // Find premium status
  const isPremiumUser = currentUser.isPremium;

  // Filter pinned / highlighted course (or use the first course with isPinned: true as featured)
  const featuredCourse = courses.find(c => (c as any).isPinned) || courses[0];
  const otherCourses = courses.filter(c => c.id !== featuredCourse?.id);

  // Filter notes belonging to this active lesson
  const activeLessonNotes = notes.filter(n => n.lessonId === activeLesson?.id);

  return (
    <div className="space-y-8 animate-fadeIn text-right" dir="rtl" id="educational_academy_root">
      
      {/* 1. PRIMARY LIST VIEW: Homepage of Academy */}
      {viewState === 'list' && (
        <div className="space-y-8">
          
          {/* FEATURED COURSE PINNED BANNER */}
          {featuredCourse && (
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-zinc-950 via-matte-dark to-zinc-900 border border-brand-orange/20 shadow-2xl p-6 sm:p-8">
              <div className="absolute top-0 right-0 w-96 h-96 bg-brand-orange/5 rounded-full blur-3xl pointer-events-none" />
              
              <div className="flex flex-col lg:flex-row gap-8 items-center relative z-10">
                {/* Widescreen cover preview */}
                <div className="w-full lg:w-5/12 aspect-video rounded-2xl overflow-hidden border border-white/10 relative shrink-0">
                  <img 
                    src={featuredCourse.coverImage || "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=420&auto=format&fit=crop&q=80"} 
                    alt={featuredCourse.title} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent p-4 flex flex-col justify-between" />
                  <span className="absolute top-3 right-3 px-2 py-1 bg-brand-orange text-white text-[9px] font-black rounded-lg flex items-center gap-1">
                    <Pin className="w-3 h-3 fill-white border-none" />
                    دوره طلایی پیشنهادی ادمین
                  </span>
                </div>

                {/* Meta details */}
                <div className="space-y-4 flex-1">
                  <div className="space-y-2">
                    <div className="flex flex-wrap gap-2 items-center">
                      <span className="font-mono text-[9px] text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded font-extrabold">مسترکلاس برتر</span>
                      {(featuredCourse as any).isPremiumOnly && (
                        <span className="px-2 py-0.5 rounded bg-brand-red/10 border border-brand-red/25 text-[9px] text-brand-red font-black flex items-center gap-1">
                          <Lock className="w-3 h-3 border-none" />
                          مخصوص اعضای طلایی
                        </span>
                      )}
                    </div>
                    <h2 className="text-xl sm:text-2xl font-black text-white leading-snug">{featuredCourse.title}</h2>
                    <p className="text-zinc-400 text-xs leading-relaxed max-w-xl">{featuredCourse.description}</p>
                  </div>

                  <div className="flex items-center gap-4 text-[11px] text-zinc-500 font-bold">
                    <span>جلسات: {featuredCourse.lessons?.length || 0} درس</span>
                    <span>•</span>
                    <span>سطح: {(featuredCourse as any).level || 'پیشرفته'}</span>
                  </div>

                  <button
                    onClick={() => {
                      setSelectedCourseId(featuredCourse.id);
                      setViewState('details');
                    }}
                    className="px-5 py-2.5 rounded-xl bg-white text-zinc-950 hover:bg-zinc-200 text-xs font-black flex items-center gap-1.5 shadow-xl transition-all cursor-pointer"
                  >
                    <span>بررسی سرفصل‌ها و شروع یادگیری</span>
                    <ArrowRight className="w-4 h-4 turn-180" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* GRID OF OTHER ACADEMY COURSES */}
          <div className="space-y-4">
            <div className="border-b border-white/5 pb-2">
              <h3 className="text-sm font-black text-white flex items-center gap-1.5">
                <List className="w-4 h-4 text-brand-orange" />
                کاتالوگ کلی دوره‌های آکادمی ساو
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {otherCourses.length === 0 && (
                <div className="col-span-full p-12 text-center text-zinc-650 text-xs">دوره‌ای فرعی یافت نشد.</div>
              )}

              {otherCourses.map((course) => {
                const isPremiumOnly = (course as any).isPremiumOnly || false;
                const isLocked = isPremiumOnly && !isPremiumUser;

                return (
                  <div 
                    key={course.id}
                    onClick={() => {
                      setSelectedCourseId(course.id);
                      setViewState('details');
                    }}
                    className="p-5 rounded-2xl bg-matte-black border border-white/5 space-y-4 hover:border-white/10 hover:-translate-y-0.5 transition-all cursor-pointer flex flex-col justify-between"
                  >
                    <div className="space-y-3">
                      <div className="aspect-video rounded-xl overflow-hidden bg-zinc-950 relative border border-white/5">
                        <img 
                          src={course.coverImage || "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=420&auto=format&fit=crop&q=80"} 
                          alt={course.title}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                        {isLocked && (
                          <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center">
                            <div className="w-10 h-10 rounded-full bg-brand-red/10 border border-brand-red/30 flex items-center justify-center">
                              <Lock className="w-4 h-4 text-brand-red border-none" />
                            </div>
                          </div>
                        )}
                        {(course as any).isPinned && (
                          <span className="absolute top-2 right-2 px-1.5 py-0.5 bg-brand-orange/80 backdrop-blur-md rounded text-[8px] font-black text-white">دوره پیشنهادی</span>
                        )}
                      </div>

                      <div className="space-y-1.5">
                        <div className="flex justify-between items-center flex-row-reverse border-b border-white/[2%] pb-2">
                          <span className="text-[10px] text-zinc-500 font-bold">جلسات: {course.lessons?.length || 0} درس</span>
                          {isPremiumOnly ? (
                            <span className="text-[9px] text-brand-red font-black flex items-center gap-1 bg-brand-red/10 border border-brand-red/25 px-2 py-0.5 rounded">VIP</span>
                          ) : (
                            <span className="text-[9px] text-emerald-400 font-black px-2 py-0.5 bg-emerald-400/10 rounded">رایگان برای همه</span>
                          )}
                        </div>

                        <h4 className="text-xs font-black text-white leading-relaxed line-clamp-1">{course.title}</h4>
                        <p className="text-[10px] text-zinc-500 line-clamp-2 leading-relaxed">{course.description}</p>
                      </div>
                    </div>

                    <div className="pt-2">
                      <span className="text-[10px] text-brand-orange font-black flex items-center gap-1 justify-end">
                        مشاهده سرفصل‌ها و تدریس‌ها
                        <ArrowRight className="w-3 h-3 turn-180" />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 2. COURSE DETAILS PAGE: Syllabus description, Level, pricing check */}
      {viewState === 'details' && selectedCourse && (
        <div className="space-y-6">
          <button
            onClick={() => setViewState('list')}
            className="text-xs font-extrabold text-zinc-400 hover:text-white flex items-center gap-1 cursor-pointer"
          >
            <ArrowRight className="w-4 h-4" />
            <span>بازگشت به هوم‌پیج آکادمی</span>
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left Box (Details list) */}
            <div className="lg:col-span-8 space-y-6">
              <div className="rounded-3xl p-6 bg-matte-black border border-white/5 space-y-4">
                <div className="aspect-video rounded-2xl overflow-hidden border border-white/10 relative">
                  <img 
                    src={selectedCourse.coverImage || "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=420&auto=format&fit=crop&q=80"}
                    alt={selectedCourse.title}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent p-6 flex flex-col justify-end" />
                </div>

                <div className="space-y-2">
                  <h2 className="text-xl font-black text-white">{selectedCourse.title}</h2>
                  <p className="text-zinc-400 text-xs leading-relaxed">{selectedCourse.description}</p>
                </div>
              </div>

              {/* Course Chapters Syllabus List */}
              <div className="rounded-3xl p-6 bg-matte-black border border-white/5 space-y-4">
                <h3 className="text-xs font-extrabold text-zinc-400 uppercase tracking-wider">سرفصل‌ها و قسمت‌های ضبط‌شده ({lessonsCount} جلسه):</h3>
                <div className="space-y-2 max-h-[300px] overflow-y-auto">
                  {selectedCourse.lessons && selectedCourse.lessons.length > 0 ? (
                    selectedCourse.lessons.map((lesson, idx) => (
                      <div key={idx} className="p-3.5 rounded-xl bg-zinc-950 border border-white/[3%] flex items-center justify-between text-xs text-zinc-300">
                        <div className="flex items-center gap-3">
                          <span className="font-mono w-5 h-5 rounded-full bg-white/5 flex items-center justify-center font-bold text-zinc-500">
                            {idx + 1}
                          </span>
                          <span className="font-semibold">{lesson.title}</span>
                        </div>
                        <span className="text-[10px] text-zinc-550 flex items-center gap-1 font-bold">
                          <Clock className="w-3 h-3 text-zinc-650 border-none" />
                          {lesson.duration || "۱۲ دقیقه"}
                        </span>
                      </div>
                    ))
                  ) : (
                    <p className="text-[10px] text-zinc-500 py-4 text-center">جلسه‌ای منتشر نشده است.</p>
                  )}
                </div>
              </div>
            </div>

            {/* Right sidebar: Premium checker, locked details */}
            <div className="lg:col-span-4 rounded-3xl p-6 bg-matte-black border border-white/5 space-y-6 flex flex-col justify-between">
              <div className="space-y-5">
                <h3 className="text-xs font-bold text-white border-b border-white/5 pb-3">شروع تماشای گام به گام</h3>

                <div className="space-y-4">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-zinc-500">طول کل مسترکلاس:</span>
                    <span className="font-bold text-zinc-300">حدود {lessonsCount * 15} دقیقه</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-zinc-500">مخاطبین هدف:</span>
                    <span className="font-bold text-zinc-300">بلاگرها، ادیتورهای ریلز</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-zinc-500">تعداد جلسات:</span>
                    <span className="font-bold text-zinc-300">{lessonsCount} جلسه ویدیویی</span>
                  </div>
                </div>

                {/* Lock screen alert if premium is required but user is standard */}
                {((selectedCourse as any).isPremiumOnly && !isPremiumUser) ? (
                  <div className="p-4 rounded-2xl bg-brand-red/10 border border-brand-red/20 text-right space-y-3">
                    <div className="flex items-center gap-2 text-brand-red">
                      <Lock className="w-5 h-5 border-none" />
                      <span className="text-xs font-black">این مسترکلاس مخصوص اعضای طلایی است</span>
                    </div>
                    <p className="text-[10px] text-zinc-400 leading-normal">
                      برای باز کردن قفل جلسات و تماشای کلیدهای دکوپاژ وایرال، لطفاً ابتدا حساب کاربری معمولی خود را به ارتقای برنز/طلایی تغییر دهید.
                    </p>
                  </div>
                ) : (
                  <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-right flex items-center gap-2 text-emerald-400">
                    <CheckCircle2 className="w-5 h-5 border-none" />
                    <span className="text-xs font-bold">دسترسی شما تضمین شده است!</span>
                  </div>
                )}
              </div>

              {((selectedCourse as any).isPremiumOnly && !isPremiumUser) ? (
                <button
                  disabled
                  className="w-full text-center py-3 rounded-xl bg-zinc-900 border border-white/5 text-zinc-500 text-xs font-black cursor-not-allowed"
                >
                  پخش قفل شده است
                </button>
              ) : (
                <button
                  onClick={() => {
                    if (selectedCourse?.lessons && selectedCourse.lessons.length > 0) {
                      setActiveLessonId(selectedCourse.lessons[0].id);
                    }
                    setViewState('player');
                  }}
                  className="w-full py-3.5 rounded-xl bg-brand-orange text-white text-xs font-black hover:opacity-95 shadow-xl shadow-brand-orange/20 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-white border-none" />
                  <span>ورود به دوره و پخش گام به گام فیلم‌ها</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 3. PLAYER VIEW: Active lesson, live custom player screen, sidebar tabs, and dynamic notepad */}
      {viewState === 'player' && selectedCourse && activeLesson && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <button
              onClick={() => setViewState('details')}
              className="text-xs font-extrabold text-zinc-400 hover:text-white flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowRight className="w-4 h-4" />
              <span>بازگشت به جزئیات دوره: {selectedCourse.title}</span>
            </button>
            <span className="text-xs text-zinc-500 font-bold bg-[#0c0c0d] px-3 py-1.5 rounded-xl border border-white/5">
              جلسه {selectedCourse.lessons.findIndex(l => l.id === activeLesson.id) + 1} از {lessonsCount}
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left box (Player and Notes - Size 8/12) */}
            <div className="lg:col-span-8 space-y-6">
              
              {/* VIDEO LAYER SIMULATION BOX */}
              <div className="rounded-3xl p-5 bg-matte-black border border-white/5 space-y-4 shadow-2xl relative">
                
                <div className="aspect-video bg-zinc-950 rounded-2xl overflow-hidden relative border border-white/5 flex items-center justify-center group flex-col">
                  {isPlaying ? (
                    <video 
                      ref={videoRef}
                      src={activeLesson.videoUrl || "https://assets.mixkit.co/videos/preview/mixkit-cinematic-foggy-pine-forest-42289-large.mp4"}
                      className="w-full h-full object-cover"
                      controls
                      autoPlay
                      onTimeUpdate={() => {
                        const progress = videoRef.current 
                          ? Math.round((videoRef.current.currentTime / videoRef.current.duration) * 100) 
                          : 35;
                        setProgressPercent(progress);
                      }}
                    />
                  ) : (
                    <>
                      {/* Cover simulation and giant play overlay */}
                      <img 
                        src={selectedCourse.coverImage || "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=420&auto=format&fit=crop&q=80"}
                        alt={activeLesson.title}
                        className="absolute inset-0 w-full h-full object-cover opacity-30" 
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-black/60 flex items-center justify-center flex-col space-y-3 z-10 p-4 text-center">
                        <button 
                          onClick={handlePlayToggle}
                          className="w-14 h-14 rounded-full bg-brand-orange text-white flex items-center justify-center shadow-2xl shadow-brand-orange/40 hover:scale-105 transition-all cursor-pointer"
                        >
                          <Play className="w-6 h-6 fill-white text-white border-none translate-x-[-1px]" />
                        </button>
                        <p className="text-xs font-black text-white">{activeLesson.title}</p>
                        <span className="text-[10px] text-zinc-500 font-bold">سبک جدید دکوپاژ سینماتیک در ریلز</span>
                      </div>
                    </>
                  )}
                </div>

                <div className="space-y-1">
                  <h3 className="text-xs font-black text-white">{activeLesson.title}</h3>
                  <p className="text-[10px] text-zinc-500 leading-relaxed">
                    در این جلسه، چگونگی کادربندی‌های لوکس، زاویه دید دوربین موبایل نسبت به ریلز و فیلترهای تاریک و روشنایی بررسی می‌شود.
                  </p>
                </div>
              </div>

              {/* LIVE NOTEPAD SYSTEM FOR THIS LESSON */}
              <div className="rounded-3xl p-6 bg-matte-black border border-white/5 space-y-4">
                <div className="flex border-b border-white/5 pb-3">
                  <h3 className="text-xs font-black text-zinc-300">دفترچه یادداشت اختصاصی من برای این جلسه</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Enter memo */}
                  <div className="space-y-4">
                    <textarea
                      value={noteContent}
                      onChange={(e) => setNoteContent(e.target.value)}
                      placeholder="نکته طلایی که هم‌اکنون از ویدیو یاد گرفتید را اینجا یادداشت کنید..."
                      rows={3}
                      className="w-full p-4 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white placeholder-zinc-600 focus:outline-none focus:border-brand-orange/30 resize-none font-semibold leading-relaxed"
                    />
                    <button
                      onClick={handleAddNote}
                      disabled={!noteContent.trim()}
                      className="px-4 py-2 bg-zinc-900 border border-white/10 text-[10px] font-black text-zinc-300 rounded-xl hover:text-white transition-all disabled:opacity-45 cursor-pointer"
                    >
                      ثبت و ذخیره یادداشت
                    </button>
                  </div>

                  {/* Logged notes */}
                  <div className="space-y-3">
                    <span className="text-[10px] text-zinc-500 font-bold block">یادداشت‌های ثبت‌شده این جلسه ({activeLessonNotes.length}):</span>
                    
                    {activeLessonNotes.length === 0 ? (
                      <p className="text-[10px] text-zinc-650 py-4 text-center">هیچ یادداشتی هنوز در این قسمت نوشته نشده است.</p>
                    ) : (
                      <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
                        {activeLessonNotes.map((note) => (
                          <div key={note.id} className="p-3 rounded-lg bg-zinc-950 border border-white/[2%] flex justify-between items-start text-[10.5px] relative">
                            <div className="space-y-1">
                              <span className="text-[9px] font-mono text-amber-500 font-bold">⏱ زمان ویدیو {note.timestamp}</span>
                              <p className="text-zinc-300 leading-relaxed font-semibold">{note.content}</p>
                            </div>
                            <button
                              onClick={() => deleteNote(note.id)}
                              className="text-zinc-600 hover:text-red-400 transition-colors shrink-0 mr-2 p-1 cursor-pointer"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Right box: Section / Episode navigator (Size 4/12) */}
            <div className="lg:col-span-4 rounded-3xl p-5 bg-matte-black border border-white/5 space-y-4 shadow-2xl">
              <div>
                <h3 className="text-xs font-black text-zinc-400">سایر قسمت‌های دوره</h3>
                <span className="text-[10px] text-zinc-550 mt-1 block">آموزش سلسله‌مراتبی و گام‌به‌گام:</span>
              </div>

              <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
                {selectedCourse.lessons.map((lesson, idx) => {
                  const isActive = activeLessonId === lesson.id;
                  return (
                    <button
                      key={lesson.id}
                      onClick={() => {
                        setActiveLessonId(lesson.id);
                        setIsPlaying(false);
                      }}
                      className={`w-full p-4 rounded-xl text-right transition-all border flex items-center justify-between font-semibold ${
                        isActive
                          ? 'bg-brand-orange/10 border-brand-orange/20 text-brand-orange shadow-lg'
                          : 'bg-white/[1%] border-white/5 hover:bg-white/[2%] text-zinc-400'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center font-mono text-[9px] font-bold ${
                          isActive ? 'bg-brand-orange text-white' : 'bg-white/5 text-zinc-400'
                        }`}>
                          {idx + 1}
                        </span>
                        <div className="text-right">
                          <p className={`text-xs font-black ${isActive ? 'text-brand-orange' : 'text-white'}`}>{lesson.title}</p>
                          <span className="text-[9px] text-zinc-550 font-bold">مدت زمان: {lesson.duration || "۱۲ دقیقه"}</span>
                        </div>
                      </div>
                      
                      {isActive && (
                        <span className="w-2 h-2 rounded-full bg-brand-orange animate-pulse" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
