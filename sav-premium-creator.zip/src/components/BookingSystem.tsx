/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAppState } from '../state';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  Video, 
  CheckCircle2, 
  Trash2,
  VideoOff
} from 'lucide-react';

export const BookingSystem: React.FC = () => {
  const { consultations, addBooking, deleteBooking, schedulingSlots, bookSlot } = useAppState();

  const [selectedTopicOption, setSelectedTopicOption] = useState('آنالیز جامع پیج اینستاگرام');
  const [customTopic, setCustomTopic] = useState('');
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [selectedSlotId, setSelectedSlotId] = useState<string | null>(null);
  const [isBooked, setIsBooked] = useState(false);

  // Available days in current Persian Jalali month (مثلا خرداد ۱۴۰۵)
  const jalaliMonthDays = Array.from({ length: 31 }, (_, i) => i + 1);

  // Fetch unbooked slots
  const unbookedSlots = schedulingSlots.filter(s => !s.isBooked);
  
  // Calculate days that contain unbooked slots
  const activeAvailableDays = Array.from(new Set(unbookedSlots.map(s => s.day))).sort((a: number, b: number) => a - b);

  // Get active slots for the clicked day
  const slotsForSelectedDay = unbookedSlots.filter(s => s.day === selectedDay);

  const finalTopic = selectedTopicOption === 'سایر موضوعات (نوشتن دستی)' 
    ? (customTopic.trim() || 'مشاوره اختصاصی ساو')
    : selectedTopicOption;

  const handleBook = () => {
    if (!finalTopic || !selectedDay || !selectedSlotId) return;

    const slotObj = unbookedSlots.find(s => s.id === selectedSlotId);
    if (!slotObj) return;

    const formattedDate = `۱۴۰۵/۰۳/${selectedDay < 10 ? '۰' + selectedDay : selectedDay}`;
    
    // Add Booking state
    addBooking({
      topic: finalTopic,
      jalaliDate: formattedDate,
      timeSlot: slotObj.time
    });

    // Toggle Slot as Booked
    bookSlot(selectedSlotId);

    setIsBooked(true);
    setCustomTopic('');
    setSelectedDay(null);
    setSelectedSlotId(null);

    // Close success alert
    setTimeout(() => {
      setIsBooked(false);
    }, 6000);
  };

  const topicOptions = [
    'آنالیز جامع پیج اینستاگرام',
    'دکوپاژ و مربیگری سناریوهای فیلم‌برداری',
    'مشاوره خرید تجهیزات نور و صدا',
    'استراتژی بازاریابی ریلز و قیف فروش',
    'سایر موضوعات (نوشتن دستی)'
  ];

  return (
    <div className="space-y-8" id="booking_system_root">
      {/* Description Callout */}
      <div className="rounded-3xl p-6 bg-gradient-to-b from-white/[2%] to-transparent border border-white/5 space-y-3">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <CalendarIcon className="w-5 h-5 text-brand-orange" />
          کلینیک تخصصی مشاوره و منتورینگ ساو
        </h2>
        <p className="text-zinc-400 text-xs leading-relaxed max-w-3xl">
          آیا درباره نحوه فیلمبرداری، خرید تجهیزات نور، یا بازاریابی کسب‌وکار تخصصی خود نیازمند منتورینگ مستقیم هستید؟ با رزرو نوبت آنلاین، بلافاصله لینک اتاق گوگل‌میت را در پنل کاربری خود و پیام تائیدیه را از طریق بات تلگرام دریافت کنید.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Scheduler Board */}
        <div className="lg:col-span-8 rounded-2xl p-6 bg-matte-black border border-white/5 space-y-6 shadow-xl">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-brand-orange" />
            ۱. انتخاب قرار ملاقات مشاوره
          </h3>

          {/* Consultation Topic Dropdown selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-[11px] font-bold text-zinc-400 block">موضوع اصلی جلسه مشاوره</label>
              <select
                value={selectedTopicOption}
                onChange={(e) => setSelectedTopicOption(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white focus:outline-none focus:border-brand-orange/40 transition-all cursor-pointer"
              >
                {topicOptions.map(opt => (
                  <option key={opt} value={opt} className="bg-zinc-950 text-white">{opt}</option>
                ))}
              </select>
            </div>

            {selectedTopicOption === 'سایر موضوعات (نوشتن دستی)' && (
              <div className="space-y-2">
                <label className="text-[11px] font-bold text-zinc-400 block">توضیح دلخواه موضوع</label>
                <input
                  type="text"
                  value={customTopic}
                  onChange={(e) => setCustomTopic(e.target.value)}
                  placeholder="موضوع مشاوره را اینجا قید فرمایید..."
                  className="w-full px-4 py-3 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white placeholder-zinc-650 focus:outline-none focus:border-brand-orange/40 transition-all font-semibold"
                />
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            {/* Jalali Calendar Sheet (3 cols) */}
            <div className="md:col-span-3 space-y-3">
              <span className="text-[11px] font-bold text-zinc-400 block">انتخاب روز (خرداد ماه ۱۴۰۵)</span>
              
              <div className="p-4 rounded-xl bg-zinc-950/50 border border-white/5 space-y-3">
                {/* Month header */}
                <div className="flex justify-between items-center text-xs font-bold text-zinc-300 border-b border-white/5 pb-2">
                  <span>◀ اردیبهشت</span>
                  <span className="text-brand-orange font-bold">خرداد ۱۴۰۵</span>
                  <span>تیر ماه ▶</span>
                </div>

                {/* Days of week */}
                <div className="grid grid-cols-7 text-center text-[10px] text-zinc-500 font-bold mb-1">
                  <span>ش</span>
                  <span>ی</span>
                  <span>د</span>
                  <span>س</span>
                  <span>چ</span>
                  <span>پ</span>
                  <span>ج</span>
                </div>

                {/* Day blocks */}
                <div className="grid grid-cols-7 gap-1">
                  {/* Empty spaces for Jalali calendar grid alignment */}
                  <div className="p-2" />
                  <div className="p-2" />

                  {jalaliMonthDays.map((day) => {
                    const isAvailable = activeAvailableDays.includes(day);
                    const isSelected = selectedDay === day;

                    return (
                      <button
                        key={day}
                        id={`calendar_day_${day}`}
                        disabled={!isAvailable}
                        onClick={() => {
                          setSelectedDay(day);
                          setSelectedSlotId(null);
                        }}
                        className={`py-2 text-center text-xs font-bold rounded-lg transition-all ${
                          isSelected
                            ? 'bg-gradient-to-tr from-brand-orange to-brand-red text-white shadow-md'
                            : isAvailable
                            ? 'bg-white/[5%] border border-brand-orange/15 text-zinc-250 hover:bg-brand-orange/10 hover:border-brand-orange/30'
                            : 'text-zinc-700/50 cursor-not-allowed text-[10px]'
                        }`}
                      >
                        {day}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Time slot picker (2 cols) */}
            <div className="md:col-span-2 space-y-3">
              <span className="text-[11px] font-bold text-zinc-400 block">ساعات خالی مشاوره</span>
              <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                {selectedDay ? (
                  slotsForSelectedDay.length > 0 ? (
                    slotsForSelectedDay.map((slot) => {
                      const isSelected = selectedSlotId === slot.id;
                      return (
                        <button
                          key={slot.id}
                          id={`time_slot_${slot.id}`}
                          onClick={() => setSelectedSlotId(slot.id)}
                          className={`w-full p-3 rounded-xl text-right text-xs font-semibold transition-all border block ${
                            isSelected
                              ? 'bg-brand-orange/10 border-brand-orange/30 text-brand-orange'
                              : 'bg-white/[2%] border-white/5 text-zinc-350 hover:bg-white/[4%]'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <Clock className="w-3.5 h-3.5 relative" />
                            <span>{slot.time}</span>
                          </div>
                        </button>
                      );
                    })
                  ) : (
                    <p className="text-[10px] text-zinc-500 py-4 text-center">جلسه خالی برای این روز تعریف نشده است.</p>
                  )
                ) : (
                  <div className="p-4 rounded-xl border border-dashed border-white/5 text-center text-[10px] text-zinc-600">
                    برای مشاهده ساعات خالی، ابتدا یک روز روشن را در تقویم انتخاب کنید.
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Confirm Button */}
          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
            id="book_confirm_btn"
            disabled={!finalTopic || !selectedDay || !selectedSlotId}
            onClick={handleBook}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-brand-orange to-brand-red hover:from-orange-600 hover:to-rose-600 text-white font-extrabold text-xs shadow-xl shadow-brand-orange/20 flex items-center justify-center gap-2 transition-all disabled:opacity-40 cursor-pointer"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>تکمیل و رزرو قطعی جلسه مشاوره</span>
          </motion.button>
        </div>

        {/* Existing Consultation Tracking list */}
        <div className="lg:col-span-4 rounded-2xl p-6 bg-matte-black border border-white/5 space-y-5 shadow-xl flex flex-col justify-between">
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2 pb-3 border-b border-white/5">
              <span className="w-1.5 h-1.5 rounded-full bg-brand-red" />
              جلسات رزرو شده من ({consultations.length})
            </h3>

            {consultations.length === 0 ? (
              <div className="text-center py-12 text-zinc-500 space-y-2">
                <VideoOff className="w-8 h-8 mx-auto text-zinc-600" />
                <p className="text-xs">هیچ جلسه مشاوره‌ای رزرو نشده است.</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1">
                {consultations.map((c) => (
                  <div key={c.id} className="p-4 rounded-xl bg-white/[2%] border border-white/5 space-y-3 relative hover:border-white/10 transition-all">
                    <button
                      onClick={() => deleteBooking(c.id)}
                      className="absolute left-3 top-3 text-zinc-505 hover:text-red-400 transition-colors cursor-pointer"
                      title="لغو رزرو"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>

                    <div className="space-y-1 pr-2">
                      <p className="text-xs font-black text-white leading-tight">{c.topic}</p>
                      <div className="flex items-center gap-3 text-[10px] text-zinc-400 mt-1">
                        <span className="font-mono bg-zinc-850 px-2 py-0.5 rounded text-amber-400 font-bold">{c.jalaliDate}</span>
                        <span className="flex items-center gap-1"><Clock className="w-3 h-3 text-zinc-500" /> {c.timeSlot}</span>
                      </div>
                    </div>

                    <a
                      href={c.meetLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20 text-[10px] font-bold flex items-center justify-center gap-1.5 transition-all text-center"
                    >
                      <Video className="w-3.5 h-3.5" />
                      <span>ورود به اتاق گوگل‌میت</span>
                    </a>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-white/5 mt-4 space-y-2.5">
            <h4 className="text-xs font-bold text-zinc-350">نکته مهم قبل از جلسه:</h4>
            <ul className="text-[10px] text-zinc-500 space-y-1 list-disc list-inside">
              <li>۵ دقیقه قبل از زمان رزرو شده در اتاق حاضر شوید.</li>
              <li>آماده کردن سناریوها جهت تسریع در همفکری اجباری است.</li>
              <li>لینک ورود به پشتیبانی تلگرام شما نیز فرستاده شده است.</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Success Notification Modal inside container */}
      <AnimatePresence>
        {isBooked && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed inset-x-4 bottom-4 md:right-auto md:left-4 z-50 p-4 rounded-2xl bg-zinc-950 border border-emerald-500/40 text-white shadow-2xl flex items-center gap-4 max-w-md glow-red"
          >
            <div className="w-10 h-10 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <p className="text-xs font-black text-emerald-400">تراکنش موفقیت‌آمیز قرار مشاوره!</p>
              <p className="text-[10px] text-zinc-400 mt-1">
                اطلاعات تاییدیه جلسه به بات تلگرام ساو ارسال شد. لینک گوگل‌میت نیز با کد تایید در پنل شما ثبت گردید.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
