/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAppState } from '../state';
import { MessageSquare, Calendar, Shield, Send, ArrowRight, Tag, HelpCircle, CheckCircle, AlertCircle, PlusCircle, Sparkles } from 'lucide-react';

export const SupportSystem: React.FC = () => {
  const { currentUser, tickets, addTicket, addTicketMessage } = useAppState();

  const [activeTicketId, setActiveTicketId] = useState<string | null>(null);
  const [isCreatingTicket, setIsCreatingTicket] = useState(false);
  
  // Create ticket states
  const [newTitle, setNewTitle] = useState('');
  const [newDept, setNewDept] = useState('پشتیبانی فنی');
  const [newMessage, setNewMessage] = useState('');
  
  // Chat state
  const [replyText, setReplyText] = useState('');

  // Filter tickets to only show current user
  const userTickets = tickets.filter(t => t.userId === currentUser.id);
  const selectedTicket = tickets.find(t => t.id === activeTicketId);

  const handleSubmitTicket = () => {
    if (!newTitle.trim() || !newMessage.trim()) return;
    addTicket(newDept, newTitle, newMessage);
    setNewTitle('');
    setNewMessage('');
    setIsCreatingTicket(false);
  };

  const handleSendReply = () => {
    if (!replyText.trim() || !activeTicketId) return;
    addTicketMessage(activeTicketId, replyText, 'user');
    setReplyText('');
    
    // Simulate auto-admin reply in 3 seconds to keep UI exciting!
    const savedTicketId = activeTicketId;
    setTimeout(() => {
      addTicketMessage(savedTicketId, 'ممنون از پیام شما. یکی از مربیان فنی یا کارشناسان مالی ساو به زودی جزئیات این مورد را بررسی خواهد کرد و پاسخ نهایی را در همین صفحه بارگذاری خواهد کرد.', 'admin');
    }, 4000);
  };

  // Badges styling
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/10 text-blue-400">باز شده</span>;
      case 'pending':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-400">در انتظار کارشناس</span>;
      case 'answered':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-green-500/10 text-green-400">پاسخ داده شده</span>;
      case 'closed':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-zinc-800 text-zinc-550">بسته شده</span>;
      default:
        return null;
    }
  };

  const getDepartmentIcon = (dept: string) => {
    switch (dept) {
      case 'پشتیبانی فنی': return '🛠️';
      case 'مالی و اشتراک': return '💳';
      case 'مشاوره سناریو': return '🎬';
      default: return '📣';
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Title Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-6 border-b border-white/5">
        <div>
          <h2 className="text-2xl font-black text-white flex items-center gap-2">
            <MessageSquare className="w-6 h-6 text-brand-orange" />
            مرכז مانیتورینگ پشتیبانی و مشاوره طلایی ساو
          </h2>
          <p className="text-zinc-550 text-xs mt-1">ارسال تیکت‌های پشتیبانی فنی، نقد ریلز، فاکتورهای بانکی و دریافت پاسخ مکتوب کارشناسان</p>
        </div>

        {!isCreatingTicket && !activeTicketId && (
          <button
            onClick={() => setIsCreatingTicket(true)}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-brand-orange to-brand-red text-white text-xs font-black shadow-lg shadow-brand-orange/15 flex items-center gap-1.5 transition-all active:scale-[0.98]"
          >
            <PlusCircle className="w-4 h-4" />
            <span>ایجاد تیکت و مشاوره جدید</span>
          </button>
        )}
      </div>

      <div className="min-h-[400px]">
        <AnimatePresence mode="wait">
          
          {/* STATE 1: Creating a ticket */}
          {isCreatingTicket && (
            <motion.div
              key="create-ticket"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="max-w-2xl bg-matte-black border border-white/5 rounded-3xl p-8 space-y-6 shadow-2xl relative"
              dir="rtl"
            >
              <div className="space-y-1">
                <h3 className="text-lg font-black text-white">درخواست پشتیبانی و مربیگری فوری</h3>
                <p className="text-zinc-500 text-xs">موضوع و دپارتمان مربوطه را مشخص کنید تا کارشناسان ساو فوراً پرونده را تایید نمایند.</p>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-zinc-400">بخش مربوطه (دپارتمان)</label>
                    <select
                      value={newDept}
                      onChange={(e) => setNewDept(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white focus:outline-none"
                    >
                      <option>پشتیبانی فنی</option>
                      <option>مالی و اشتراک</option>
                      <option>مشاوره سناریو</option>
                      <option>خدمات ساخت و تدوین</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-zinc-400">عنوان تیکت / موضوع خلاصه</label>
                    <input
                      type="text"
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      placeholder="مثلا: خطای درگاه پرداخت زرین‌پال در خرید اشتراک"
                      className="w-full px-4 py-3 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white placeholder-zinc-700 focus:outline-none focus:border-brand-orange/30"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-zinc-400">شرح کامل پیام تیکت</label>
                  <textarea
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="متن پیام خود را با جزئیات کامل بنویسید..."
                    rows={6}
                    className="w-full p-4 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white placeholder-zinc-700 resize-none focus:outline-none focus:border-brand-orange/30"
                  />
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={handleSubmitTicket}
                    className="px-5 py-3 rounded-xl bg-gradient-to-r from-brand-orange to-brand-red text-white text-xs font-bold shadow-lg transition-all"
                  >
                    ثبت و ارسال پرونده به کارشناسان
                  </button>
                  <button
                    onClick={() => setIsCreatingTicket(false)}
                    className="px-5 py-3 rounded-xl bg-zinc-900 border border-white/5 text-zinc-400 text-xs font-bold transition-all"
                  >
                    انصراف
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* STATE 2: Ticket Chat bubbles interface */}
          {activeTicketId && selectedTicket && (
            <motion.div
              key="ticket-chat"
              initial={{ opacity: 0, x: -15 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 15 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-8"
              dir="rtl"
            >
              {/* Left Column: Metadata card */}
              <div className="lg:col-span-1 space-y-4">
                <button
                  onClick={() => setActiveTicketId(null)}
                  className="px-4 py-2 rounded-xl bg-white/[3%] border border-white/5 text-zinc-300 text-xs font-bold flex items-center gap-1.5 transition-all hover:bg-white/[5%]"
                >
                  <ArrowRight className="w-4 h-4" />
                  <span>بازگشت به لیست پرونده‌ها</span>
                </button>

                <div className="rounded-2xl p-6 bg-matte-black border border-white/5 space-y-4 shadow-xl">
                  <div className="space-y-1">
                    <span className="text-[10px] text-zinc-550 font-mono">شناسه پرونده: {selectedTicket.id.toUpperCase()}</span>
                    <h3 className="text-sm font-black text-white leading-relaxed">{selectedTicket.title}</h3>
                  </div>

                  <div className="space-y-3.5 pt-3 border-t border-white/5 text-xs text-zinc-400">
                    <div className="flex justify-between">
                      <span className="text-zinc-500 font-bold">بخش پاسخگو:</span>
                      <span className="text-white font-semibold flex items-center gap-1">
                        <span>{getDepartmentIcon(selectedTicket.department)}</span>
                        <span>{selectedTicket.department}</span>
                      </span>
                    </div>

                    <div className="flex justify-between">
                      <span className="text-zinc-500 font-bold">وضعیت تیکت:</span>
                      {getStatusBadge(selectedTicket.status)}
                    </div>

                    <div className="flex justify-between">
                      <span className="text-zinc-500 font-bold">اولویت سیستمی:</span>
                      <span className={`font-bold uppercase ${selectedTicket.priority === 'high' ? 'text-rose-450' : 'text-amber-400'}`}>
                        {selectedTicket.priority === 'high' ? 'بسیار بالا' : 'معمولی'}
                      </span>
                    </div>

                    <div className="flex justify-between font-mono">
                      <span className="text-zinc-500 font-bold">تاریخ بازگشایی:</span>
                      <span className="text-zinc-300">{selectedTicket.createdAt}</span>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-brand-orange/5 border border-brand-orange/15 flex gap-2 text-[10px] text-brand-orange">
                    <Shield className="w-4 h-4 shrink-0" />
                    <span className="leading-relaxed">امنیت مکاتبات شما با پروتکل رمزگذاری SSL ساو تضمین شده است.</span>
                  </div>
                </div>
              </div>

              {/* Right Column: Chat layout */}
              <div className="lg:col-span-2 rounded-2xl bg-matte-black border border-white/5 flex flex-col h-[550px] shadow-xl overflow-hidden">
                
                {/* Chat Header */}
                <div className="p-4 bg-zinc-950/60 border-b border-white/5 flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-brand-orange/10 flex items-center justify-center text-brand-orange text-sm font-black">
                      SAV
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">پیشخوان پشتیبانی ساو</h4>
                      <p className="text-[10px] text-zinc-500 mt-0.5">کارشناسان آنلاین هستند • زمان پاسخگویی زنده: کمتر از ۵ دقیقه</p>
                    </div>
                  </div>
                </div>

                {/* Messages Bubbles Scroll Area */}
                <div className="flex-1 overflow-y-auto p-5 space-y-4 max-h-[380px]">
                  {selectedTicket.messages.map((msg, idx) => {
                    const isAdmin = msg.sender === 'admin';
                    return (
                      <div 
                        key={idx} 
                        className={`flex flex-col ${isAdmin ? 'items-start' : 'items-end'} space-y-1`}
                      >
                        <span className="text-[9px] text-zinc-550 font-bold px-1">{msg.senderName}</span>
                        <div 
                          className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed ${
                            isAdmin 
                              ? 'bg-zinc-950 border border-white/5 rounded-tr-none text-zinc-300' 
                              : 'bg-gradient-to-bl from-brand-orange via-brand-orange to-brand-red text-white rounded-tl-none shadow-md shadow-brand-orange/10'
                          }`}
                        >
                          {msg.content}
                        </div>
                        <span className="text-[8px] font-mono text-zinc-650 px-1">{msg.createdAt}</span>
                      </div>
                    );
                  })}
                </div>

                {/* Chat footer input bar */}
                <div className="p-4 bg-zinc-950/40 border-t border-white/5">
                  {selectedTicket.status === 'closed' ? (
                    <p className="text-center text-[11px] text-zinc-500 font-bold py-2">این پرونده بسته شده است و امکان ارسال پیام جدید وجود ندارد.</p>
                  ) : (
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleSendReply();
                        }}
                        placeholder="پیام یا مشاوره خود را بنویسید..."
                        className="flex-1 px-4 py-3 rounded-xl bg-zinc-950 border border-white/10 text-xs text-white focus:outline-none focus:border-brand-orange/40 focus:ring-1 focus:ring-brand-orange/20"
                      />
                      <button
                        onClick={handleSendReply}
                        className="px-4 rounded-xl bg-brand-orange text-white hover:bg-brand-orange-light transition-all flex items-center justify-center shrink-0"
                      >
                        <Send className="w-4 h-4 rotate-180" />
                      </button>
                    </div>
                  )}
                </div>

              </div>
            </motion.div>
          )}

          {/* STATE 3: Default Dashboard Ticket List */}
          {!isCreatingTicket && !activeTicketId && (
            <motion.div
              key="ticket-list"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-4"
              dir="rtl"
            >
              {userTickets.length === 0 ? (
                <div className="rounded-3xl p-12 bg-matte-black border border-white/5 text-center space-y-4">
                  <div className="inline-flex p-4 rounded-full bg-white/[2%] text-zinc-550 border border-white/5">
                    <HelpCircle className="w-10 h-10" />
                  </div>
                  <h3 className="text-base font-bold text-white">هنوز تیکتی ثبت نکرده‌اید</h3>
                  <p className="text-zinc-500 text-xs max-w-md mx-auto leading-relaxed">
                    اگر در حوزه پرداخت، استفاده از دوره‌ها، کیفیت ویدیو یا طراحی قلاب‌های سناریو خود سوالی دارید، اولین تیکت خود را بفرستید.
                  </p>
                  <button
                    onClick={() => setIsCreatingTicket(true)}
                    className="px-4 py-2 rounded-xl bg-white/[4%] border border-white/10 text-white text-xs font-bold hover:bg-white/[6%] transition-all"
                  >
                    شروع گفتگو با مشاوران
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {userTickets.map((t) => (
                    <div 
                      key={t.id}
                      onClick={() => setActiveTicketId(t.id)}
                      className="p-5 rounded-2xl bg-matte-black border border-white/5 hover:border-brand-orange/30 cursor-pointer transition-all space-y-3.5 relative shadow-lg group"
                    >
                      {/* Hover glowing edge */}
                      <div className="absolute inset-0 bg-gradient-to-r from-brand-orange/[3%] to-transparent opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl pointer-events-none" />

                      <div className="flex justify-between items-start">
                        <div className="space-y-1">
                          <span className="text-[9px] text-zinc-500 font-mono tracking-wide">TICKET CODE: {t.id.toUpperCase()}</span>
                          <h4 className="text-xs font-black text-white group-hover:text-brand-orange transition-colors">{t.title}</h4>
                        </div>
                        {getStatusBadge(t.status)}
                      </div>

                      <div className="flex justify-between items-center text-[10px] text-zinc-500 pt-3 border-t border-white/[3%] font-mono">
                        <span className="flex items-center gap-1.5 font-sans">
                          <span>{getDepartmentIcon(t.department)}</span>
                          <span className="text-zinc-400 font-bold">{t.department}</span>
                        </span>
                        <span>{t.createdAt}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          )}

        </AnimatePresence>
      </div>
    </div>
  );
};
