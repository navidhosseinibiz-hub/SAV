/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAppState } from '../state';
import { Phone, CheckCircle, ShieldCheck, ArrowRight, Loader2, KeyRound, Chrome } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const { loginWithOTP, loginWithGoogle, currentUser } = useAppState();

  const [step, setStep] = useState<'phone' | 'otp' | 'success'>('phone');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [phoneError, setPhoneError] = useState('');
  
  const [verificationCode, setVerificationCode] = useState('');
  const [otpError, setOtpError] = useState('');
  
  const [resendTimer, setResendTimer] = useState(60);
  const [isSending, setIsSending] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);

  // Countdown timer logic
  useEffect(() => {
    let interval: any = null;
    if (step === 'otp' && resendTimer > 0) {
      interval = setInterval(() => {
        setResendTimer(prev => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [step, resendTimer]);

  const validatePhone = (num: string) => {
    // Standard Persian phone regex: starts with 09 and is 11 characters long
    const regex = /^09\d{9}$/;
    return regex.test(num);
  };

  const handleSendOtp = () => {
    setPhoneError('');
    if (!phoneNumber) {
      setPhoneError('لطفا شماره موبایل خود را وارد کنید.');
      return;
    }
    if (!validatePhone(phoneNumber)) {
      setPhoneError('شماره موبایل نامعتبر است. فرمت صحیح: ۰۹۱۲۳۴۵۶۷۸۹');
      return;
    }

    setIsSending(true);
    setTimeout(() => {
      setIsSending(false);
      setStep('otp');
      setResendTimer(60);
    }, 1500);
  };

  const handleVerifyOtp = () => {
    setOtpError('');
    if (!verificationCode) {
      setOtpError('لطفا کد تایید ۴ رقمی پیامک شده را وارد کنید.');
      return;
    }
    if (verificationCode.length !== 4) {
      setOtpError('کد تایید باید ۴ رقمی باشد.');
      return;
    }

    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      loginWithOTP(phoneNumber);
      setStep('success');
      setTimeout(() => {
        if (onSuccess) onSuccess();
        onClose();
        // reset form
        setStep('phone');
        setPhoneNumber('');
        setVerificationCode('');
      }, 2000);
    }, 1500);
  };

  const handleGoogleLogin = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      loginWithGoogle('creator@google.com', 'فرهاد کریمی (گوگل)');
      setStep('success');
      setTimeout(() => {
        if (onSuccess) onSuccess();
        onClose();
        setStep('phone');
      }, 2000);
    }, 1200);
  };

  const handleResendCode = () => {
    if (resendTimer > 0) return;
    setIsSending(true);
    setTimeout(() => {
      setIsSending(false);
      setResendTimer(60);
    }, 1000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Background overlay */}
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-md" 
        onClick={onClose}
      />

      {/* Floating Card */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 10 }}
        className="relative w-full max-w-md overflow-hidden rounded-3xl bg-zinc-950 border border-white/10 p-8 shadow-[0_0_50px_rgba(255,87,34,0.15)] text-right"
        dir="rtl"
      >
        {/* Soft glowing ambient circle */}
        <div className="absolute -top-12 -left-12 w-32 h-32 bg-brand-orange/10 rounded-full blur-2xl" />

        <AnimatePresence mode="wait">
          {step === 'phone' && (
            <motion.div
              key="phone"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-6"
            >
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-brand-orange">
                  <ShieldCheck className="w-5 h-5 animate-pulse" />
                  <span className="text-xs font-black uppercase tracking-wider">سیستم ورود یکپارچه ساو</span>
                </div>
                <h3 className="text-2xl font-black text-white">ورود هنرآموزان و کریتورها</h3>
                <p className="text-zinc-500 text-xs leading-relaxed">
                  جهت دریافت سناریوهای خلاق نامحدود، پیوستن به آکادمی تخصصی فیلمسازی و ارتباط مستقیم با مربیان، وارد سامانه ساو شوید.
                </p>
              </div>

              {/* Input Form */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[11px] font-bold text-zinc-400">شماره موبایل شما (مخصوص احراز هویت پیامکی)</label>
                  <div className="relative">
                    <input
                      type="text"
                      maxLength={11}
                      value={phoneNumber}
                      onChange={(e) => {
                        // Only numerical chars allowed
                        const clean = e.target.value.replace(/[^0-9]/g, '');
                        setPhoneNumber(clean);
                      }}
                      placeholder="مثال: ۰۹۱۲۳۴۵۶۷۸۹"
                      className="w-full px-5 py-3.5 pl-12 rounded-xl bg-white/[3%] border border-white/10 text-white font-mono text-center tracking-widest text-sm focus:outline-none focus:border-brand-orange/50 focus:ring-1 focus:ring-brand-orange/20 transition-all placeholder:text-zinc-700 placeholder:text-xs placeholder:font-sans placeholder:tracking-normal"
                    />
                    <Phone className="w-4 h-4 text-zinc-500 absolute left-4 top-1/2 -translate-y-1/2" />
                  </div>
                  {phoneError && (
                    <p className="text-[11px] text-rose-500 font-bold mt-1">{phoneError}</p>
                  )}
                </div>

                <button
                  type="button"
                  disabled={isSending}
                  onClick={handleSendOtp}
                  className="w-full py-4 rounded-xl bg-gradient-to-r from-brand-orange to-brand-red hover:brightness-110 active:scale-[0.98] text-white text-xs font-black shadow-lg shadow-brand-orange/15 flex items-center justify-center gap-2 transition-all"
                >
                  {isSending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <span>دریافت پیامک کد فعالسازی</span>
                      <ArrowRight className="w-4 h-4 rotate-180" />
                    </>
                  )}
                </button>
              </div>

              {/* Divider */}
              <div className="relative flex py-2 items-center">
                <div className="flex-grow border-t border-white/5"></div>
                <span className="flex-shrink mx-4 text-[10px] text-zinc-600 font-bold">یا ورود با شبکه همکاران</span>
                <div className="flex-grow border-t border-white/5"></div>
              </div>

              {/* Google Button */}
              <button
                type="button"
                onClick={handleGoogleLogin}
                className="w-full py-3.5 rounded-xl bg-white/[2%] hover:bg-white/[5%] border border-white/10 text-white text-xs font-bold flex items-center justify-center gap-2.5 transition-all"
              >
                <Chrome className="w-4 h-4 text-brand-orange" />
                <span>احراز هویت آنی با اکانت گوگل</span>
              </button>

              <div className="text-center">
                <button
                  onClick={onClose}
                  className="text-[10px] text-zinc-550 hover:text-zinc-400 font-medium transition-colors"
                >
                  فعلا به طور مهمان ادامه میدهم
                </button>
              </div>
            </motion.div>
          )}

          {step === 'otp' && (
            <motion.div
              key="otp"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-6"
            >
              <div className="space-y-2">
                <h3 className="text-2xl font-black text-white">تایید شماره همراه</h3>
                <p className="text-zinc-500 text-xs leading-relaxed">
                  یک پیامک حاوی کلمه امنیتی ۴ رقمی به شماره <span className="text-zinc-200 font-mono font-bold">{phoneNumber}</span> ارسال شد. لطفا آن را وارد کنید (کد شبیه‌ساز: <span className="text-brand-orange font-mono font-bold">۸۸۲۰</span>).
                </p>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[11px] font-bold text-zinc-400">کد تایید پیامکی</label>
                  <div className="relative">
                    <input
                      type="text"
                      maxLength={4}
                      value={verificationCode}
                      onChange={(e) => {
                        const clean = e.target.value.replace(/[^0-9]/g, '');
                        setVerificationCode(clean);
                      }}
                      placeholder="• • • •"
                      className="w-full px-5 py-4 pl-12 rounded-xl bg-white/[3%] border border-white/10 text-white font-mono text-center tracking-[1.5em] text-lg font-black focus:outline-none focus:border-brand-orange/50 focus:ring-1 focus:ring-brand-orange/25 transition-all placeholder:text-zinc-700"
                    />
                    <KeyRound className="w-4 h-4 text-zinc-500 absolute left-4 top-1/2 -translate-y-1/2" />
                  </div>
                  {otpError && (
                    <p className="text-[11px] text-rose-500 font-bold mt-1">{otpError}</p>
                  )}
                </div>

                <button
                  type="button"
                  disabled={isVerifying}
                  onClick={handleVerifyOtp}
                  className="w-full py-4 rounded-xl bg-gradient-to-r from-brand-orange to-brand-red text-white text-xs font-black shadow-lg shadow-brand-orange/15 flex items-center justify-center gap-2 transition-all"
                >
                  {isVerifying ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <span>فعالسازی هویت و ورود</span>
                  )}
                </button>

                {/* Resend handler */}
                <div className="flex justify-between items-center text-[11px] pt-2">
                  <span className="text-zinc-550">کد را دریافت نکردید؟</span>
                  {resendTimer > 0 ? (
                    <span className="text-zinc-400 font-mono font-bold">ارسال مجدد تا {resendTimer} ثانیه</span>
                  ) : (
                    <button
                      onClick={handleResendCode}
                      className="text-brand-orange font-bold hover:underline"
                    >
                      ارسال مجدد پیامک
                    </button>
                  )}
                </div>

                <button
                  onClick={() => setStep('phone')}
                  className="w-full text-center text-[10px] text-zinc-500 hover:text-zinc-350 transition-all font-bold pt-4"
                >
                  ← تغییر شماره موبایل
                </button>
              </div>
            </motion.div>
          )}

          {step === 'success' && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="py-12 space-y-4 text-center"
            >
              <div className="inline-flex p-4 rounded-full bg-green-500/10 border border-green-500/20 text-green-400 animate-bounce">
                <CheckCircle className="w-12 h-12" />
              </div>
              <h3 className="text-2xl font-black text-white">خوش آمدید!</h3>
              <p className="text-zinc-400 text-xs">
                به عنوان <span className="text-white font-bold">{currentUser?.name || 'هنرآموز ساو'}</span> با موفقیت احراز هویت شدید.
              </p>
              <p className="text-[11px] text-zinc-550">در حال لود دارایی‌ها و بازگشت به میز تدوین ریلز...</p>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};
