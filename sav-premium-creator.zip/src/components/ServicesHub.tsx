/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Tv, Video, Clock } from 'lucide-react';
import { ProductionRequest } from './ProductionRequest';
import { ProductionTeam } from './ProductionTeam';
import { BookingSystem } from './BookingSystem';
import { useAppState } from '../state';

export const ServicesHub: React.FC = () => {
  const { settings, copywriting } = useAppState();

  const allTabs = [
    { 
      id: 'consultation', 
      label: settings.serviceConsultationTitle || copywriting.serviceConsultationTitle || 'مشاوره و کلینیک رشد', 
      icon: Clock, 
      desc: settings.serviceConsultationDesc || copywriting.serviceConsultationDesc || 'رزرو جلسات آنالیز عمیق و لایو استراتژی ارتقای پیج با منتورها',
      enabled: settings.serviceConsultationEnabled !== false 
    },
    { 
      id: 'request', 
      label: settings.serviceProductionTitle || copywriting.serviceProductionTitle || 'خدمات تخصصی تولید', 
      icon: Tv, 
      desc: settings.serviceProductionDesc || copywriting.serviceProductionDesc || 'ثبت سفارش تولید محتوا، تدوین کات سین و پروژه‌های برندینگ',
      enabled: settings.serviceProductionEnabled !== false 
    },
    { 
      id: 'team', 
      label: settings.serviceCreatorsTitle || copywriting.serviceCreatorsTitle || 'کریتورها و تدوین‌گران', 
      icon: Video, 
      desc: settings.serviceCreatorsDesc || copywriting.serviceCreatorsDesc || 'روییارویی و همکاری با بااستعدادترین کریتورها و پیاده‌سازان ویدیو',
      enabled: settings.serviceCreatorsEnabled !== false 
    }
  ];

  const enabledTabs = allTabs.filter(t => t.enabled);

  // Default to first enabled tab
  const [activeServiceTab, setActiveServiceTab] = useState<'request' | 'team' | 'consultation'>(() => {
    return (enabledTabs[0]?.id || 'consultation') as any;
  });

  return (
    <div className="space-y-8 text-right" dir="rtl" id="services_hub_root">
      {/* Top Welcome Title */}
      <div className="border-b border-white/5 pb-4 space-y-1">
        <h2 className="text-xl font-black text-white">{copywriting.servicesTitle || 'مرکز خدمات لوکس تولید و رشد ساو'}</h2>
        <p className="text-xs text-zinc-400">{copywriting.servicesSubtitle || 'مجموعه سرویس‌های یکپارچه جهت ارتقای ضریب ویرال و بازاریابی کانال‌های ویدیویی'}</p>
      </div>

      {enabledTabs.length === 0 ? (
        <div className="p-12 text-center text-zinc-550 border border-white/5 bg-zinc-950 rounded-2xl">
          <p className="text-sm font-black">تمام خدمات موقتاً غیرفعال شده‌اند.</p>
        </div>
      ) : (
        <>
          {/* Services sub-tabs switcher */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {enabledTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeServiceTab === tab.id;
              return (
                <button
                  key={tab.id}
                  id={`tab_btn_${tab.id}`}
                  onClick={() => setActiveServiceTab(tab.id as any)}
                  className={`p-5 rounded-2xl text-right transition-all border flex flex-col justify-between space-y-3 ${
                    isActive
                      ? 'bg-zinc-950 border-brand-orange shadow-lg shadow-brand-orange/5'
                      : 'bg-[#0b0b0c]/50 border-white/5 hover:border-white/10 hover:bg-zinc-950/40'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <div className="w-9 h-9 rounded-xl bg-white/[2%] flex items-center justify-center border border-white/5">
                      <Icon className={`w-4 border-none h-4 ${isActive ? 'text-brand-orange' : 'text-zinc-400'}`} />
                    </div>
                    {isActive && (
                      <span className="w-1.5 h-1.5 rounded-full bg-brand-orange animate-pulse" />
                    )}
                  </div>
                  <div className="space-y-1">
                    <h3 className={`text-xs font-black transition-colors ${isActive ? 'text-brand-orange' : 'text-white'}`}>
                      {tab.label}
                    </h3>
                    <p className="text-[10px] text-zinc-500 font-medium leading-relaxed leading-normal line-clamp-2">
                      {tab.desc}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Primary Dynamic Content Frame */}
          <div className="pt-4">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeServiceTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.25 }}
                className="w-full"
              >
                {activeServiceTab === 'request' && <ProductionRequest />}
                {activeServiceTab === 'team' && <ProductionTeam />}
                {activeServiceTab === 'consultation' && <BookingSystem />}
              </motion.div>
            </AnimatePresence>
          </div>
        </>
      )}
    </div>
  );
};
