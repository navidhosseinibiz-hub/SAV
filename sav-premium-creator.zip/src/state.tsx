/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Scenario, 
  Consultation, 
  ProductionRequest, 
  Course, 
  Lesson,
  UserNote, 
  ScenarioTemplate, 
  BlogPost, 
  PaymentRecord,
  ProductionTeamMember,
  UserProfile,
  SupportTicket,
  HomeSection,
  PushCampaign,
  InspirationVideo
} from './types';
import { 
  INITIAL_COURSES, 
  INITIAL_PAYMENTS, 
  INITIAL_TEMPLATES, 
  INITIAL_BLOGS, 
  INITIAL_TEAM,
  INITIAL_INSPIRATIONS
} from './mockData';

export interface SchedulingSlot {
  id: string;
  day: number;
  time: string;
  isBooked: boolean;
}

interface Settings {
  maintenanceMode: boolean;
  featureGenerator: boolean;
  featureExpertReview: boolean;
  featureBooking: boolean;
  featureProduction: boolean;
  goldSubscriptionPrice: number;
  
  // Advanced variables for SaaS controls
  geminiApiKey: string;
  geminiBackupKey: string;
  gemini_mode_enabled: boolean;
  geminiUsageCount: number;
  
  telegramToken: string;
  telegramBotName: string;
  telegramStatus: 'connected' | 'disconnected' | 'testing';
  telegramWorkflows: {
    notifyConsultations: boolean;
    notifyProduction: boolean;
    notifyExpertReview: boolean;
  };
  
  stripeEnabled: boolean;
  zarinpalEnabled: boolean;
  idpayEnabled: boolean;
  stripeCreds: string;
  zarinpalCreds: string;
  idpayCreds: string;

  // Orderable/toggleable services properties
  serviceConsultationEnabled: boolean;
  serviceProductionEnabled: boolean;
  serviceCreatorsEnabled: boolean;
  serviceConsultationTitle: string;
  serviceConsultationDesc: string;
  serviceProductionTitle: string;
  serviceProductionDesc: string;
  serviceCreatorsTitle: string;
  serviceCreatorsDesc: string;
}

interface AppStateContextType {
  scenarios: Scenario[];
  consultations: Consultation[];
  productionRequests: ProductionRequest[];
  courses: Course[];
  notes: UserNote[];
  templates: ScenarioTemplate[];
  blogPosts: BlogPost[];
  payments: PaymentRecord[];
  teamMembers: ProductionTeamMember[];
  settings: Settings;
  
  // Real Freemium & Account State
  currentUser: UserProfile;
  usersList: UserProfile[];
  tickets: SupportTicket[];
  homeSections: HomeSection[];
  pushCampaigns: PushCampaign[];

  // Dynamic copywriting state and actions
  copywriting: Record<string, string>;
  updateCopywriting: (key: string, val: string) => void;

  // Scheduling slots state and actions
  schedulingSlots: SchedulingSlot[];
  addSlot: (slot: { day: number; time: string }) => void;
  deleteSlot: (slotId: string) => void;
  bookSlot: (slotId: string) => void;

  // Creator profiles handling actions
  addTeamMember: (member: ProductionTeamMember) => void;
  updateTeamMember: (id: string, updated: Partial<ProductionTeamMember>) => void;
  
  // Authentication Actions
  loginWithOTP: (phone: string) => void;
  loginWithGoogle: (email: string, name: string) => void;
  loginAsGuest: () => void;
  logout: () => void;
  registerUser: (name: string, phone: string, email?: string) => void;
  incrementAiCount: () => void;
  
  // User Management
  updateUserStatus: (id: string, status: 'active' | 'suspended') => void;
  updateUserSubscription: (id: string, isPremium: boolean) => void;
  
  // Support Ticketing System
  addTicket: (department: string, title: string, firstMessage: string) => void;
  addTicketMessage: (ticketId: string, content: string, sender: 'user' | 'admin') => void;
  updateTicketStatus: (id: string, status: SupportTicket['status']) => void;
  
  // Page Builder Core
  updateHomeSections: (sections: HomeSection[]) => void;
  
  // Notification Campaigns
  addPushCampaign: (campaign: Omit<PushCampaign, 'id' | 'status'>) => void;
  sendPushCampaignImmediately: (id: string) => void;
  
  // Scenarios actions
  addScenario: (scenario: Omit<Scenario, 'id' | 'createdAt' | 'reviewStatus'>) => Scenario;
  updateScenario: (id: string, updated: Partial<Scenario>) => void;
  deleteScenario: (id: string) => void;
  requestExpertReview: (scenarioId: string) => void;
  submitExpertFeedback: (scenarioId: string, status: Scenario['reviewStatus'], notes: string) => void;
  
  // Bookings actions
  addBooking: (booking: Omit<Consultation, 'id' | 'createdAt' | 'meetLink'>) => void;
  deleteBooking: (id: string) => void;
  
  // Production requests
  addProductionRequest: (req: Omit<ProductionRequest, 'id' | 'createdAt' | 'status'>) => void;
  updateProductionStatus: (id: string, status: ProductionRequest['status']) => void;
  
  // CMS & Templates actions
  addTemplate: (template: Omit<ScenarioTemplate, 'id'>) => void;
  deleteTemplate: (id: string) => void;
  addBlogPost: (post: Omit<BlogPost, 'id'>) => void;
  editBlogPost: (id: string, post: Partial<BlogPost>) => void;
  deleteBlogPost: (id: string) => void;
  addCourse: (course: Omit<Course, 'id' | 'lessons'> & { lessons?: Lesson[] }) => void;
  editCourse: (id: string, course: Partial<Course>) => void;
  addLessonToCourse: (courseId: string, lesson: Omit<any, 'id'>) => void;
  deleteLessonFromCourse: (courseId: string, lessonId: string) => void;
  deleteCourse: (id: string) => void;
  
  // Notes actions
  addNote: (lessonId: string, lessonTitle: string, timestamp: string, content: string) => void;
  deleteNote: (id: string) => void;
  
  // Payments actions
  simulatePayment: (payment: Omit<PaymentRecord, 'id' | 'refId' | 'date'>) => string;
  
  // Settings actions
  updateSettings: (newSettings: Partial<Settings>) => void;

  // Inspiration actions & state
  inspirationVideos: InspirationVideo[];
  inspirationCategories: string[];
  addInspirationVideo: (video: Omit<InspirationVideo, 'id' | 'likes' | 'createdAt'>) => void;
  updateInspirationVideo: (id: string, updated: Partial<InspirationVideo>) => void;
  deleteInspirationVideo: (id: string) => void;
  likeInspirationVideo: (id: string) => void;
  addInspirationCategory: (category: string) => void;
}


const AppStateContext = createContext<AppStateContextType | undefined>(undefined);

export const AppStateProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Read initial states from localStorage if they exist, or fall back to mock seeds
  const [scenarios, setScenarios] = useState<Scenario[]>(() => {
    const saved = localStorage.getItem('sav_scenarios');
    return saved ? JSON.parse(saved) : [];
  });

  const [consultations, setConsultations] = useState<Consultation[]>(() => {
    const saved = localStorage.getItem('sav_consultations');
    return saved ? JSON.parse(saved) : [];
  });

  const [productionRequests, setProductionRequests] = useState<ProductionRequest[]>(() => {
    const saved = localStorage.getItem('sav_production_requests');
    return saved ? JSON.parse(saved) : [];
  });

  const [courses, setCourses] = useState<Course[]>(() => {
    const saved = localStorage.getItem('sav_courses');
    return saved ? JSON.parse(saved) : INITIAL_COURSES;
  });

  const [notes, setNotes] = useState<UserNote[]>(() => {
    const saved = localStorage.getItem('sav_notes');
    return saved ? JSON.parse(saved) : [];
  });

  const [templates, setTemplates] = useState<ScenarioTemplate[]>(() => {
    const saved = localStorage.getItem('sav_templates');
    return saved ? JSON.parse(saved) : INITIAL_TEMPLATES;
  });

  const [blogPosts, setBlogPosts] = useState<BlogPost[]>(() => {
    const saved = localStorage.getItem('sav_blog_posts');
    return saved ? JSON.parse(saved) : INITIAL_BLOGS;
  });

  const [payments, setPayments] = useState<PaymentRecord[]>(() => {
    const saved = localStorage.getItem('sav_payments');
    return saved ? JSON.parse(saved) : INITIAL_PAYMENTS;
  });

  const [teamMembers, setTeamMembers] = useState<ProductionTeamMember[]>(() => {
    const saved = localStorage.getItem('sav_team_members');
    return saved ? JSON.parse(saved) : INITIAL_TEAM;
  });

  const [copywriting, setCopywriting] = useState<Record<string, string>>(() => {
    const saved = localStorage.getItem('sav_copywriting');
    if (saved) {
      try { return JSON.parse(saved); } catch(e) {}
    }
    return {
      appName: 'ساو',
      siteTitle: 'پلتفرم ساو دکوپاژ ریلز',
      siteLogoName: 'آکادمی فیلم‌سازی و استودیو تولید ساو',
      siteLogoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80',
      siteFaviconUrl: 'https://images.unsplash.com/photo-1618052182384-a83a8bd57fbe?w=32&auto=format&fit=crop&q=80',
      heroWelcome: 'سلام کاربر خلاق؛ به ساو خوش آمدی!',
      heroSubtitle: 'اینجا پلتفرم هوشمند برای دکوپاژ ریلزها، ویرایش کادر و ارتقای ۱۰۰ درصدی واچ‌تایم وایرال است.',
      heroBigTitle: 'دستیار خلاق لوکس ریلز ساو',
      heroButtonText: 'شروع کار با دستیار هوشمند سناریو',
      servicesTitle: 'مرکز خدمات لوکس تولید و رشد ساو',
      servicesSubtitle: 'مجموعه سرویس‌های یکپارچه جهت ارتقای ضریب ویرال و بازاریابی کانال‌های ویدیویی',
      academyTitle: 'آکادمی فیلمسازی موبایلی ساو',
      academySubtitle: 'مسترکلاس‌های تخصصی دکوپاژ، تدوین ریتمیک، قلاب و کار روی عواطف مخاطب',
      articlesTitle: 'تحلیل و تبیین الگوریتم‌ها',
      articlesSubtitle: 'آخرین مقالات و یادداشت‌های تخصصی آکادمی ساو',
      footerCopyright: '© ۱۴۰۵ تمامی حقوق برای آژانس دیجیتال و آکادمی ساو محفوظ است.',
      telegramTestBtn: 'تست اتصال ربات تلگرام',
    };
  });

  const [schedulingSlots, setSchedulingSlots] = useState<SchedulingSlot[]>(() => {
    const saved = localStorage.getItem('sav_scheduling_slots');
    return saved ? JSON.parse(saved) : [
      { id: '1', day: 14, time: '۱۰:۰۰ تا ۱۱:۰۰ صبح', isBooked: false },
      { id: '2', day: 14, time: '۱۱:۳۰ تا ۱۲:۳۰ ظـهر', isBooked: false },
      { id: '3', day: 15, time: '۱۴:۰۰ تا ۱۵:۰۰ عصر', isBooked: false },
      { id: '4', day: 15, time: '۱۶:۳۰ تا ۱۷:۳۰ عصر', isBooked: false },
      { id: '5', day: 16, time: '۱۸:۰۰ تا ۱۹:۰۰ شب', isBooked: false },
      { id: '6', day: 17, time: '۱۰:۰۰ تا ۱۱:۰۰ صبح', isBooked: false },
      { id: '7', day: 20, time: '۱۱:۳۰ تا ۱۲:۳۰ ظـهر', isBooked: false },
    ];
  });

  // Expanded Freemium/SaaS States
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('sav_current_user');
    return saved ? JSON.parse(saved) : {
      id: 'guest_' + Math.random().toString(36).substr(2, 6),
      name: 'کاربر مهمان',
      phone: '',
      email: '',
      isPremium: false,
      isGuest: true,
      status: 'active',
      aiCount: 0,
      registrationDate: new Date().toLocaleDateString('fa-IR'),
      provider: 'guest'
    };
  });

  const [usersList, setUsersList] = useState<UserProfile[]>(() => {
    const saved = localStorage.getItem('sav_users_list');
    return saved ? JSON.parse(saved) : [
      {
        id: 'u_1',
        name: 'امیرحسین رضایی',
        phone: '09121234567',
        email: 'amir@example.com',
        isPremium: true,
        isGuest: false,
        status: 'active',
        aiCount: 18,
        registrationDate: '۱۴۰۵/۰۲/۱۰',
        provider: 'otp'
      },
      {
        id: 'u_2',
        name: 'سارا کریمی',
        phone: '09199876543',
        email: 'sara@example.com',
        isPremium: false,
        isGuest: false,
        status: 'active',
        aiCount: 5,
        registrationDate: '۱۴۰۵/۰۲/۲۸',
        provider: 'google'
      },
      {
        id: 'u_3',
        name: 'سیاوش سهرابی',
        phone: '09355551212',
        email: 'sia@example.com',
        isPremium: false,
        isGuest: false,
        status: 'suspended',
        aiCount: 22,
        registrationDate: '۱۴۰۵/۰۱/۱۵',
        provider: 'otp'
      }
    ];
  });

  const [tickets, setTickets] = useState<SupportTicket[]>(() => {
    const saved = localStorage.getItem('sav_tickets');
    return saved ? JSON.parse(saved) : [
      {
        id: 'tk_1',
        userId: 'u_1',
        userName: 'امیرحسین رضایی',
        department: 'پشتیبانی فنی',
        title: 'عدم اعمال خروجی PDF در آیفون ۱۵ پرو مکس',
        status: 'answered',
        priority: 'high',
        createdAt: '۱۴۰۵/۰۳/۰۲',
        messages: [
          {
            sender: 'user',
            senderName: 'امیرحسین رضایی',
            content: 'سلام، من کاربر ویژه طلایی هستم ولی وقتی فایل پی‌دی‌اف سناریو رو دانلود می‌کنم فونت‌ها توی سافاری به هم میریزه. لطفا بررسی بفرمایید.',
            createdAt: '۱۴۰۵/۰۳/۰۲ ۱۲:۳۰'
          },
          {
            sender: 'admin',
            senderName: 'پشتیبان ارشد ساو',
            content: 'درود امیرحسین عزیز. پچ هماهنگی فونت‌های فارسی وب‌آیف زیرسیستم سافاری دقایقی پیش اعمال شد. لطفا مجدد تست بفرمایید و ترجیحا از گوگل کروم یا مرورگرهای مبتنی بر کرومیوم به عنوان جایگزین موقت استفاده کنید.',
            createdAt: '۱۴۰۵/۰۳/۰۲ ۱۴:۱۵'
          }
        ]
      },
      {
        id: 'tk_2',
        userId: 'u_2',
        userName: 'سارا کریمی',
        department: 'مالی و اشتراک',
        title: 'بررسی فاکتور پرداختی درگاه زرین‌پال',
        status: 'open',
        priority: 'medium',
        createdAt: '۱۴۰۵/۰۳/۰۴',
        messages: [
          {
            sender: 'user',
            senderName: 'سارا کریمی',
            content: 'هزینه اشتراک طلایی از حساب من کسر شد ولی سیستم خطای برگشت درگاه داد و هنوز دسترسی برام فعال نشده.',
            createdAt: '۱۴۰۵/۰۳/۰۴ ۱۰:۰۵'
          }
        ]
      }
    ];
  });

  const [homeSections, setHomeSections] = useState<HomeSection[]>(() => {
    const saved = localStorage.getItem('sav_home_sections');
    return saved ? JSON.parse(saved) : [
      { id: 'sec_1', type: 'hero', title: 'دستیار خلاق لوکس ریلز ساو', subtitle: 'کوپایلوت هوشمند سناریو، نورپردازی و دکوپاژ سینماتیک برای اینستاگرام فارسی', enabled: true, order: 1 },
      { id: 'sec_2', type: 'features', title: 'چرا تولیدکنندگان برتر ساو را انتخاب کرده‌اند؟', subtitle: 'پیشرفته‌ترین ابزارهای بهینه‌سازی واچ‌تایم و افزایش تعامل', enabled: true, order: 2 },
      { id: 'sec_3', type: 'popular_courses', title: 'آکادمی فیلمسازی موبایلی ساو', subtitle: 'مسترکلاس‌های تخصصی دکوپاژ، تدوین ریتمیک، قلاب و کار روی عواطف مخاطب', enabled: true, order: 3 },
      { id: 'sec_4', type: 'cta_banner', title: 'به شتاب‌دهنده‌ی سازندگان بپیوندید!', subtitle: 'همین حالا سطح بعدی کیفیت محتوای ویدیویی برند شخصی‌تان را لمس کنید.', enabled: true, order: 4 },
      { id: 'sec_5', type: 'stats', title: 'به روایت ارقام و آمار ساو', subtitle: 'رشد و پویایی کومیونیتی ما در یک نگاه', enabled: true, order: 5 },
      { id: 'sec_6', type: 'team', title: 'منتورها و فیلمبرداران انحصاری ساو', subtitle: 'درخواست آفیش تجهیزات، استودیو، نورپرداز حرفه‌ای و کارگردان هنری در ایران', enabled: true, order: 6 }
    ];
  });

  const [pushCampaigns, setPushCampaigns] = useState<PushCampaign[]>(() => {
    const saved = localStorage.getItem('sav_push_campaigns');
    return saved ? JSON.parse(saved) : [
      { id: 'n_1', title: '🔥 آپدیت جدید الگوریتم ریلز وایرال!', description: 'راز قلاب‌های ۳ ثانیه‌ای جدید اینستاگرام با ویدیوی لوکس تاریک در بخش مقالات آکادمی منتشر شد!', segment: 'all', status: 'sent' },
      { id: 'n_2', title: '🚀 ۳ سناریوی رایگان شما آماده استفاده است', description: 'ایده‌های جذاب ریلز متولد شده با هوش مصنوعی ساو منتظر بازخوانی سناریوهای شماست.', segment: 'guest', status: 'sent' }
    ];
  });

  const [settings, setSettings] = useState<Settings>(() => {
    const saved = localStorage.getItem('sav_settings');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // ensure advanced credentials keys exist
        if (parsed.geminiApiKey !== undefined) return {
          ...parsed,
          serviceConsultationEnabled: parsed.serviceConsultationEnabled ?? true,
          serviceProductionEnabled: parsed.serviceProductionEnabled ?? true,
          serviceCreatorsEnabled: parsed.serviceCreatorsEnabled ?? true,
          serviceConsultationTitle: parsed.serviceConsultationTitle ?? 'مشاوره و کلینیک رشد',
          serviceConsultationDesc: parsed.serviceConsultationDesc ?? 'رزرو جلسات آنالیز عمیق و لایو استراتژی ارتقای پیج با منتورها',
          serviceProductionTitle: parsed.serviceProductionTitle ?? 'خدمات تخصصی تولید',
          serviceProductionDesc: parsed.serviceProductionDesc ?? 'ثبت سفارش تولید محتوا، تدوین کات سین و پروژه‌های برندینگ',
          serviceCreatorsTitle: parsed.serviceCreatorsTitle ?? 'کریتورها و تدوین‌گران',
          serviceCreatorsDesc: parsed.serviceCreatorsDesc ?? 'روییارویی و همکاری با بااستعدادترین کریتورها و پیاده‌سازان ویدیو',
        };
      } catch (e) {}
    }
    return {
      maintenanceMode: false,
      featureGenerator: true,
      featureExpertReview: true,
      featureBooking: true,
      featureProduction: true,
      goldSubscriptionPrice: 350000, // Toman per month
      geminiApiKey: 'SAV-GEMINI-AI-KEY-2026',
      geminiBackupKey: 'SAV-GEMINI-BACKUP-KEY-MOCK',
      gemini_mode_enabled: true,
      geminiUsageCount: 42,
      telegramToken: '7304192301:AAF-telegram-key-sav-mock-token',
      telegramBotName: 'SavReelsBot',
      telegramStatus: 'connected',
      telegramWorkflows: {
        notifyConsultations: true,
        notifyProduction: true,
        notifyExpertReview: true
      },
      stripeEnabled: true,
      zarinpalEnabled: true,
      idpayEnabled: false,
      stripeCreds: 'sk_test_51MszSAV2026',
      zarinpalCreds: 'MerchantID-sav-reels-8820-zarinpal',
      idpayCreds: 'IDPay-APi-Key-779d',

      serviceConsultationEnabled: true,
      serviceProductionEnabled: true,
      serviceCreatorsEnabled: true,
      serviceConsultationTitle: 'مشاوره و کلینیک رشد',
      serviceConsultationDesc: 'رزرو جلسات آنالیز عمیق و لایو استراتژی ارتقای پیج با منتورها',
      serviceProductionTitle: 'خدمات تخصصی تولید',
      serviceProductionDesc: 'ثبت سفارش تولید محتوا، تدوین کات سین و پروژه‌های برندینگ',
      serviceCreatorsTitle: 'کریتورها و تدوین‌گران',
      serviceCreatorsDesc: 'روییارویی و همکاری با بااستعدادترین کریتورها و پیاده‌سازان ویدیو',
    };
  });

  const [inspirationVideos, setInspirationVideos] = useState<InspirationVideo[]>(() => {
    const saved = localStorage.getItem('sav_inspiration_videos');
    return saved ? JSON.parse(saved) : INITIAL_INSPIRATIONS;
  });

  const [inspirationCategories, setInspirationCategories] = useState<string[]>(() => {
    const saved = localStorage.getItem('sav_inspiration_categories');
    return saved ? JSON.parse(saved) : ['بلاگری', 'آموزشی', 'کسب و کار', 'مشاوره', 'سفر', 'آنلاین شاپ'];
  });

  // Sync back to localStorage
  useEffect(() => {
    localStorage.setItem('sav_current_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('sav_users_list', JSON.stringify(usersList));
  }, [usersList]);

  useEffect(() => {
    localStorage.setItem('sav_tickets', JSON.stringify(tickets));
  }, [tickets]);

  useEffect(() => {
    localStorage.setItem('sav_home_sections', JSON.stringify(homeSections));
  }, [homeSections]);

  useEffect(() => {
    localStorage.setItem('sav_push_campaigns', JSON.stringify(pushCampaigns));
  }, [pushCampaigns]);

  useEffect(() => {
    localStorage.setItem('sav_copywriting', JSON.stringify(copywriting));
  }, [copywriting]);

  useEffect(() => {
    localStorage.setItem('sav_scheduling_slots', JSON.stringify(schedulingSlots));
  }, [schedulingSlots]);

  useEffect(() => {
    localStorage.setItem('sav_team_members', JSON.stringify(teamMembers));
  }, [teamMembers]);

  // Sync back to localStorage
  useEffect(() => {
    localStorage.setItem('sav_scenarios', JSON.stringify(scenarios));
  }, [scenarios]);

  useEffect(() => {
    localStorage.setItem('sav_consultations', JSON.stringify(consultations));
  }, [consultations]);

  useEffect(() => {
    localStorage.setItem('sav_production_requests', JSON.stringify(productionRequests));
  }, [productionRequests]);

  useEffect(() => {
    localStorage.setItem('sav_courses', JSON.stringify(courses));
  }, [courses]);

  useEffect(() => {
    localStorage.setItem('sav_notes', JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    localStorage.setItem('sav_templates', JSON.stringify(templates));
  }, [templates]);

  useEffect(() => {
    localStorage.setItem('sav_blog_posts', JSON.stringify(blogPosts));
  }, [blogPosts]);

  useEffect(() => {
    localStorage.setItem('sav_payments', JSON.stringify(payments));
  }, [payments]);

  useEffect(() => {
    localStorage.setItem('sav_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('sav_inspiration_videos', JSON.stringify(inspirationVideos));
  }, [inspirationVideos]);

  useEffect(() => {
    localStorage.setItem('sav_inspiration_categories', JSON.stringify(inspirationCategories));
  }, [inspirationCategories]);

  // Actions
  const loginWithOTP = (phone: string) => {
    const defaultUser: UserProfile = {
      id: 'usr_' + Math.random().toString(36).substr(2, 6),
      name: 'کاربر خلاق ' + phone.substring(phone.length - 4),
      phone: phone,
      email: '',
      isPremium: false,
      isGuest: false,
      status: 'active',
      aiCount: 0,
      registrationDate: new Date().toLocaleDateString('fa-IR'),
      provider: 'otp'
    };
    setCurrentUser(defaultUser);
    setUsersList(prev => {
      if (prev.some(u => u.phone === phone)) return prev;
      return [...prev, defaultUser];
    });
  };

  const loginWithGoogle = (email: string, name: string) => {
    const defaultUser: UserProfile = {
      id: 'usr_' + Math.random().toString(36).substr(2, 6),
      name: name,
      phone: '',
      email: email,
      isPremium: false,
      isGuest: false,
      status: 'active',
      aiCount: 0,
      registrationDate: new Date().toLocaleDateString('fa-IR'),
      provider: 'google'
    };
    setCurrentUser(defaultUser);
    setUsersList(prev => {
      if (prev.some(u => u.email === email)) return prev;
      return [...prev, defaultUser];
    });
  };

  const loginAsGuest = () => {
    const guestUser: UserProfile = {
      id: 'guest_' + Math.random().toString(36).substr(2, 6),
      name: 'کاربر مهمان',
      phone: '',
      email: '',
      isPremium: false,
      isGuest: true,
      status: 'active',
      aiCount: 0,
      registrationDate: new Date().toLocaleDateString('fa-IR'),
      provider: 'guest'
    };
    setCurrentUser(guestUser);
  };

  const logout = () => {
    const guestUser: UserProfile = {
      id: 'guest_' + Math.random().toString(36).substr(2, 6),
      name: 'کاربر مهمان',
      phone: '',
      email: '',
      isPremium: false,
      isGuest: true,
      status: 'active',
      aiCount: 0,
      registrationDate: new Date().toLocaleDateString('fa-IR'),
      provider: 'guest'
    };
    setCurrentUser(guestUser);
  };

  const registerUser = (name: string, phone: string, email?: string) => {
    const updatedUser: UserProfile = {
      id: currentUser.id.startsWith('guest_') ? 'usr_' + Math.random().toString(36).substr(2, 6) : currentUser.id,
      name: name,
      phone: phone,
      email: email || '',
      isPremium: currentUser.isPremium,
      isGuest: false,
      status: 'active',
      aiCount: currentUser.aiCount,
      registrationDate: currentUser.registrationDate,
      provider: email ? 'google' : 'otp'
    };
    setCurrentUser(updatedUser);
    setUsersList(prev => {
      const idx = prev.findIndex(u => u.id === updatedUser.id);
      if (idx !== -1) {
        const copy = [...prev];
        copy[idx] = updatedUser;
        return copy;
      }
      return [...prev, updatedUser];
    });
  };

  const incrementAiCount = () => {
    setCurrentUser(prev => ({ ...prev, aiCount: prev.aiCount + 1 }));
    setUsersList(prevList => prevList.map(u => u.id === currentUser.id ? { ...u, aiCount: u.aiCount + 1 } : u));
  };

  const updateUserStatus = (id: string, status: 'active' | 'suspended') => {
    setUsersList(prev => prev.map(u => u.id === id ? { ...u, status } : u));
    if (currentUser.id === id) {
      setCurrentUser(prev => ({ ...prev, status }));
    }
  };

  const updateUserSubscription = (id: string, isPremium: boolean) => {
    setUsersList(prev => prev.map(u => u.id === id ? { ...u, isPremium } : u));
    if (currentUser.id === id) {
      setCurrentUser(prev => ({ ...prev, isPremium }));
    }
  };

  const addTicket = (department: string, title: string, firstMessage: string) => {
    const newTicket: SupportTicket = {
      id: 'tk_' + Math.random().toString(36).substr(2, 6),
      userId: currentUser.id,
      userName: currentUser.name,
      department,
      title,
      status: 'open',
      priority: 'medium',
      createdAt: new Date().toLocaleDateString('fa-IR'),
      messages: [
        {
          sender: 'user',
          senderName: currentUser.name,
          content: firstMessage,
          createdAt: new Date().toLocaleDateString('fa-IR') + ' ' + new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
        }
      ]
    };
    setTickets(prev => [newTicket, ...prev]);
  };

  const addTicketMessage = (ticketId: string, content: string, sender: 'user' | 'admin') => {
    const senderName = sender === 'admin' ? 'مدیریت و پشتیبانی ساو' : currentUser.name;
    const timeString = new Date().toLocaleDateString('fa-IR') + ' ' + new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
    setTickets(prev => prev.map(t => {
      if (t.id === ticketId) {
        return {
          ...t,
          status: sender === 'admin' ? 'answered' : 'pending',
          messages: [
            ...t.messages,
            {
              sender,
              senderName,
              content,
              createdAt: timeString
            }
          ]
        };
      }
      return t;
    }));
  };

  const updateTicketStatus = (id: string, status: SupportTicket['status']) => {
    setTickets(prev => prev.map(t => t.id === id ? { ...t, status } : t));
  };

  const updateHomeSections = (sections: HomeSection[]) => {
    setHomeSections(sections);
  };

  const addPushCampaign = (campaignData: Omit<PushCampaign, 'id' | 'status'>) => {
    const newCampaign: PushCampaign = {
      ...campaignData,
      id: 'n_' + Math.random().toString(36).substr(2, 6),
      status: campaignData.scheduledAt ? 'scheduled' : 'sent'
    };
    setPushCampaigns(prev => [newCampaign, ...prev]);
  };

  const sendPushCampaignImmediately = (id: string) => {
    setPushCampaigns(prev => prev.map(c => c.id === id ? { ...c, status: 'sent' } : c));
  };

  const addScenario = (scenarioData: Omit<Scenario, 'id' | 'createdAt' | 'reviewStatus'>) => {
    const newScenario: Scenario = {
      ...scenarioData,
      id: 'sc_' + Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toLocaleDateString('fa-IR'),
      reviewStatus: 'pending'
    };
    setScenarios(prev => [newScenario, ...prev]);
    return newScenario;
  };

  const updateScenario = (id: string, updated: Partial<Scenario>) => {
    setScenarios(prev => prev.map(s => s.id === id ? { ...s, ...updated } : s));
  };

  const deleteScenario = (id: string) => {
    setScenarios(prev => prev.filter(s => s.id !== id));
  };

  const requestExpertReview = (scenarioId: string) => {
    setScenarios(prev => prev.map(s => s.id === scenarioId ? { ...s, reviewStatus: 'under_review' } : s));
    
    // Auto-create a pending simulation payment style transaction
    simulatePayment({
      amount: 120000,
      type: 'booking_fee',
      description: `بررسی فوری سناریو کد ${scenarioId.substring(3, 7).toUpperCase()} توسط منتور ساو`,
      gateway: 'zarinpal',
      status: 'successful'
    });
  };

  const submitExpertFeedback = (scenarioId: string, status: Scenario['reviewStatus'], notesText: string) => {
    setScenarios(prev => prev.map(s => s.id === scenarioId ? { ...s, reviewStatus: status, expertNotes: notesText } : s));
  };

  const addBooking = (bookingData: Omit<Consultation, 'id' | 'createdAt' | 'meetLink'>) => {
    const roomCode = Math.random().toString(36).substr(2, 6);
    const newBooking: Consultation = {
      ...bookingData,
      id: 'bk_' + Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toLocaleDateString('fa-IR'),
      meetLink: `https://meet.google.com/sav-${roomCode}-prm`,
      telegramStatus: 'sent'
    };
    setConsultations(prev => [newBooking, ...prev]);
    
    // Simulate active financial entry as audit trail
    simulatePayment({
      amount: 250000,
      type: 'booking_fee',
      description: `رزرو جلسه کلینیک مشاوره: ${bookingData.topic}`,
      gateway: 'idpay',
      status: 'successful'
    });
  };

  const deleteBooking = (id: string) => {
    setConsultations(prev => prev.filter(b => b.id !== id));
  };

  const addProductionRequest = (requestData: Omit<ProductionRequest, 'id' | 'createdAt' | 'status'>) => {
    const newRequest: ProductionRequest = {
      ...requestData,
      id: 'pr_' + Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toLocaleDateString('fa-IR'),
      status: 'received'
    };
    setProductionRequests(prev => [newRequest, ...prev]);

    // Financial entry
    simulatePayment({
      amount: Math.round(requestData.budget * 0.1), // 10% booking deposit
      type: 'production_deposit',
      description: `بیعانه پیش‌پرداخت پروژه (${requestData.contentType})`,
      gateway: 'zarinpal',
      status: 'successful'
    });
  };

  const updateProductionStatus = (id: string, status: ProductionRequest['status']) => {
    setProductionRequests(prev => prev.map(r => r.id === id ? { ...r, status } : r));
  };

  const addTemplate = (templateData: Omit<ScenarioTemplate, 'id'>) => {
    const newTpl: ScenarioTemplate = {
      ...templateData,
      id: 'tpl_' + Math.random().toString(36).substr(2, 9)
    };
    setTemplates(prev => [...prev, newTpl]);
  };

  const deleteTemplate = (id: string) => {
    setTemplates(prev => prev.filter(t => t.id !== id));
  };

  const addBlogPost = (postData: Omit<BlogPost, 'id'>) => {
    const newPost: BlogPost = {
      ...postData,
      id: 'b_' + Math.random().toString(36).substr(2, 9)
    };
    setBlogPosts(prev => [newPost, ...prev]);
  };

  const editBlogPost = (id: string, updatedFields: Partial<BlogPost>) => {
    setBlogPosts(prev => prev.map(p => p.id === id ? { ...p, ...updatedFields } : p));
  };

  const deleteBlogPost = (id: string) => {
    setBlogPosts(prev => prev.filter(p => p.id !== id));
  };

  const addCourse = (courseData: Omit<Course, 'id' | 'lessons'> & { lessons?: Lesson[] }) => {
    const newCourse: Course = {
      ...courseData,
      id: 'c_' + Math.random().toString(36).substr(2, 9),
      lessons: courseData.lessons || []
    };
    setCourses(prev => [...prev, newCourse]);
  };

  const addLessonToCourse = (courseId: string, lessonData: Omit<typeof INITIAL_COURSES[0]['lessons'][0], 'id'>) => {
    const newLesson = {
      ...lessonData,
      id: 'l_' + Math.random().toString(36).substr(2, 9)
    };
    setCourses(prev => prev.map(c => {
      if (c.id === courseId) {
        return { ...c, lessons: [...c.lessons, newLesson] };
      }
      return c;
    }));
  };

  const deleteLessonFromCourse = (courseId: string, lessonId: string) => {
    setCourses(prev => prev.map(c => {
      if (c.id === courseId) {
        return { ...c, lessons: c.lessons.filter(l => l.id !== lessonId) };
      }
      return c;
    }));
  };

  const deleteCourse = (id: string) => {
    setCourses(prev => prev.filter(c => c.id !== id));
  };

  const editCourse = (id: string, updatedFields: Partial<Course>) => {
    setCourses(prev => prev.map(c => c.id === id ? { ...c, ...updatedFields } : c));
  };

  const addNote = (lessonId: string, lessonTitle: string, timestamp: string, content: string) => {
    const newNote: UserNote = {
      id: 'nt_' + Math.random().toString(36).substr(2, 9),
      lessonId,
      lessonTitle,
      timestamp,
      content,
      createdAt: new Date().toLocaleDateString('fa-IR')
    };
    setNotes(prev => [newNote, ...prev]);
  };

  const deleteNote = (id: string) => {
    setNotes(prev => prev.filter(n => n.id !== id));
  };

  const simulatePayment = (p: Omit<PaymentRecord, 'id' | 'refId' | 'date'>) => {
    const refId = (p.gateway === 'stripe' ? 'ST-CH_' : 'ZP-') + Math.floor(10000000 + Math.random() * 90000000);
    const newRecord: PaymentRecord = {
      ...p,
      id: 'pay_' + Math.random().toString(36).substr(2, 9),
      refId,
      date: new Date().toLocaleDateString('fa-IR')
    };
    setPayments(prev => [newRecord, ...prev]);
    return refId;
  };

  const updateSettings = (newSettings: Partial<Settings>) => {
    setSettings(prev => {
      const merged = { ...prev, ...newSettings };
      localStorage.setItem('sav_settings', JSON.stringify(merged));
      return merged;
    });
  };

  const addInspirationVideo = (video: Omit<InspirationVideo, 'id' | 'likes' | 'createdAt'>) => {
    const newVideo: InspirationVideo = {
      ...video,
      id: 'iv_' + Math.random().toString(36).substring(2, 8),
      likes: 0,
      createdAt: new Date().toLocaleDateString('fa-IR'),
      likedByUsers: []
    };
    setInspirationVideos(prev => [newVideo, ...prev]);
  };

  const updateInspirationVideo = (id: string, updated: Partial<InspirationVideo>) => {
    setInspirationVideos(prev => prev.map(v => v.id === id ? { ...v, ...updated } : v));
  };

  const deleteInspirationVideo = (id: string) => {
    setInspirationVideos(prev => prev.filter(v => v.id !== id));
  };

  const likeInspirationVideo = (id: string) => {
    const userId = currentUser ? currentUser.id : 'anonymous';
    setInspirationVideos(prev => prev.map(v => {
      if (v.id === id) {
        const likedBy = v.likedByUsers || [];
        const isAlreadyLiked = likedBy.includes(userId);
        const nextLikedBy = isAlreadyLiked ? likedBy.filter(uid => uid !== userId) : [...likedBy, userId];
        return {
          ...v,
          likes: isAlreadyLiked ? Math.max(0, v.likes - 1) : v.likes + 1,
          likedByUsers: nextLikedBy
        };
      }
      return v;
    }));
  };

  const addInspirationCategory = (category: string) => {
    setInspirationCategories(prev => {
      if (prev.includes(category)) return prev;
      return [...prev, category];
    });
  };

  const updateCopywriting = (key: string, val: string) => {
    setCopywriting(prev => {
      const updated = { ...prev, [key]: val };
      localStorage.setItem('sav_copywriting', JSON.stringify(updated));
      return updated;
    });
  };

  const addSlot = (slot: { day: number; time: string }) => {
    setSchedulingSlots(prev => {
      const updated = [...prev, {
        id: 'slot_' + Math.random().toString(36).substr(2, 9),
        day: slot.day,
        time: slot.time,
        isBooked: false
      }];
      localStorage.setItem('sav_scheduling_slots', JSON.stringify(updated));
      return updated;
    });
  };

  const deleteSlot = (slotId: string) => {
    setSchedulingSlots(prev => {
      const updated = prev.filter(s => s.id !== slotId);
      localStorage.setItem('sav_scheduling_slots', JSON.stringify(updated));
      return updated;
    });
  };

  const bookSlot = (slotId: string) => {
    setSchedulingSlots(prev => {
      const updated = prev.map(s => s.id === slotId ? { ...s, isBooked: true } : s);
      localStorage.setItem('sav_scheduling_slots', JSON.stringify(updated));
      return updated;
    });
  };

  const addTeamMember = (member: ProductionTeamMember) => {
    setTeamMembers(prev => {
      const updated = [...prev, member];
      localStorage.setItem('sav_team_members', JSON.stringify(updated));
      return updated;
    });
  };

  const updateTeamMember = (id: string, updatedFields: Partial<ProductionTeamMember>) => {
    setTeamMembers(prev => {
      const updated = prev.map(m => m.id === id ? { ...m, ...updatedFields } : m);
      localStorage.setItem('sav_team_members', JSON.stringify(updated));
      return updated;
    });
  };

  return (
    <AppStateContext.Provider value={{
      scenarios,
      consultations,
      productionRequests,
      courses,
      notes,
      templates,
      blogPosts,
      payments,
      teamMembers,
      settings,
      
      inspirationVideos,
      inspirationCategories,
      addInspirationVideo,
      updateInspirationVideo,
      deleteInspirationVideo,
      likeInspirationVideo,
      addInspirationCategory,
      
      currentUser,
      usersList,
      tickets,
      homeSections,
      pushCampaigns,

      copywriting,
      updateCopywriting,
      schedulingSlots,
      addSlot,
      deleteSlot,
      bookSlot,
      addTeamMember,
      updateTeamMember,
      
      loginWithOTP,
      loginWithGoogle,
      loginAsGuest,
      logout,
      registerUser,
      incrementAiCount,
      updateUserStatus,
      updateUserSubscription,
      addTicket,
      addTicketMessage,
      updateTicketStatus,
      updateHomeSections,
      addPushCampaign,
      sendPushCampaignImmediately,
      
      addScenario,
      updateScenario,
      deleteScenario,
      requestExpertReview,
      submitExpertFeedback,
      
      addBooking,
      deleteBooking,
      
      addProductionRequest,
      updateProductionStatus,
      
      addTemplate,
      deleteTemplate,
      addBlogPost,
      editBlogPost,
      deleteBlogPost,
      addCourse,
      editCourse,
      addLessonToCourse,
      deleteLessonFromCourse,
      deleteCourse,
      
      addNote,
      deleteNote,
      
      simulatePayment,
      updateSettings
    }}>
      {children}
    </AppStateContext.Provider>
  );
};

export const useAppState = () => {
  const context = useContext(AppStateContext);
  if (!context) {
    throw new Error('useAppState can only be used inside AppStateProvider');
  }
  return context;
};
